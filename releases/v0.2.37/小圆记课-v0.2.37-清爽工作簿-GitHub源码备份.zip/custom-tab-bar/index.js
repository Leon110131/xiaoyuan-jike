var theme=require('../utils/theme');
Component({
 data:{selected:-1,hidden:false,list:[{pagePath:'/pages/dashboard/index',text:'工作台',icon:'/assets/tab-bar/dashboard.png',selectedIcon:'/assets/tab-bar/dashboard-selected.png'},{pagePath:'/pages/calendar/index',text:'课表',icon:'/assets/tab-bar/calendar.png',selectedIcon:'/assets/tab-bar/calendar-selected.png'},{pagePath:'/pages/members/index',text:'会员',icon:'/assets/tab-bar/members.png',selectedIcon:'/assets/tab-bar/members-selected.png'},{pagePath:'/pages/statistics/index',text:'统计',icon:'/assets/tab-bar/statistics.png',selectedIcon:'/assets/tab-bar/statistics-selected.png'},{pagePath:'/pages/mine/index',text:'我的',icon:'/assets/tab-bar/mine.png',selectedIcon:'/assets/tab-bar/mine-selected.png'}]},
 lifetimes:{attached:function(){this.syncSelected();}},
 pageLifetimes:{show:function(){this.syncSelected();}},
 methods:{
  applyPalette:function(t){t=t||theme.current();var list=this.data.list.map(function(item){return Object.assign({},item,{selectedIcon:'/assets/themes/'+t.id+'/'+item.pagePath.split('/')[2]+'-selected.png'});});this.setData({themeId:t.id,themePrimary:t.primary,themeStyle:t.style,list:list});},
  syncSelected:function(){var app=getApp(),pages=getCurrentPages(),route=app.globalData.activeTabPath||(pages.length?('/'+pages[pages.length-1].route):''),idx=-1;for(var i=0;i<this.data.list.length;i++)if(this.data.list[i].pagePath===route){idx=i;break;}this.setData({selected:idx});this.applyPalette(theme.current());},
  switchTab:function(e){var idx=Number(e.currentTarget.dataset.index),item=this.data.list[idx],self=this;if(!item||this._switching)return;var old=this.data.selected,app=getApp(),oldPath=app.globalData.activeTabPath;this._switching=true;app.globalData.activeTabPath=item.pagePath;this.setData({selected:idx});wx.switchTab({url:item.pagePath,fail:function(){app.globalData.activeTabPath=oldPath;self.setData({selected:old});wx.showToast({title:'页面切换失败，请重试',icon:'none'});},complete:function(){self._switching=false;}});}
 }
});
