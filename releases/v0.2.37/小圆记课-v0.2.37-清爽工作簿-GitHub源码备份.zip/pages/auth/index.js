var defineThemePage=function(config){Page(require('../../utils/theme-page')(config));};
var feedback=require('../../utils/page-feedback');
var s=require('../../utils/store'),account=require('../../utils/coach-account'),docs=require('../../utils/legal-documents');
var HINT='仅演示流程，不会发送真实短信。试用验证码固定为 123456。';
defineThemePage(require('../../utils/back-navigation')('pages/auth/index',require('../../utils/page-guard')({
 data:{agreementsAccepted:false,mode:'register',profile:null,form:{name:'',phone:'',code:'',password:''},codeSent:false,codePhone:'',hint:HINT},
 onShow:function(){var p=s.get('coachProfile')||{},f=this.data.form;if(!this._profileInitialized){f.name=p.name||'';f.phone=p.phone||'';this._profileInitialized=true;}this.setData({profile:p,form:f});},
 setMode:function(e){this.setData({mode:e.currentTarget.dataset.mode,hint:HINT});},
 onInput:function(e){var key=e.currentTarget.dataset.key,f=this.data.form;if(!Object.prototype.hasOwnProperty.call(f,key))return;f[key]=e.detail.value;if(key==='phone'){f.code='';this.setData({codeSent:false,codePhone:'',hint:HINT});}this.setData({form:f});},
 phoneReady:function(){if(!account.validPhone(this.data.form.phone)){feedback.showToast({title:'请填写有效的11位手机号',icon:'none'});return false;}return true;},
 sendCode:function(){if(!this.phoneReady())return;this.setData({codeSent:true,codePhone:this.data.form.phone.trim(),hint:'演示验证码：123456（没有实际发送短信）'});feedback.showToast({title:'已生成演示验证码',icon:'success'});},
 submit:function(){if(this.data.mode==='register')this.register();else this.login();},
 register:function(){if(!this.data.agreementsAccepted){feedback.showToast({title:'请阅读并确认两份测试草案',icon:'none'});return;}var f=this.data.form;if(!f.name.trim()){feedback.showToast({title:'请填写教练名称',icon:'none'});return;}if(!this.phoneReady())return;if(!this.data.codeSent||this.data.codePhone!==f.phone.trim()||f.code!=='123456'){feedback.showToast({title:'请获取并填写演示验证码',icon:'none'});return;}if(!f.password||f.password.length<6){feedback.showToast({title:'密码至少6位（仅演示，不保存密码）',icon:'none'});return;}s.registerDemoCoach({name:f.name.trim(),phone:f.phone.trim(),brand:'小圆记课',isRegistered:true,registrationConsent:docs.accept(['privacy','service'])});s.setRole('coach');feedback.showModal({title:'注册流程演示完成',content:'已登记本地手机号资料，本教练体验版全部功能开放，不设使用期限和会员人数限制。尚未连接真实短信、密码验证或云端账号。',showCancel:false,success:function(){feedback.navigateBack({delta:1});}});},
 login:function(){if(!this.phoneReady())return;var f=this.data.form,p=s.get('coachProfile')||{};if(!p.isRegistered||f.phone.trim()!==p.phone){feedback.showModal({title:'未找到匹配的演示账号',content:'请先通过手机号注册建立本地演示账号。',showCancel:false});return;}if(!f.password){feedback.showToast({title:'请输入密码（演示）',icon:'none'});return;}s.setRole('coach');feedback.showModal({title:'登录流程演示完成',content:'已用本地手机号资料模拟登录。没有连接真实密码验证或服务器。',showCancel:false,success:function(){feedback.navigateBack({delta:1});}});},
 onAgreementChange:function(e){this.setData({agreementsAccepted:Array.isArray(e.detail.value)&&e.detail.value.indexOf('accept')>=0});},openLegal:function(e){wx.navigateTo({url:'/pages/legal/index?kind='+encodeURIComponent(e.currentTarget.dataset.kind)});},
 clear:function(){this.setData({agreementsAccepted:false,form:{name:'',phone:'',code:'',password:''},codeSent:false,codePhone:'',hint:HINT});}
})));
