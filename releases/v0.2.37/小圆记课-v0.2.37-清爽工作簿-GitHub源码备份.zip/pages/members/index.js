var defineThemePage=function(config){Page(require('../../utils/theme-page')(config));};
var s=require('../../utils/store'),classification=require('../../utils/member-classification');
defineThemePage(require('../../utils/back-navigation')('pages/members/index',require('../../utils/tab-page')(2,require('../../utils/feature-page')('members',{
 data:{members:[],filtered:[],query:'',status:'全部',goal:'全部',sort:'最近训练',statusOptions:['正常训练','暂停训练','已结课','课时预警','重点跟进'],goalOptions:classification.goals,sortOptions:['最近训练','剩余课时（从少到多）']},
 onShow:function(){var app=getApp();if(app.globalData.memberStatusFilter){this.setData({status:app.globalData.memberStatusFilter,query:'',goal:'全部'});app.globalData.memberStatusFilter='';}this.refresh();},
 refresh:function(){var all=s.visibleMembers().map(function(m){m.avatar=(m.name||'?').substring(0,1);m.targetLabel=classification.goalLabel(m.target);return m;});this.setData({members:all});this.filter();},
 onSearch:function(e){this.setData({query:e.detail.value});this.filter();},
 chooseStatus:function(e){var v=e.currentTarget.dataset.value;this.setData({status:this.data.status===v?'全部':v});this.filter();},
 chooseGoal:function(e){var v=e.currentTarget.dataset.value;this.setData({goal:this.data.goal===v?'全部':v});this.filter();},
 onSort:function(e){this.setData({sort:this.data.sortOptions[Number(e.detail.value)]});this.filter();},
 filter:function(){var self=this,arr=(this.data.members||[]).slice(),query=(this.data.query||'').toLowerCase(),status=this.data.status,goal=this.data.goal;arr=arr.filter(function(m){var ok=(!query||(m.name||'').toLowerCase().indexOf(query)>=0||(m.phone||'').indexOf(query)>=0);if(status==='正常训练'||status==='暂停训练'||status==='已结课')ok=ok&&m.status===status;if(status==='课时预警'){var pp=s.activePackages(m.id),left=pp.reduce(function(sum,p){return sum+Number(p.remaining||0);},0);ok=ok&&((m.tags||[]).indexOf('课时预警')>=0||left<=Number((s.get('reminderRules')||{}).firstWarning||5));}if(status==='重点跟进')ok=ok&&(m.tags||[]).indexOf('重点跟进')>=0;if(goal!=='全部')ok=ok&&classification.matches(m.target,goal);return ok;});arr=arr.map(function(m){var p=s.activePackages(m.id);m.remaining=p.reduce(function(sum,x){return sum+Number(x.remaining||0);},0);var ws=s.list('workouts').filter(function(w){return w.memberId===m.id;}).sort(function(a,b){return b.date.localeCompare(a.date);});m.lastTraining=ws.length?ws[0].date:'1900-01-01';m.lastTrainingLabel=ws.length?ws[0].date:'暂无训练记录';m.tags=m.tags||[];return m;});if(this.data.sort==='剩余课时（从少到多）')arr.sort(function(a,b){return a.remaining-b.remaining;});else arr.sort(function(a,b){return b.lastTraining.localeCompare(a.lastTraining);});this.setData({filtered:arr});},
 addMember:function(){wx.navigateTo({url:'/pages/member-form/index'});},
 openDetail:function(e){wx.navigateTo({url:'/pages/member-detail/index?id='+e.currentTarget.dataset.id});},
 resetFilters:function(){this.setData({query:'',status:'全部',goal:'全部',sort:'最近训练'});this.filter();}
}))));
