// Pure planner: deletions require registered exact content and preserve referenced user data.
var COACH=['members','packages','courses','plans','measurements','workouts','nutritionGoals','nutritionLogs','photos','reports','financialEntries','ledger'];
var PLATFORM=[];
function stable(x){if(x===null||typeof x!=='object')return JSON.stringify(x);if(Array.isArray(x))return '['+x.map(stable).join(',')+']';return '{'+Object.keys(x).sort().map(function(k){return JSON.stringify(k)+':'+stable(x[k]);}).join(',')+'}';}
function identity(k,row){return row.id||(k==='nutritionGoals'?row.memberId:'');}
function key(k,id){return k+'|'+id;}
function refs(k,row){var a=[];function ref(collection,id){if(id)a.push(key(collection,id));}
 if(COACH.indexOf(k)>=0){ref('members',row.memberId);ref('packages',row.packageId);ref('courses',row.courseId);ref('workouts',row.workoutId);ref('plans',row.planId);}
 if(PLATFORM.indexOf(k)>=0){ref('coaches',row.coachId);ref('subscriptionOrders',row.orderId);if(k==='adminWorkspaces')ref('coaches',row.id);if(k==='coaches')ref('subscriptionOrders',row.currentOrderId);}
 return a;
}
function plan(state,domain){if(domain!=='coach'&&domain!=='platform')throw Error('清理范围无效');var collections=domain==='coach'?COACH:PLATFORM,registry=state.sampleRegistry||[],remove={},known=0;
 registry.forEach(function(entry){if(entry.origin!=='builtin-factory'||entry.domain!==domain||collections.indexOf(entry.collection)<0)return;var matches=(state[entry.collection]||[]).filter(function(x){return identity(entry.collection,x)===entry.id;});if(!matches.length)return;known+=matches.length;if(matches.length!==1)return;var row=matches[0];if(entry.collection==='coaches'&&entry.id==='coach_demo')return;if(stable(row)===entry.fingerprint)remove[key(entry.collection,entry.id)]=true;});
 var changed=true;while(changed){changed=false;COACH.concat(PLATFORM).forEach(function(c){(state[c]||[]).forEach(function(row){if(remove[key(c,identity(c,row))])return;refs(c,row).forEach(function(k){if(remove[k]){delete remove[k];changed=true;}});});});}
 var rows=collections.map(function(c){var ids=(state[c]||[]).filter(function(x){return remove[key(c,identity(c,x))];}).map(function(x){return identity(c,x);});return {collection:c,ids:ids,count:ids.length};}),total=rows.reduce(function(n,x){return n+x.count;},0);
 return {domain:domain,rows:rows,total:total,protectedCount:known-total};
}
module.exports={identity:identity,coach:COACH,platform:PLATFORM,stable:stable,plan:plan};
