function assert(ok, msg) { if (!ok) throw require('./operation-errors').create('VALIDATION', msg); }
function object(value) { return value && typeof value === 'object' && !Array.isArray(value); }
function number(value, min, label, integer) {
  assert(value !== '' && value != null && typeof value !== 'boolean', label+'不能为空。');
  var n = Number(value);
  assert(isFinite(n) && n >= min && (!integer || Math.floor(n) === n), label+'格式不正确。');
  return n;
}
function date(value, label) {
  assert(typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value),label+'格式不正确。');
  var parts=value.split('-'), d=new Date(Number(parts[0]),Number(parts[1])-1,Number(parts[2]),12);
  assert(d.getFullYear()===Number(parts[0]) && d.getMonth()+1===Number(parts[1]) && d.getDate()===Number(parts[2]),label+'不是有效日期。');
  return value;
}
function packageData(p) {
  assert(object(p),'课时包格式不正确。');
  assert(typeof p.name==='string' && p.name.trim(),'请填写课时包名称。');
  var total=number(p.total,1,'总课时',true), used=number(p.used,0,'已用课时',true), left=number(p.remaining,0,'剩余课时',true);
  assert(total===used+left,'总课时必须等于已用课时与剩余课时之和。');
  var amount=number(p.saleAmount,0,'售课金额');
  assert(amount<=100000000 && Math.abs(amount*100-Math.round(amount*100))<0.00001,'金额最多两位小数且不能超过一亿元。');
  date(p.startDate,'开始日期');
  if(p.endDate) { date(p.endDate,'到期日期'); assert(p.endDate>=p.startDate,'到期日期不能早于开始日期。'); }
  if(p.saleDate)date(p.saleDate,'售课日期');
  assert(['active','paused','closed','refunded','ended'].indexOf(p.status)>=0,'课时包状态无效。');
}
function courseData(c) {
  date(c.date,'课程日期');
  assert(typeof c.time==='string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(c.time),'课程时间格式不正确。');
  assert(number(c.duration,1,'课程时长',true)<=1440,'课程时长不能超过 24 小时。');
}
function nutrition(row, isGoal) {
  if(!isGoal)date(row.date,'营养记录日期');
  ['kcal','protein','carbs','fat'].forEach(function(k) { number(row[k],0,'营养数值'); });
  if(!isGoal)assert(number(row.adherence,0,'执行度')<=100,'执行度不能超过 100%。');
}
function financial(row) {
  assert(['income','expense'].indexOf(row.type)>=0,'收支类型不正确。');
  var amount=number(row.amount,0.01,'收支金额');
  assert(amount<=100000000 && Math.abs(amount*100-Math.round(amount*100))<0.00001,'金额最多两位小数且不能超过一亿元。');
  date(row.date,'收支日期');
  assert(typeof row.category==='string' && row.category.trim(),'请选择收支分类。');
}
function workout(row) { if(row.templateSnapshot!=null){var t=row.templateSnapshot;assert(object(t)&&typeof t.id==='string'&&typeof t.name==='string'&&t.name.trim()&&typeof t.dayName==='string'&&Array.isArray(t.exerciseNames)&&t.exerciseNames.every(function(n){return typeof n==='string';}),'训练模板快照格式无效。');number(t.version,1,'计划版本',true);} if(row.time!==undefined)assert(typeof row.time==='string'&&/^([01]\d|2[0-3]):[0-5]\d$/.test(row.time),'训练时间格式不正确。');
  date(row.date,'训练日期'); number(row.duration,1,'训练时长',true);
  assert(Array.isArray(row.sets),'训练组数据格式无效。');
  row.sets.forEach(function(st) {
    ['restActual','restPlanned'].forEach(function(k){if(st[k]!==undefined)number(st[k],0,'休息记录',true);});if(st.restCompleted!==undefined)assert(typeof st.restCompleted==='boolean','休息完成状态格式无效。');number(st.weight,0,'重量'); number(st.reps,0,'次数',true); number(st.rest,0,'休息时间',true);
    assert(st.rpe===undefined||number(st.rpe,0,'RPE')<=10,'RPE 必须在 0–10 之间。');
    assert(st.rir===undefined||number(st.rir,0,'RIR',true)<=10,'RIR 必须在 0–10 之间。');
  });
}
function snapshot(data, keys) {
  assert(object(data) && data.demoOnly===true,'不是本试用版导出的备份。');
  assert(!data.backupVersion || data.backupVersion<=5,'备份版本高于当前支持版本。');
  // 先整体校验，再由调用方一次提交；拒绝缺失集合，避免新旧数据混合。
  var arrays=['members','packages','courses','exercises','plans','measurements','workouts','nutritionGoals','nutritionLogs','photos','reports','financialEntries','ledger'];
  arrays.forEach(function(key) { assert(Array.isArray(data[key]),'备份 '+key+' 必须是数组。'); });
  ['coachProfile','cancelRules','reminderRules'].forEach(function(k) { assert(object(data[k]),'备份 '+k+' 格式不正确。'); });
  assert(data.demoRole==='coach','演示角色无效。');
  var maps={};
  arrays.forEach(function(k) {
    maps[k]={};
    data[k].forEach(function(row) {
      assert(object(row),'备份 '+k+' 包含无效记录。');
      if(k==='nutritionGoals')return;
      assert(typeof row.id==='string' && row.id && !maps[k][row.id],'备份 '+k+' 存在空或重复 ID。'); maps[k][row.id]=row;
    });
  });
  function member(row) { assert(typeof row.memberId==='string' && !!maps.members[row.memberId],'备份存在无效会员关联。'); }
  ['packages','courses','measurements','workouts','nutritionGoals','nutritionLogs','photos','ledger'].forEach(function(k) { data[k].forEach(member); });
  data.reports.forEach(function(r) { if(r.reportType!=='summary')member(r); });
  data.plans.forEach(function(p){if(p.template===true){assert(!p.memberId,'通用计划不可绑定会员。');assert(typeof p.name==='string'&&p.name.trim(),'计划名称无效。');assert(Array.isArray(p.days)&&p.days.length,'训练日不能为空。');p.days.forEach(function(d){assert(typeof d.name==='string'&&d.name.trim()&&Array.isArray(d.exerciseNames)&&d.exerciseNames.length&&d.exerciseNames.every(function(n){return typeof n==='string'&&n.trim();}),'训练日动作无效。');});}else member(p);});data.packages.forEach(packageData);
  data.courses.forEach(function(c) { courseData(c); assert(['scheduled','completed','canceled','leave','no_show'].indexOf(c.status)>=0,'课程状态无效。'); if(c.packageId)assert(maps.packages[c.packageId] && maps.packages[c.packageId].memberId===c.memberId,'课程课时包关联无效。'); if(c.workoutId)assert(maps.workouts[c.workoutId] && maps.workouts[c.workoutId].memberId===c.memberId,'课程训练关联无效。'); });
  data.workouts.forEach(function(w) { workout(w); if(w.planId)assert(maps.plans[w.planId] && maps.plans[w.planId].memberId===w.memberId,'训练计划关联无效。'); if(w.courseId)assert(maps.courses[w.courseId] && maps.courses[w.courseId].memberId===w.memberId,'训练课程关联无效。'); });
  data.ledger.forEach(function(l) { assert(maps.packages[l.packageId] && maps.packages[l.packageId].memberId===l.memberId,'课时流水关联无效。'); if(l.courseId)assert(maps.courses[l.courseId] && maps.courses[l.courseId].memberId===l.memberId,'课时流水课程关联无效。'); });
  var goals={}; data.nutritionGoals.forEach(function(g) { nutrition(g,true); assert(!goals[g.memberId],'营养目标会员重复。'); goals[g.memberId]=true; });
  data.nutritionLogs.forEach(function(g) { nutrition(g,false); }); data.financialEntries.forEach(financial);
  function finiteTree(value) { if(typeof value==='number')assert(isFinite(value),'备份包含非有限数值。'); else if(value && typeof value==='object')Object.keys(value).forEach(function(k) { assert(['__proto__','prototype','constructor'].indexOf(k)<0,'备份包含非法字段。'); finiteTree(value[k]); }); }
  if(data.backupVersion>=5)assert(Array.isArray(data.workoutDrafts),'备份 workoutDrafts 必须是数组。');
  if(data.workoutDrafts!=null)require('./workout-drafts').validate(data.workoutDrafts,data);
  finiteTree(data);
  return true;
}
module.exports={assert:assert,number:number,date:date,packageData:packageData,courseData:courseData,nutrition:nutrition,financial:financial,workout:workout,snapshot:snapshot};
