// 每个原生Tab页有独立的底栏实例；在页面显示和数据变更时主动同步。
var ROUTES=['/pages/dashboard/index','/pages/calendar/index','/pages/members/index','/pages/statistics/index','/pages/mine/index'];
function overlay(data){return !!(data.showBookingDrawer||data.showCourseDetail||data.showPackageChooser||data.showQuickFinance);}
module.exports=function(index,config){
 var load=config.onLoad,show=config.onShow,ready=config.onReady,hide=config.onHide;
 function sync(page){var app=getApp();app.globalData.activeTabPath=ROUTES[index];if(typeof page.getTabBar==='function'){var bar=page.getTabBar();if(bar)bar.setData({selected:index,hidden:overlay(page.data)});}}
 function setup(page){if(page._tabStateWrapped)return;page._tabStateWrapped=true;var base=page.setData;page.setData=function(patch,callback){var next=Object.assign({},this.data,patch);if(typeof this.getTabBar==='function'){var bar=this.getTabBar();if(bar)bar.setData({selected:index,hidden:overlay(next)});}return base.call(this,patch,callback);};}
 config.onLoad=function(){setup(this);if(load)return load.apply(this,arguments);};
 config.onShow=function(){setup(this);sync(this);if(show)return show.apply(this,arguments);};
 config.onReady=function(){sync(this);if(ready)return ready.apply(this,arguments);};
 config.onHide=function(){if(typeof this.getTabBar==='function'){var bar=this.getTabBar();if(bar)bar.setData({hidden:false});}if(hide)return hide.apply(this,arguments);};
 return config;
};
