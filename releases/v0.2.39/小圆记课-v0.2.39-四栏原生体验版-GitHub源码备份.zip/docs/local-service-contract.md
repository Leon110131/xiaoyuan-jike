# 本地数据服务约定

这是本地同步接口，消费者是本小程序页面；不提供 HTTP 端点。

```js
var service = require('./local-service');
var result = service.execute(function () {
  // 在同一事务中调用现有 store 同步方法。
  return store.addMember(member);
}, { expectedRevision: revisionAtStart }); // 可选；用于明确要求整个本地版本不变的动作
```

成功：`{ok:true, data:<处理结果>, error:null, revision:<提交后版本或null>, changed:<布尔值>}`。

失败：`{ok:false, data:null, error:{code,message,hint,retryable}, revision:<开始时版本或null>, changed:false}`。

revision 为 null 表示本次未取得版本，不表示版本为 0；提交后的版本读取失败仍返回成功。不要仅根据 revision 判断是否保存。失败不会自动重试；释放空间等恢复条件满足后由用户再次提交。没有本机数据版本迁移。

`expectedRevision` 是整个本地事务的乐观版本检查，建议只用于需要这一约束的调用。会员编辑使用原会员快照比较，避免其他无关集合变化造成误冲突。

错误码：VALIDATION 为预期输入校验，CONFLICT 为资料变化，STORAGE_QUOTA / STORAGE_UNAVAILABLE 为存储失败，INVALID_STATE 为原资料格式异常，ASYNC_TRANSACTION 为不支持的异步事务，INTERNAL_ERROR 为未分类异常。只有明确校验消息原样展示，未知异常统一提示。

事务回调必须同步，不得启动网络请求、异步任务或原生异步写入；返回 Promise/thenable 会拒绝提交，声明的 async 回调在执行前拒绝。不能取消普通回调已经启动的异步副作用，因此回调内严禁启动这些副作用。确认弹窗、跳转和成功提示经 page-feedback 推迟到提交后执行。确认回调在新的同步事务中运行。

持久化原子性依赖同一 Storage 键的一次 setStorageSync；不声称跨设备/多用户幂等性。现有 store 方法返回形态保持兼容，只有新增 local-service 使用封装响应。
