// Moving a panel between actions must not move the action the coach just touched.
function preserve(page,id,operation){
  if(page._restLayoutBusy||!page.data.timerRunning||page.data.timerExerciseId===id||!id||typeof wx.createSelectorQuery!=='function'||typeof wx.pageScrollTo!=='function')return operation();
  page._restLayoutBusy=true;
  var selector='#rest-action-'+id,ran=false;
  function run(){if(ran)return;ran=true;return operation();}
  function release(){page._restLayoutBusy=false;}
  try{
    var query=wx.createSelectorQuery();if(query.in)query=query.in(page);
    query.select(selector).boundingClientRect();query.selectViewport().scrollOffset();
    query.exec(function(before){
      var rect=before&&before[0],offset=before&&before[1];
      if(page._restLayoutDisposed){release();return;}
      if(!rect||!offset){try{return run();}finally{release();}}
      var originalScroll=Number(offset.scrollTop)||0;
      try{page.holdRestViewport();run();}catch(error){release();throw error;}
      function restore(){
        if(page._restLayoutDisposed||page.data.timerExerciseId!==id||Math.abs((page._workoutScrollTop||0)-originalScroll)>2){release();return;}
        var after=wx.createSelectorQuery();if(after.in)after=after.in(page);
        after.select(selector).boundingClientRect();
        after.exec(function(rows){var next=rows&&rows[0];release();if(!next||page._restLayoutDisposed||page.data.timerExerciseId!==id||Math.abs((page._workoutScrollTop||0)-originalScroll)>2)return;var delta=next.top-rect.top;if(Math.abs(delta)>1)wx.pageScrollTo({scrollTop:Math.max(0,originalScroll+delta),duration:0});});
      }
      if(typeof wx.nextTick==='function')wx.nextTick(restore);else restore();
    });
  }catch(error){release();if(!ran)return run();throw error;}
}
module.exports=function(config){
  var unload=config.onUnload;config.onUnload=function(){this._restLayoutDisposed=true;if(unload)return unload.apply(this,arguments);};
  ['toggleDone','startRest'].forEach(function(name){var base=config[name];config[name]=function(e){var ex=this.data.exercises[Number(e.currentTarget.dataset.ei)],self=this,args=arguments;return preserve(this,ex&&ex.id,function(){return base.apply(self,args);});};});
  return config;
};
module.exports.preserve=preserve;
