// Synchronous writes use one transaction and one safe feedback contract.
var store = require('./store');
var service = require('./local-service');
var errors = require('./operation-errors');
var writes = ['hideLedger','deleteRecentCourse','deleteMember','deletePlan','deleteCanceledCourse','saveQuickExercise','confirmDeleteReport','archive','deleteExercise','removeExercise','remove','deleteEntry','deletePhoto','save','savePackage','saveGoal','saveLog','saveReport','register','gift','returnCredit','togglePause','selectPackage','confirmBooking'];
var COOLDOWN_MS = 800;
function report(page, detail, title) {
  page.setData({operationError:detail, saving:false});
  try { wx.showModal({title:title,content:detail.message + '\n' + detail.hint,showCancel:false}); }
  catch (ignored) { /* The inline error remains visible when the native modal fails. */ }
}
module.exports = function(config) {
  config.data = Object.assign({saving:false, operationError:null}, config.data || {});
  writes.forEach(function(name) {
    if (name === 'removeExercise' && config._localExerciseRemoval) return;
    var handler = config[name];
    if (typeof handler !== 'function') return;
    config[name] = function() {
      if (this._writeBusy || (this._writeUntil && Date.now() < this._writeUntil)) return false;
      var self = this, args = arguments, dataBefore;
      this._writeBusy = true;
      try {
        if (!store.coachWriteAllowed(config._feature) && name !== 'register') {
          wx.showToast({title:store.coachAccess().reason,icon:'none'});
          return false;
        }
        dataBefore = JSON.parse(JSON.stringify(this.data));
        this.setData({saving:true, operationError:null});
        var result = service.execute(function() { return handler.apply(self, args); });
        if (!result.ok) {
          this.setData(dataBefore);
          report(this, result.error, '未能保存');
          return false;
        }
        if (result.changed) this._writeUntil = Date.now() + COOLDOWN_MS;
        return result.data;
      } catch (error) {
        if (dataBefore) this.setData(dataBefore);
        report(this, errors.describe(error), '未能保存');
        return false;
      } finally {
        this._writeBusy = false;
        this.setData({saving:false});
      }
    };
  });
  Object.keys(config).forEach(function(name) {
    if (typeof config[name] !== 'function' || writes.indexOf(name) >= 0) return;
    var handler = config[name];
    config[name] = function() {
      try { return handler.apply(this, arguments); }
      catch (error) { report(this, errors.describe(error), '操作未完成'); return false; }
    };
  });
  return config;
};
