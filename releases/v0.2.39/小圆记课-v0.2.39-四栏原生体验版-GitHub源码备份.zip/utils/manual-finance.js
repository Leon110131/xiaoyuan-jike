const store = require('./store');
const errors = require('./operation-errors');
const validate = require('./validation');

function read(id, expected) {
  const row = store.byId('financialEntries', id);
  if (!row || (expected && JSON.stringify(row) !== expected)) {
    throw errors.create('CONFLICT', '记录已变化或不存在，请返回明细核对。');
  }
  return row;
}

function save(fields, id, expected) {
  if (!id) return store.saveFinancialEntry(fields);
  const row = { ...read(id, expected), ...fields, amount: Number(fields.amount) };
  validate.financial(row);
  return store.upsert('financialEntries', row);
}

function remove(id, expected) {
  read(id, expected);
  store.set('financialEntries', store.list('financialEntries').filter(row => row.id !== id));
}

function monthLabel(date) {
  const [year, month] = date.split('-');
  return year + ' 年 ' + Number(month) + ' 月';
}

module.exports = { read, save, remove, monthLabel };
