const store = require('./store');
const grid = require('./calendar-grid');
const service = require('./local-service');
const feedback = require('./page-feedback');
const records = require('./course-records');
const removal = require('./course-removal');
const errors = require('./operation-errors');
const workoutRecords = require('./workout-records');
const workoutDrafts = require('./workout-drafts');

const cancellations = [
  { mode: 'early', label: '提前取消' },
  { mode: 'late', label: '临时取消' },
  { mode: 'noShow', label: '爽约' },
  { mode: 'leave', label: '请假' }
];

function current(id) {
  const course = store.byId('courses', id);
  return course && !course.archived ? course : null;
}

function reject(message, code = 'VALIDATION') {
  throw errors.create(code, message);
}

function actions(course) {
  const scheduled = course && course.status === 'scheduled';
  const completed = course && course.status === 'completed';
  const canceled = course && ['canceled', 'leave', 'no_show'].includes(course.status);
  const supplement = completed && course.deducted === true;
  const member = supplement && store.byId('members', course.memberId);
  const hasReport = supplement ? Boolean(member && workoutRecords.linkedToCourse(course).length) :
    Boolean(course && course.workoutId);
  return {
    edit: scheduled,
    cancel: scheduled,
    debit: course && !course.deducted && (scheduled || (completed && course.autoTimeStatus)),
    remove: canceled || (completed && course.deducted && !course.recentHidden),
    refund: completed && course.deducted,
    record: supplement ? Boolean(member && !hasReport) :
      course && !course.deducted && (scheduled || (completed && course.autoTimeStatus)),
    report: hasReport,
    supplement
  };
}

function cancellationImpact(course, mode) {
  const rule = (store.get('cancelRules') || {})[mode];
  const deduct = Boolean(rule && rule.deduct && store.canUseFeature('packages', true));
  return { deduct, pack: deduct ? store.activePackages(course.memberId)[0] || null : null };
}

function balance(pack) {
  return pack.name + '，剩余 ' + pack.remaining + ' 节，扣 1 节后剩余 ' + (Number(pack.remaining) - 1) + ' 节。';
}

module.exports = function (page, isCalendar, originalData) {
  Object.assign(page.data, {
    courseActions: {}, packageChoices: [], cancelChoices: cancellations,
    writeError: '', saving: false
  });
  const openReadCourse = page.openReadCourse;
  const closeCourseDetail = page.closeCourseDetail;
  const confirmBooking = page.confirmBooking;
  const closeBookingDrawer = page.closeBookingDrawer;
  const onShow = page.onShow;
  if (isCalendar) Object.assign(page.data, {
    bookingFilters: originalData.bookingFilters, durationChoices: originalData.durationChoices,
    quickDurationLabels: originalData.durationChoices.map(value => value + ' 分钟'), quickDurationIndex: 0
  });

  Object.assign(page, {
    onShow() {
      onShow.call(this);
      if (!this._detailId || (this.data.isCoursePage && !this.data.detail)) return;
      const c = current(this._detailId);
      this.setData({ courseActions: actions(c) });
      if (this.data.panel === 'packages') this.setData({ packageChoices: c ? store.activePackages(c.memberId) : [] });
    },
    refresh() { this.loadCourses(false); },
    openReadCourse(event) {
      openReadCourse.call(this, event);
      this.setData({ courseActions: actions(this.data.detail ? current(this.data.detail.id) : null), writeError: '' });
    },
    closeCourseDetail() {
      if (this._coursePromptOpen || this.data.saving) return;
      if (['cancel', 'packages', 'transactions'].includes(this.data.panel)) {
        this.setData({ panel: 'detail', courseOptionsOpen: false, writeError: '' });
        return;
      }
      if (this.data.panel === 'quick-member') {
        this.setData({ panel: 'quick', quickMemberOpen: false });
        return;
      }
      if (this.data.panel === 'quick') {
        this.closeBookingDrawer();
        return;
      }
      closeCourseDetail.call(this);
    },
    _actionCourse(action) {
      if (!this._detailId || this._coursePromptOpen || this.data.saving) return null;
      const c = current(this._detailId);
      if (!store.coachWriteAllowed('calendar') || !c || !actions(c)[action]) {
        this.setData({ writeError: '当前课程状态已变化或无法操作，请重新打开详情。' });
        return null;
      }
      return c;
    },
    openReadForm(event) {
      const edit = event && event.currentTarget.dataset.edit;
      const c = edit ? this._actionCourse('edit') : null;
      if (edit && !c) return;
      const quick = this.data.panel === 'quick';
      const date = quick ? this.data.bookingDate : isCalendar ? this.data.date : store.formatDate(new Date());
      const query = c ? 'id=' + encodeURIComponent(c.id) : 'date=' + encodeURIComponent(date) +
        (quick ? '&time=' + encodeURIComponent(this.data.bookingTime) + '&duration=' + this.data.bookingDuration +
          (this.data.bookingMemberId ? '&memberId=' + encodeURIComponent(this.data.bookingMemberId) : '') : '');
      feedback.navigateTo({ url: '/pages/course-form/index?' + query, success: () => {
        if (quick) this.closeCourseDetail();
      } });
    },
    openReadSlot(event) {
      if (!isCalendar || this.data.panel) return;
      this.openSlot(event);
      if (!this.data.showBookingDrawer) return;
      const available = Number(event.currentTarget.dataset.minutes);
      const duration = this.data.durationChoices.filter(value => value <= available && value <= this.data.bookingDuration).pop();
      this.setData({ panel: 'quick', bookingDuration: duration || this.data.bookingDuration,
        quickDurationIndex: this.data.durationChoices.indexOf(duration || this.data.bookingDuration) });
      if (duration) this.refreshBooking();
    },
    openQuickFromToolbar() {
      if (!isCalendar || this.data.panel) return;
      this.quickAdd();
      if (this.data.showBookingDrawer) this.setData({ panel: 'quick',
        quickDurationIndex: this.data.durationChoices.indexOf(this.data.bookingDuration) });
    },
    closeBookingDrawer() {
      closeBookingDrawer.call(this);
      if (['quick', 'quick-member'].includes(this.data.panel)) this.setData({ panel: '', quickMemberOpen: false, writeError: '' });
    },
    onQuickDuration(event) {
      const index = Number(event.detail.value);
      this.setData({ quickDurationIndex: index });
      this.chooseBookingDuration({ currentTarget: { dataset: { value: this.data.durationChoices[index] } } });
    },
    openQuickMembers() { this.setData({ panel: 'quick-member', quickMemberOpen: true }); },
    pickQuickMember(event) {
      this.selectBookingMember(event);
      if (this.data.bookingMemberId === event.currentTarget.dataset.id) this.closeCourseDetail();
    },
    closeQuickLayer() { this.closeCourseDetail(); },
    saveReadQuick() {
      if (this.data.panel !== 'quick' || this.data.saving) return;
      if (confirmBooking.call(this)) {
        const start = grid.minute(this.data.bookingTime);
        this.setData({ panel: '', timelineAnchor: 'time-' + (Math.floor(start / 30) * 30) });
      }
    },
    openCancelChoices() {
      const c = this._actionCourse('cancel');
      if (!c) return;
      const cancelChoices = cancellations.map(item => Object.assign({}, item, { deduct: cancellationImpact(c, item.mode).deduct }));
      this.setData({ panel: 'cancel', courseOptionsOpen: true, cancelChoices, writeError: '' });
    },
    confirmReadCancel(event) {
      const c = this._actionCourse('cancel');
      const option = cancellations.find(item => item.mode === event.currentTarget.dataset.mode);
      if (!c || !option) return;
      const effect = cancellationImpact(c, option.mode);
      if (effect.deduct && !effect.pack) {
        this.setData({ writeError: '按当前规则需要扣 1 节，但该会员没有可用课时包。' });
        return;
      }
      const name = store.memberName(c.memberId);
      this._confirmCourse({
        title: '确认' + option.label + '？', confirmText: '确认',
        content: name + ' · ' + c.date + ' ' + c.time + '\n' +
          (effect.deduct ? '按当前规则扣课。' + balance(effect.pack) : '按当前规则，本次不扣课。')
      }, c, () => {
        if (JSON.stringify(cancellationImpact(c, option.mode)) !== JSON.stringify(effect)) {
          reject('扣课规则或课时包已变化，请重新核对。', 'CONFLICT');
        }
        return store.cancelCourse(c.id, option.mode);
      });
    },
    openDebitChoices() {
      const c = this._actionCourse('debit');
      if (!c) return;
      const packageChoices = store.activePackages(c.memberId);
      this.setData({ panel: 'packages', courseOptionsOpen: true, packageChoices,
        selectedPackageId: packageChoices.length ? packageChoices[0].id : '', writeError: '' });
    },
    openCoursePackages() {
      const c = this._actionCourse('debit');
      if (c) feedback.navigateTo({ url: '/pages/packages/index?memberId=' + encodeURIComponent(c.memberId) });
    },
    confirmReadDebit(event) {
      const c = this._actionCourse('debit');
      if (!c) return;
      const id = event.currentTarget.dataset.id;
      const pack = store.activePackages(c.memberId).find(item => item.id === id);
      if (!pack || JSON.stringify(pack) !== JSON.stringify(this.data.packageChoices.find(item => item.id === id))) {
        this.setData({ packageChoices: store.activePackages(c.memberId), selectedPackageId: '', writeError: '课时包已变化，请重新选择。' });
        return;
      }
      this._confirmCourse({
        title: '完成课程并扣课？', confirmText: '确认扣课',
        content: store.memberName(c.memberId) + ' · ' + c.date + ' ' + c.time + '\n' + balance(pack)
      }, c, () => {
        const latest = store.activePackages(c.memberId).find(item => item.id === id);
        if (JSON.stringify(latest) !== JSON.stringify(pack)) reject('课时包已变化，请重新选择。', 'CONFLICT');
        return store.completeCourse(c.id, id);
      });
    },
    confirmReadRemoval() {
      const c = this._actionCourse('remove');
      if (!c) return;
      const completed = c.status === 'completed';
      const selected = completed ? removal.readCompleted(c.id) : records.read(c.id);
      const expected = JSON.stringify(selected);
      const content = completed
        ? '原课时包核验通过后，退回原课时包 1 节，并删除课程及明确关联的训练和草稿。核验失败会停止本次删除。删除不可直接撤销，售课现金不自动退款。'
        : '移除此条取消记录及明确关联的训练和草稿。已产生的课时流水保留，不再次扣课或自动退回。不可直接撤销。';
      this._confirmCourse({
        title: completed ? '删除课程并退回课时？' : '删除取消记录？', confirmText: '确认删除',
        confirmColor: '#B33D49', content: store.memberName(c.memberId) + ' · ' + c.date + ' ' + c.time + '\n' + content
      }, c, () => {
        if (completed) removal.removeCompleted(c.id, expected);
        else records.remove(c.id, expected);
        return { ok: true, msg: completed ? '课程已删除，已退回1节' : '记录已删除' };
      }, true);
    },
    _confirmCourse(options, course, write, removed = false) {
      if (this._coursePromptOpen || this.data.saving) return;
      const expected = JSON.stringify(course);
      const prompt = {};
      this._coursePromptOpen = prompt;
      const failed = () => {
        if (this._coursePromptOpen !== prompt) return;
        this._coursePromptOpen = false;
        this.setData({ writeError: '确认框未能打开，请重试。' });
      };
      try {
        const show = this.showCourseConfirmation || wx.showModal;
        show.call(this.showCourseConfirmation ? this : wx, Object.assign({}, options, {
          fail: failed,
          success: result => {
            if (this._coursePromptOpen !== prompt) return;
            this._coursePromptOpen = false;
            if (!result.confirm) return;
            this.setData({ saving: true, writeError: '' });
            const outcome = service.execute(() => {
              store.assertCoachWrite('calendar');
              if (JSON.stringify(current(course.id)) !== expected) reject('课程资料已变化，请重新打开详情。', 'CONFLICT');
              const value = write();
              if (!value.ok) reject(value.msg);
              return value;
            });
            this.setData({ saving: false });
            if (!outcome.ok) {
              this.setData({ writeError: outcome.error.message });
              return;
            }
            const detailPanel = { panel: 'detail', courseOptionsOpen: false };
            if (removed && this.data.isCoursePage) {
              this.loadCourses(false);
              // Allow the native page-container to finish closing before returning.
              this.setData(detailPanel, () => {
                setTimeout(() => {
                  if (getCurrentPages().slice(-1)[0] === this) this.closeCourseDetail();
                }, 300);
              });
            } else {
              this.setData(detailPanel);
              if (removed) this.closeCourseDetail();
              this.loadCourses(false);
              if (!removed) this.setData({ courseActions: actions(current(course.id)) });
            }
            wx.showToast({ title: outcome.data.msg, icon: 'success' });
          }
        }));
      } catch (error) { failed(); }
    },
    openCourseTraining() {
      const c = this._actionCourse('record');
      if (!c) return;
      if (!store.byId('members', c.memberId) || (this.data.detail && this.data.detail.memberId !== c.memberId)) {
        this.setData({ writeError: '课程会员已变化，请重新打开详情。' });
        return;
      }
      let url = '/pages/workout/index?memberId=' + encodeURIComponent(c.memberId) +
        '&courseId=' + encodeURIComponent(c.id);
      if (c.status === 'completed' && c.deducted === true) {
        const draft = workoutDrafts.resumable(c.memberId, c.id)[0];
        url += '&supplementCourse=1' + (draft ? '&draftId=' + encodeURIComponent(draft.id) : '&fresh=1');
      }
      feedback.navigateTo({ url });
    },
    openCourseReport() {
      const c = current(this._detailId);
      if (c && (!this.data.detail || this.data.detail.memberId === c.memberId) && actions(c).report) {
        feedback.navigateTo({ url: '/pages/session-report/index?courseId=' + encodeURIComponent(c.id) });
      } else {
        this.setData({ writeError: '课程或训练记录已变化，请重新打开详情。' });
      }
    },
    openCourseMember() {
      const c = current(this._detailId);
      if (c && store.byId('members', c.memberId)) {
        feedback.navigateTo({ url: '/pages/member-detail/index?id=' + encodeURIComponent(c.memberId) });
      } else {
        wx.showToast({ title: '该会员资料不可用', icon: 'none' });
      }
    }
  });
  return page;
};
