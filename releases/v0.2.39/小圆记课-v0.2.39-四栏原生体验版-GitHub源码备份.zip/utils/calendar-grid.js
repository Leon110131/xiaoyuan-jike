// 周时间网格：只负责日期、时段和课程布局，业务写入沿用 store。
var START=7*60, END=23*60, STEP=30, ROW=64;
function pad(n){return ('0'+n).slice(-2);}
function dateText(d){return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());}
function at(date){var p=date.split('-');return new Date(Number(p[0]),Number(p[1])-1,Number(p[2]),12);}
function shift(date,n){var d=at(date);d.setDate(d.getDate()+n);return dateText(d);}
function minute(time){var p=time.split(':');return Number(p[0])*60+Number(p[1]);}
function time(n){return pad(Math.floor(n/60))+':'+pad(n%60);}
function week(date,courses,today){
  var d=at(date), weekday=d.getDay()||7, monday=shift(date,1-weekday), labels=['一','二','三','四','五','六','日'];
  var slots=[];for(var n=START;n<END;n+=STEP)slots.push({id:'slot-'+n,time:time(n),label:n%60===0?time(n):'',minute:n,top:(n-START)/STEP*ROW,height:ROW});
  var days=labels.map(function(label,i){
    var day=shift(monday,i),next=shift(day,1),blocks=[];
    // 将跨午夜课程切分到相应日期，超出显示范围的部分只裁切视觉。
    courses.forEach(function(c){
      if(c.status!=='scheduled'&&c.status!=='completed')return;
      var base=minute(c.time),duration=Number(c.duration)||60,begin,end;
      if(c.date===day){begin=base;end=base+duration;}
      else if(shift(c.date,1)===day && base+duration>1440){begin=0;end=base+duration-1440;}
      else return;
      if(end<=START||begin>=END)return;
      var from=Math.max(begin,START),to=Math.min(end,END);
      blocks.push({id:c.id,memberId:c.memberId,name:c.memberName||'',initial:(c.memberName||'会').substring(0,1),title:c.title||'私教训练',time:c.time,endTime:time((base+duration)%1440),duration:duration,status:c.status,top:(from-START)/STEP*ROW,height:(to-from)/STEP*ROW,start:from,end:to,compact:to-from<45,continued:c.date!==day});
    });
    blocks.sort(function(a,b){return a.start-b.start||a.end-b.end;});
    // 历史数据可能已有冲突，分列显示避免课程互相遮挡。
    var group=[],groupEnd=-1;
    function flush(){var ends=[],lanes=0;group.forEach(function(b){var lane=0;while(lane<ends.length&&ends[lane]>b.start)lane++;ends[lane]=b.end;b.lane=lane;lanes=Math.max(lanes,lane+1);});group.forEach(function(b){b.left=b.lane/lanes*100;b.width=100/lanes;});group=[];}
    blocks.forEach(function(b){if(group.length&&b.start>=groupEnd)flush();group.push(b);groupEnd=Math.max(group.length===1?b.end:groupEnd,b.end);});if(group.length)flush();
    return {date:day,day:Number(day.slice(8)),label:label,isToday:day===today,selected:day===date,slots:slots,blocks:blocks};
  });
  return {start:monday,end:shift(monday,6),days:days,slots:slots,height:slots.length*ROW,label:monday.slice(5).replace('-','/')+' — '+shift(monday,6).slice(5).replace('-','/')};
}
module.exports={week:week,shift:shift,minute:minute,time:time,start:START,end:END};
