// 人类可读报告使用统一层级；JSON 和 CSV 由各自序列化器处理。
var rule='────────────────────';
function polish(text){var lines=String(text||'').replace(/\r\n/g,'\n').split('\n');if(lines[1]===rule)return lines.join('\n');var title=(lines.shift()||'小圆记课').replace(/^【|】$/g,'');var out=[title,rule];lines.forEach(function(line){if(/^[一二三四五六七八九十]+、/.test(line)){out.push('【'+line+'】',rule);}else if(/^【.+】$/.test(line)){out.push('',line,rule);}else out.push(line);});return out.join('\n').replace(/\n{3,}/g,'\n\n').trim();}
module.exports={polish:polish,rule:rule};
