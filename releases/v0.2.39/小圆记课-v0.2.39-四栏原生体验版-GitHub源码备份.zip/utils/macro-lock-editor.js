// Numeric draft belongs to this editor only; confirming is the sole lock commit.
var engine=require('./tdee-plan'),feedback=require('./page-feedback');
module.exports=function(config){
  config.data=Object.assign({},config.data,{lockPreview:'待填写',lockPreviewHint:'目标热量在下一步确认',lockCompact:false});
  config.keepLockLayer=function(){};
  config.openLock=function(e){
    var key=e.currentTarget.dataset.key,m=this.data.macroOptions.filter(function(x){return x.key===key;})[0];
    if(!m)return;
    if(!this.data.locks[key]&&this.data.lockCount>=2){feedback.showToast({title:'最多锁定两项，请先解除一项',icon:'none'});return;}
    var lock=this.data.locks[key];this._lockViewportHeight=0;var viewport=this.lockViewportHeight();
    this._lockDraft=lock?String(lock.value):'';
    this._lockIgnoreBlur=false;
    this.setData({lockModal:true,lockKey:key,lockName:m.name,lockMode:lock?lock.mode:'percent',lockValue:this._lockDraft,lockError:'',lockKeyboardHeight:0,lockDialogMaxHeight:viewport-24,lockCompact:viewport<480});
    this.refreshLockPreview();
  };
  config.setLockMode=function(e){
    var mode=e.currentTarget.dataset.mode;if(['percent','grams'].indexOf(mode)<0||mode===this.data.lockMode)return;
    // A blur event from the old mode must not overwrite the new draft.
    this._lockIgnoreBlur=true;this._lockDraft='';
    this.setData({lockMode:mode,lockValue:'',lockError:''});this.refreshLockPreview();
  };
  config.onLockValue=function(e){
    if(!this.data.lockModal)return;
    var value=String(e.detail.value);this._lockIgnoreBlur=false;this._lockDraft=value;
    this.setData({lockValue:value,lockError:''});this.refreshLockPreview();
    return value;
  };
  config.blurLockInput=function(e){
    if(!this.data.lockModal||this._lockIgnoreBlur)return;
    if(e.detail&&typeof e.detail.value==='string'&&e.detail.value!==this._lockDraft)this.onLockValue(e);
  };
  config.focusLockInput=function(e){this.keepInputKeyboard();if(e.detail&&e.detail.height)this.onLockKeyboard(e);};
  config.onLockKeyboard=function(e){
    if(!this.data.lockModal)return;
    var viewport=this.lockViewportHeight(),height=Math.max(0,Math.min(Number(e.detail&&e.detail.height)||0,viewport-100));
    this.setData({lockKeyboardHeight:height,lockDialogMaxHeight:Math.max(100,viewport-height-24),lockCompact:viewport-height<480});
  };
  config.refreshLockPreview=function(){
    var raw=this._lockDraft===undefined?String(this.data.lockValue):this._lockDraft,n=Number(raw),mode=this.data.lockMode,factor=this.data.lockKey==='fat'?9:4;
    var preview='待填写',hint='目标热量在下一步确认';
    if(raw.trim()!==''&&Number.isFinite(n)&&n>=0&&n<=(mode==='percent'?100:1500)){
      if(mode==='grams'){preview=+(n*factor).toFixed(1)+' kcal';hint='按每克 '+factor+' kcal 换算';}
      else{try{if(!this.data.goal)throw Error('no goal');var r=engine.calculate(this.data.form,this.data.goal,this.data.adjustment,{}),cal=r.kcal*n/100;preview=+(cal/factor).toFixed(1)+' g · '+cal.toFixed(0)+' kcal';hint='按本次每日目标 '+r.kcal+' kcal 换算';}catch(ignore){preview=n+'% 每日目标热量';}}
    }
    this.setData({lockPreview:preview,lockPreviewHint:hint});
  };
  config.closeLock=function(){this._lockDraft=undefined;this._lockIgnoreBlur=true;this.setData({lockModal:false,lockError:'',lockKeyboardHeight:0,lockCompact:false});this.finishKeyboardEditing();};
  config.confirmLock=function(){
    if(!this.data.lockModal)return;
    try{var locks=JSON.parse(JSON.stringify(this.data.locks));locks[this.data.lockKey]={mode:this.data.lockMode,value:this._lockDraft===undefined?this.data.lockValue:this._lockDraft};engine.validateLocks(locks);
      this.setData({locks:locks,result:null,syncHint:''});this.closeLock();this.refreshLocks();
    }catch(error){this.setData({lockError:error.message});}
  };
  config.unlock=function(){if(!this.data.lockModal)return;var locks=JSON.parse(JSON.stringify(this.data.locks));delete locks[this.data.lockKey];this.setData({locks:locks,result:null,syncHint:''});this.closeLock();this.refreshLocks();};
  var hide=config.onHide,unload=config.onUnload;
  config.onHide=function(){if(this.data.lockModal)this.closeLock();if(hide)return hide.apply(this,arguments);};
  config.onUnload=function(){if(this.data.lockModal)this.closeLock();if(unload)return unload.apply(this,arguments);};
  return config;
};
