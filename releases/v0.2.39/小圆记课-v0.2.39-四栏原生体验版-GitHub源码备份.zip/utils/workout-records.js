var s=require('./store');
function read(id){var row=s.byId('workouts',id);if(!row)throw Error('训练记录已不存在，请返回刷新。');return row;}
function check(id,expected){var row=read(id);if(JSON.stringify(row)!==expected)throw Error('训练记录已发生变化，请返回重新打开，避免覆盖其他修改。');return row;}
function linkedToCourse(course, workouts = s.list('workouts')) {
  return workouts.filter(row => row.memberId === course.memberId && !row.standalone &&
    (row.courseId === course.id || (!row.courseId && row.id === course.workoutId)));
}
function draft(row,library){var arr=[];(row.sets||[]).forEach(function(st){var key=st.exerciseInstanceId||st.exerciseId||st.exerciseName||'未命名动作',ex=arr.filter(function(x){return x._key===key;})[0];if(!ex){var source=library.filter(function(x){return st.exerciseId?x.id===st.exerciseId:x.name===st.exerciseName;})[0]||{};ex={_key:key,id:st.exerciseInstanceId||s.uid('we'),exerciseId:st.exerciseId||'',name:st.exerciseName||'未命名动作',imagePath:st.exerciseImage||source.imagePath||'',group:st.exerciseGroup||source.group||'未分类',defaultReps:source.defaultReps||'',defaultIntensity:source.intensity||'',defaultRest:st.rest===undefined?0:st.rest,sets:[],expanded:true};arr.push(ex);}var copy=Object.assign({},st);copy.id=copy.id||s.uid('set');if(copy.weightBlank)copy.weight='';if(copy.repsBlank)copy.reps='';copy.restCustomized=true;ex.sets.push(copy);});return arr;}
function remove(id,expected){return s.transaction(function(){s.assertCoachWrite();check(id,expected);s.set('workouts',s.list('workouts').filter(function(w){return w.id!==id;}));var courses=s.list('courses'),changed=false;courses.forEach(function(c){if(c.workoutId===id){c.workoutId='';changed=true;}});if(changed)s.set('courses',courses);});}
module.exports={read:read,check:check,draft:draft,remove:remove,linkedToCourse:linkedToCourse};
