var audio=null;
function arm(){try{if(typeof wx.prepareRestCue==='function'){wx.prepareRestCue();return;}if(!audio&&typeof wx.createInnerAudioContext==='function'){audio=wx.createInnerAudioContext();audio.src='/assets/audio/rest-end.wav';audio.obeyMuteSwitch=false;if(audio.onError)audio.onError(function(){wx.showToast({title:'休息结束，提示音未能播放',icon:'none'});});}}catch(error){}}
function ring(){arm();try{if(typeof wx.playRestCue==='function')wx.playRestCue();else if(audio){if(audio.stop)audio.stop();audio.play();}if(typeof wx.vibrateShort==='function')wx.vibrateShort({type:'light'});}catch(error){wx.showToast({title:'组间休息结束',icon:'none'});}}
function close(){if(audio){audio.destroy();audio=null;}}
module.exports={arm:arm,ring:ring,close:close};
