// 绝对截止时间避免页面切后台后累积计时偏差；完成事件只触发一次。
function Clock(now){this.now=now||Date.now;this.active=false;this.paused=false;this.remaining=0;this.deadline=0;}
Clock.prototype.start=function(seconds){if(!Number.isInteger(seconds)||seconds<1||seconds>3600)throw Error('休息时间应为1至3600秒。');var at=this.now();this.active=true;this.paused=false;this.remaining=seconds;this.deadline=at+seconds*1000;return this.tick(at);};
// Keep the fractional remainder internally; only the displayed countdown rounds up.
Clock.prototype.tick=function(at){at=at===undefined?this.now():at;var ended=false;if(this.active&&!this.paused){this.remaining=Math.max(0,(this.deadline-at)/1000);}if(this.active&&this.remaining===0){this.active=false;ended=true;}var seconds=Math.ceil(this.remaining);return {remaining:seconds,running:this.active,paused:this.paused,ended:ended,sampledAt:at,label:('0'+Math.floor(seconds/60)).slice(-2)+':'+('0'+seconds%60).slice(-2)};};
Clock.prototype.pause=function(at){at=at===undefined?this.now():at;var state=this.tick(at);if(state.ended)return state;if(this.active)this.paused=true;return this.tick(at);};
Clock.prototype.resume=function(at){at=at===undefined?this.now():at;if(this.active&&this.paused){this.deadline=at+Math.round(this.remaining*1000);this.paused=false;}return this.tick(at);};
Clock.prototype.adjust=function(delta,at){if(this.active){if(this.paused)this.remaining=Math.max(0,this.remaining+delta);else this.deadline+=delta*1000;}return this.tick(at);};
Clock.prototype.stop=function(){this.active=false;this.paused=false;this.remaining=0;return this.tick();};
module.exports=Clock;
