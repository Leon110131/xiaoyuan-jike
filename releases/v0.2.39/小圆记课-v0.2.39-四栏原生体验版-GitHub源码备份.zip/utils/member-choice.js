function eligible(member) {
  return !!(member && !member.listRemoved && member.status !== '已结课' &&
    typeof member.name === 'string' && member.name.trim());
}

function describe(members) {
  const names = new Map();
  const tails = new Map();
  const key = (name, tail) => JSON.stringify([name, tail]);
  const rows = members.map(member => {
    const tail = (String(member.phone || '').match(/\d{4}$/) || [])[0] || '';
    const name = member.name;
    names.set(name, (names.get(name) || 0) + 1);
    const pair = key(name, tail);
    tails.set(pair, (tails.get(pair) || 0) + 1);
    return { id: member.id, name, tail };
  });
  return rows.map(({ id, name, tail }) => {
    const showId = names.get(name) > 1 && (!tail || tails.get(key(name, tail)) > 1);
    const label = [tail && '尾号 ' + tail, showId && '会员 ID ' + id].filter(Boolean).join(' · ');
    return { id, name, label };
  });
}

function display(row) {
  return row.label ? row.name + ' · ' + row.label : row.name;
}

module.exports = { eligible, describe, display };
