// Pure planner: deletions require registered exact content and preserve referenced user data.
var COACH=['members','packages','courses','plans','measurements','workouts','nutritionGoals','nutritionLogs','photos','reports','financialEntries','ledger'];
var PLATFORM=[];
function stable(x){if(x===null||typeof x!=='object')return JSON.stringify(x);if(Array.isArray(x))return '['+x.map(stable).join(',')+']';return '{'+Object.keys(x).sort().map(function(k){return JSON.stringify(k)+':'+stable(x[k]);}).join(',')+'}';}
function identity(k,row){return row.id||(k==='nutritionGoals'?row.memberId:'');}
function key(k,id){return k+'|'+id;}
function refs(k,row){var a=[];function ref(collection,id){if(id)a.push(key(collection,id));}
 if(COACH.indexOf(k)>=0){ref('members',row.memberId);ref('packages',row.packageId);ref('courses',row.courseId);ref('workouts',row.workoutId);ref('plans',row.planId);}
 if(PLATFORM.indexOf(k)>=0){ref('coaches',row.coachId);ref('subscriptionOrders',row.orderId);if(k==='adminWorkspaces')ref('coaches',row.id);if(k==='coaches')ref('subscriptionOrders',row.currentOrderId);}
 return a;
}
function draftReferences(state) {
 var drafts=state.workoutDrafts;
 if(drafts===undefined)return [];
 if(!Array.isArray(drafts))throw Error('训练草稿列表无法读取，暂不能核验关联。');
 var refs=[],seen=new Set();
 drafts.forEach(function(row){
  var data=row&&row.data;
  function check(ok,message){if(!ok)throw Error('训练草稿'+message+'，清理可能导致草稿无法恢复。');}
  check(data&&typeof data==='object'&&!Array.isArray(data)&&typeof row.memberId==='string'&&
    row.memberId&&data.memberId===row.memberId,'的会员关联无法核对');
  check(typeof row.workoutId==='string'&&row.workoutId&&data.workoutId===row.workoutId&&
    row.id==='draft:'+row.workoutId&&!seen.has(row.id),'的训练标识无法核对');
  check(data.editingExisting===undefined||typeof data.editingExisting==='boolean','的训练编辑状态无法核对');
  seen.add(row.id);
  check(!row.courseId||!data.courseId||row.courseId===data.courseId,'的课程标识不一致');
  function protect(collection,id,required) {
   if(id===undefined||id===null||id===''){check(!required,'缺少必要关联');return;}
   check(typeof id==='string'&&id.trim()===id,'包含无法识别的关联标识');
   var matches=(state[collection]||[]).filter(function(item){return identity(collection,item)===id;});
   check(matches.length<=1&&(!required||matches.length===1),'引用的记录缺失或不唯一');
   if(matches.length&&collection!=='members'){
    var owner=matches[0].memberId;
    check(collection==='plans'&&!owner||owner===row.memberId,'引用的记录不属于该会员');
   }
   refs.push(key(collection,id));
  }
  protect('members',row.memberId,true);
  // Historical course/plan references may remain after the source is removed.
  [row.courseId,data.courseId,row.sourceCourseId,data.sourceCourseId].forEach(function(id){protect('courses',id,false);});
  protect('workouts',row.workoutId,data.editingExisting===true);
  if(data.templateSnapshot!=null)check(typeof data.templateSnapshot==='object'&&
    typeof data.templateSnapshot.id==='string'&&data.templateSnapshot.id,'的计划快照无法核对');
  [data.planId,data.launchPlanId,data.templateSnapshot&&data.templateSnapshot.id].forEach(function(id){protect('plans',id,false);});
 });
 return refs;
}
function plan(state,domain){
 if(domain!=='coach'&&domain!=='platform')throw Error('清理范围无效');
 var collections=domain==='coach'?COACH:PLATFORM,registry=state.sampleRegistry||[];
 var remove=Object.create(null),known=0,seen=new Set(),blockedReason='';
 registry.forEach(function(entry){
  if(!entry||entry.origin!=='builtin-factory'||entry.domain!==domain||collections.indexOf(entry.collection)<0)return;
  var k=key(entry.collection,entry.id);
  if(seen.has(k))return;
  seen.add(k);
  var matches=(state[entry.collection]||[]).filter(function(x){return identity(entry.collection,x)===entry.id;});
  known+=matches.length;
  if(matches.length!==1||registry.filter(function(other){
    return other&&other.domain===domain&&other.collection===entry.collection&&other.id===entry.id;
  }).length!==1)return;
  if(stable(matches[0])===entry.fingerprint)remove[k]=true;
 });
 if(domain==='coach'){
  try{draftReferences(state).forEach(function(k){delete remove[k];});}
  catch(error){blockedReason=error.message;}
 }
 var changed=true;while(changed){changed=false;COACH.concat(PLATFORM).forEach(function(c){(state[c]||[]).forEach(function(row){if(remove[key(c,identity(c,row))])return;refs(c,row).forEach(function(k){if(remove[k]){delete remove[k];changed=true;}});});});}
 var rows=collections.map(function(c){var ids=(state[c]||[]).filter(function(x){return remove[key(c,identity(c,x))];}).map(function(x){return identity(c,x);});return {collection:c,ids:ids,count:ids.length};}),total=rows.reduce(function(n,x){return n+x.count;},0);
 return {domain:domain,rows:rows,total:blockedReason?0:total,candidateTotal:total,blockedReason:blockedReason,protectedCount:known-total};
}
module.exports={identity:identity,coach:COACH,platform:PLATFORM,stable:stable,plan:plan};
