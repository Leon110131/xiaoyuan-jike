var s=require('./store');
module.exports=function(feature,config){var load=config.onLoad,show=config.onShow;config._feature=feature;
 function check(page){var allowed=s.canUseFeature(feature,false);if(!allowed){page.setData({showQuickFinance:false,showBookingDrawer:false,showCourseDetail:false,showPackageChooser:false});if(typeof page.stopRest==='function')page.stopRest();}page.setData({featureLocked:!allowed,lockedFeature:feature,noMembers:s.list('members').length===0});return allowed;}
 config.onLoad=function(q){this._featureQuery=q||{};if(!check(this))return;this._featureInitialized=true;if(load)return load.apply(this,arguments);};
 config.onShow=function(){if(!check(this))return;if(!this._featureInitialized){this._featureInitialized=true;if(load)load.call(this,this._featureQuery||{});}if(this._awaitingFirstMember){this._awaitingFirstMember=false;if(load&&s.list("members").length)load.call(this,this._featureQuery||{});}if(show)return show.apply(this,arguments);};
 config.addFirstMember=function(){this._awaitingFirstMember=true;wx.navigateTo({url:'/pages/member-form/index'});};config.unlockFeature=function(){wx.navigateTo({url:'/pages/about-help/index'});};return config;};
