const store = require('./store');
const grid = require('./calendar-grid');
const filters = require('./calendar-filters');
const courseStatus = require('./course-status');
const courseRecords = require('./course-records');
const workoutRecords = require('./workout-records');
const workoutDrafts = require('./workout-drafts');

const weekdays = ['日', '一', '二', '三', '四', '五', '六'];
const canceled = { canceled: '已取消', leave: '请假', no_show: '爽约' };
const statuses = ['全部状态', '已预约', '待处理', '已扣课', '已取消'];
const ranges = ['日', '周', '月', '全部'];

function localDate(value) {
  const [year, month, day] = value.split('-').map(Number);
  return new Date(year, month - 1, day, 12);
}

function dateLabel(value, withWeekday = true) {
  const date = localDate(value);
  return (date.getMonth() + 1) + '月' + date.getDate() + '日' + (withWeekday ? ' 周' + weekdays[date.getDay()] : '');
}

function monthStep(value, step) {
  const date = localDate(value);
  const first = new Date(date.getFullYear(), date.getMonth() + step, 1, 12);
  const lastDay = new Date(first.getFullYear(), first.getMonth() + 1, 0).getDate();
  first.setDate(Math.min(date.getDate(), lastDay));
  return store.formatDate(first);
}

function clock(minutes) {
  return grid.time((minutes % 1440 + 1440) % 1440);
}

function courseView(course, member, workouts, drafts, now) {
  const start = Date.parse(course.date + 'T' + course.time + ':00');
  const duration = Number(course.duration);
  const end = start + duration * 60000;
  const hasInterval = Number.isFinite(start) && Number.isFinite(duration) && duration > 0;
  const debit = course.deducted === true;
  const debitKnown = typeof course.deducted === 'boolean';
  const projected = courseStatus.status(course, now);
  const cancelLabel = canceled[course.status];
  const explicitlyCompleted = course.status === 'completed' &&
    (!course.autoTimeStatus || Boolean(course.completedAt));
  const inProgress = !cancelLabel && !debit && !explicitlyCompleted && hasInterval &&
    start <= now && now < end && projected === 'scheduled';
  let label = '状态待核对';
  let filter = '';
  let tone = 'neutral';
  let priority = 3;
  if (cancelLabel) {
    label = cancelLabel; filter = '已取消';
  } else if (debit || explicitlyCompleted) {
    label = '已完成';
    filter = debit ? '已扣课' : '待处理';
    tone = debit ? 'success' : 'warning';
  } else if (inProgress) {
    label = '进行中'; filter = '已预约'; tone = 'accent'; priority = 0;
  } else if (projected === 'completed' || (projected === 'scheduled' && hasInterval && end <= now)) {
    label = '已过时待处理'; filter = '待处理'; tone = 'warning'; priority = 1;
  } else if (projected === 'scheduled') {
    label = '已预约'; filter = '已预约'; tone = 'accent';
    if (hasInterval && start > now) priority = 2;
  }
  const endMinute = grid.minute(course.time || '00:00') + duration;
  const endTime = hasInterval ? (endMinute >= 1440 ? '次日 ' : '') + clock(endMinute) : '—';
  const name = member && member.name ? member.name : '会员资料不可用';
  const savedWorkout = workoutRecords.linkedToCourse(course, workouts).length > 0;
  const draft = Boolean(member) && !cancelLabel && (debit
    ? !savedWorkout && workoutDrafts.resumable(course.memberId, course.id, drafts, workouts).length > 0
    : drafts.some(row => row.memberId === course.memberId &&
      (row.courseId === course.id || row.sourceCourseId === course.id)));
  return {
    id: course.id, memberId: course.memberId, date: course.date, time: course.time || '—', endTime,
    duration: course.duration, title: course.title || '私教训练', name, initial: member && member.name ? name.slice(-1) : '—',
    durationLabel: hasInterval ? duration + '分钟' : '时长未记录', label, filter, tone, priority,
    debitLabel: debit ? '已扣课' : debitKnown ? '未扣课' : '扣课状态待核对',
    workoutMissing: debit && !cancelLabel && !savedWorkout, hasWorkout: savedWorkout, draft,
    note: course.notes || course.note || '', dateLabel: dateLabel(course.date),
    storedStatus: course.status, status: cancelLabel ? course.status : projected
  };
}

function read(now = Date.now()) {
  const raw = courseRecords.visible(store.get('courses') || []);
  const members = new Map(store.list('members').map(row => [row.id, row]));
  const workouts = store.list('workouts');
  const drafts = store.list('workoutDrafts');
  return raw.map(row => courseView(row, members.get(row.memberId), workouts, drafts, now))
    .sort((a, b) => a.date.localeCompare(b.date) || a.time.localeCompare(b.time));
}

function today(rows, date) {
  const day = filters.apply(rows, date, '日', '全部状态');
  const current = day.reduce((best, row) => row.priority < 3 && (!best || row.priority < best.priority) ? row : best, null);
  const next = day.find(row => row.priority === 2);
  const ongoing = day.find(row => row.priority === 0);
  const pending = day.filter(row => row.filter === '待处理');
  return {
    dateLabel: dateLabel(date, false), weekday: '周' + weekdays[localDate(date).getDay()],
    count: day.length, current, other: day.filter(row => row !== current),
    next, ongoing, pending, remaining: day.filter(row => row !== next && row !== ongoing && !pending.includes(row))
  };
}

function matching(rows, status) {
  return status === 0 ? rows : rows.filter(row => row.filter === statuses[status]);
}

function withDayGaps(rows, filtered) {
  if (filtered) return rows;
  const occupied = rows.filter(row => row.filter !== '已取消').map(row => {
    const start = grid.minute(row.time);
    return { start, end: start + Number(row.duration), id: row.id };
  });
  if (occupied.some((row, index) => !Number.isFinite(row.end) || row.end <= row.start ||
      (index > 0 && row.start < occupied[index - 1].end))) return rows;
  const byId = new Map(occupied.map(row => [row.id, row]));
  return rows.map((row, index) => {
    const previous = index > 0 && byId.get(rows[index - 1].id);
    const current = byId.get(row.id);
    if (!previous || !current || previous.end >= current.start) return row;
    const minutes = current.start - previous.end;
    return Object.assign({}, row, {
      gap: { from: clock(previous.end), to: clock(current.start), minutes,
        canBook: minutes >= 30 && previous.end >= grid.start && previous.end + 30 <= grid.end }
    });
  });
}

function schedule(rows, date, mode, status, now) {
  const todayDate = store.formatDate(new Date(now));
  const selected = localDate(date);
  const selectedDay = filters.apply(rows, date, '日', '全部状态');
  const next = date === todayDate ? selectedDay.find(row => row.priority === 2) : null;
  const previousDate = grid.shift(date, -1);
  const overnight = rows.some(row => row.date === previousDate && row.filter !== '已取消' &&
    grid.minute(row.time) + Number(row.duration) > 1440);
  const day = withDayGaps(matching(selectedDay, status).map(row => Object.assign({}, row, { next: row === next })),
    status !== 0 || overnight || mode !== 'day');
  const filtered = matching(rows, status);
  const byId = new Map(filtered.map(row => [row.id, row]));
  const gridWeek = grid.week(date, filtered.map(row => Object.assign({ memberName: row.name }, row)), todayDate);
  // calendar-grid owns the time scale, clipping and overlap lanes.
  const activeDay = gridWeek.days.find(row => row.date === date);
  const slots = gridWeek.slots.map(row => Object.assign({}, row, { anchor: 'time-' + row.minute }));
  const nowMinute = new Date(now).getHours() * 60 + new Date(now).getMinutes();
  const first = slots[0];
  const currentMinute = Math.max(grid.start, Math.min(grid.end - 30, Math.floor((nowMinute - 60) / 30) * 30));
  const days = gridWeek.days.map(row => {
    const dayRows = filters.apply(filtered, row.date, '日', '全部状态');
    const count = dayRows.length;
    return { date: row.date, day: row.day, label: row.label, selected: row.selected, isToday: row.isToday, count,
      pending: dayRows.filter(item => item.filter === '待处理').length,
      marks: row.blocks.map(b => ({ id: b.id, tone: byId.get(b.id).tone,
        top: (b.top / gridWeek.height) * 100, height: Math.max(3, b.height / gridWeek.height * 100) })) };
  });
  let month = [];
  if (mode === 'month') {
    const monthStart = store.formatDate(new Date(selected.getFullYear(), selected.getMonth(), 1, 12));
    const firstDate = grid.week(monthStart, [], todayDate).start;
    const counts = new Map();
    const pending = new Map();
    filtered.forEach(row => {
      counts.set(row.date, (counts.get(row.date) || 0) + 1);
      if (row.filter === '待处理') pending.set(row.date, (pending.get(row.date) || 0) + 1);
    });
    month = Array.from({ length: 42 }, (_, i) => {
      const key = grid.shift(firstDate, i);
      return { date: key, day: Number(key.slice(8)), count: counts.get(key) || 0, pending: pending.get(key) || 0,
        outside: key.slice(0, 7) !== date.slice(0, 7), selected: key === date, isToday: key === todayDate };
    });
  }
  return {
    monthLabel: selected.getFullYear() + '年' + (selected.getMonth() + 1) + '月',
    dateLabel: dateLabel(date), shortDate: dateLabel(date, false), day, unfilteredCount: selectedDay.length, days, month,
    isToday: date === todayDate, pendingCount: day.filter(row => row.filter === '待处理').length,
    weekLabel: dateLabel(gridWeek.start, false) + '—' + dateLabel(gridWeek.end, false),
    weekCount: days.reduce((sum, row) => sum + row.count, 0), slots,
    blocks: activeDay.blocks.map(block => Object.assign({}, block, { row: byId.get(block.id) })),
    gridHeight: gridWeek.height,
    nowLine: date === todayDate && nowMinute >= grid.start && nowMinute < grid.end,
    nowTop: (nowMinute - grid.start) / 30 * first.height, nowLabel: clock(nowMinute),
    timelineAnchor: 'time-' + (date === todayDate ? currentMinute : grid.start)
  };
}

function rangeRows(rows, date, range, status) {
  const scoped = filters.apply(rows, date, ranges[range], '全部状态');
  const visible = matching(scoped, status);
  const groups = [];
  visible.forEach(row => {
    let group = groups[groups.length - 1];
    if (!group || group.date !== row.date) {
      group = { date: row.date, label: row.dateLabel, rows: [] };
      groups.push(group);
    }
    group.rows.push(row);
  });
  return { groups, rangeCount: scoped.length };
}

module.exports = { read, dateLabel, today, schedule, rangeRows, monthStep, statuses, ranges };
