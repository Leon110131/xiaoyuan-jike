// Single transaction owned by package-records.remove. Do not refund or debit
// another package when the whole source package and its history are deleted.
var local=require('./local-state');
function purge(packageId){
  var keys=['courses','workouts','workoutDrafts','ledger','financialEntries','reports'],rows={},marked={},ids={courses:Object.create(null),workouts:Object.create(null)};
  keys.forEach(function(k){rows[k]=local.get(k)||[];marked[k]=Object.create(null);});
  function related(r){return r&&typeof r==='object'&&(r.packageId===packageId||ids.courses[r.courseId]||ids.courses[r.sourceCourseId]||ids.workouts[r.workoutId]);}
  var changed=true;
  while(changed){changed=false;keys.forEach(function(k){rows[k].forEach(function(r,i){
    if(!marked[k][i]&&(related(r)||related(r.data)||(ids[k]&&ids[k][r.id]))){
      marked[k][i]=true;changed=true;
      if(ids[k]&&r.id)ids[k][r.id]=true;
      // Old courses may point to workouts which lack a reverse courseId.
      if(k==='courses'&&r.workoutId)ids.workouts[r.workoutId]=true;
    }
  });});}
  var counts={};keys.forEach(function(k){var kept=rows[k].filter(function(r,i){return !marked[k][i];});counts[k]=rows[k].length-kept.length;if(counts[k])local.set(k,kept);});
  local.set('packages',(local.get('packages')||[]).filter(function(p){return p.id!==packageId;}));
  return {packageId:packageId,deleted:counts};
}
module.exports={purge:purge};
