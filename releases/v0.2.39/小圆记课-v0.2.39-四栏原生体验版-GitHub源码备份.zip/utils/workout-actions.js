var s=require('./store'),records=require('./workout-records'),feedback=require('./page-feedback'),local=require('./local-state');
function edit(id){records.read(id);feedback.navigateTo({url:'/pages/workout/index?workoutId='+encodeURIComponent(id)});}
function remove(id,done){var row=records.read(id),expected=JSON.stringify(row);feedback.showModal({title:'删除训练记录',content:'确定删除'+s.memberName(row.memberId)+'在'+row.date+'的这条训练记录？仅删除本条训练，课程预约、扣课和收支保持不变。',confirmText:'删除',success:function(r){if(!r.confirm)return;records.remove(id,expected);local.afterCommit(function(){done();feedback.showToast({title:'训练记录已删除',icon:'none'});});}});}
module.exports={edit:edit,remove:remove};
