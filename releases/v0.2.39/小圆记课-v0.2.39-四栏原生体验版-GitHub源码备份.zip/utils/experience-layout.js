var feedback=require('./page-feedback');
function metrics(page){
 var info={},menu=null;try{info=wx.getWindowInfo?wx.getWindowInfo():(wx.getSystemInfoSync?wx.getSystemInfoSync():{});}catch(ignored){}
 try{menu=wx.getMenuButtonBoundingClientRect&&wx.getMenuButtonBoundingClientRect();}catch(ignored){}
 var status=Math.max(0,Number(info.statusBarHeight)||0),right=menu&&menu.left?Math.max(0,(info.windowWidth||375)-menu.left+8):0,nav=menu&&menu.bottom?Math.max(40,menu.bottom-status+Math.max(4,menu.top-status)):0;
 var style='--compact-status-top:'+status+'px;--compact-right:'+right+'px;--compact-nav-height:'+nav+'px;'+(info.windowHeight?'--app-window-height:'+info.windowHeight+'px;':'');
 if(page.data.compactStyle!==style)page.setData({compactStyle:style});
}
module.exports=function(kind,config){
 var load=config.onLoad,show=config.onShow,resize=config.onResize,hide=config.onHide;
 config.data=Object.assign({},config.data,{compactStyle:''});
 config.onLoad=function(){metrics(this);if(load)return load.apply(this,arguments);};
 config.onShow=function(){metrics(this);if(show)return show.apply(this,arguments);};
 config.onResize=function(){metrics(this);if(resize)return resize.apply(this,arguments);};
 if(kind==='dashboard')config.designRecordCourse=function(e){var s=require('./store');if(!s.coachWriteAllowed()){feedback.showToast({title:'当前体验账号不可用，请重新打开',icon:'none'});return;}var d=e.currentTarget.dataset;feedback.navigateTo({url:'/pages/workout/index?memberId='+d.memberId+(d.courseId?'&courseId='+d.courseId:'')});};
 if(kind==='members'){
  config.data.designFilterOpen='';config.data.designStatusOptions=['全部'].concat(config.data.statusOptions||[]);config.data.designGoalOptions=['全部'].concat(config.data.goalOptions||[]);
  config.designToggleStatus=function(){this.setData({designFilterOpen:this.data.designFilterOpen==='status'?'':'status'});};
  config.designToggleGoal=function(){this.setData({designFilterOpen:this.data.designFilterOpen==='goal'?'':'goal'});};
  config.designCloseFilters=function(){this.setData({designFilterOpen:''});};
  config.designPickStatus=function(e){this.setData({status:e.currentTarget.dataset.value,designFilterOpen:''});this.filter();};
  config.designPickGoal=function(e){this.setData({goal:e.currentTarget.dataset.value,designFilterOpen:''});this.filter();};
  var reset=config.resetFilters;config.resetFilters=function(){reset.apply(this,arguments);this.setData({designFilterOpen:''});};
  config.onHide=function(){if(this.data.designFilterOpen)this.setData({designFilterOpen:''});if(hide)return hide.apply(this,arguments);};
 }
 if(kind==='calendar'){
  var refresh=config.refresh;config.data.designListDayCounts={};config.refresh=function(){var r=refresh.apply(this,arguments),counts={};(this.data.courses||[]).forEach(function(c){counts[c.date]=(counts[c.date]||0)+1;});this.setData({designListDayCounts:counts});return r;};
  config.designChooseListStatus=function(e){var value=this.data.statusOptions[Number(e.detail.value)];if(value)this.chooseStatus({currentTarget:{dataset:{value:value}}});};
 }
 if(kind==='workout'){
  config.data.designTrainingSettingsOpen=false;config.designToggleTrainingSettings=function(){var open=!this.data.designTrainingSettingsOpen;if(!open&&wx.hideKeyboard)wx.hideKeyboard();this.setData({designTrainingSettingsOpen:open});};
 }
 return config;
};
