// 本地演示适配器：业务集合在同一 Storage 值中一次提交。不是服务端租户隔离。
var STATE_KEY = 'leonCoachExperienceStateV1';
var draft = null;
var effects = null;
var errors = require('./operation-errors');
function clone(value) { return value == null ? value : JSON.parse(JSON.stringify(value)); }
function readState() {
  try { return wx.getStorageSync(STATE_KEY); }
  catch (error) { throw errors.storage(error); }
}
function writeState(value) {
  try { wx.setStorageSync(STATE_KEY, value); }
  catch (error) { throw errors.storage(error); }
}
function state() {
  var current = readState();
  if (!current || current.schemaVersion !== 2 || !current.values || typeof current.values !== 'object' || Array.isArray(current.values) || !Number.isSafeInteger(current.revision) || current.revision < 1) {
    throw errors.create('INVALID_STATE', '本地数据格式异常，已停止写入以保护原资料。');
  }
  return current;
}
function initialize(factory, keys) {
  if (readState()) { state(); return; }
  var values=factory();
  writeState({schemaVersion:2,revision:1,values:clone(values)});
}
function get(key) { var values = draft || state().values; return Object.prototype.hasOwnProperty.call(values,key) ? clone(values[key]) : null; }
function set(key, value) {
  if (draft) { draft[key] = clone(value); return value; }
  return transaction(function() { draft[key] = clone(value); return value; });
}
function transaction(fn) {
  if (Object.prototype.toString.call(fn) === '[object AsyncFunction]') {
    throw errors.create('ASYNC_TRANSACTION', '本地事务不支持异步保存，本次操作未执行。');
  }
  if (draft) return synchronous(fn());
  var previous = state(), result;
  draft = clone(previous.values);
  effects = [];
  var committedEffects;
  try {
    result = synchronous(fn());
    if (JSON.stringify(draft) !== JSON.stringify(previous.values)) {
      writeState({schemaVersion:2,revision:previous.revision+1,values:draft});
    }
    committedEffects = effects;
  } finally { draft = null; effects = null; }
  // Durable data must not be reported as a failed save if a later UI effect fails.
  committedEffects.forEach(function(fn) {
    try { fn(); }
    catch (error) {
      try { wx.showToast({title:'操作已完成，请手动返回查看',icon:'none'}); } catch (ignored) {}
    }
  });
  return result;
}
function synchronous(result) {
  if (result && typeof result.then === 'function') {
    if (typeof result.catch === 'function') result.catch(function() {});
    throw errors.create('ASYNC_TRANSACTION', '本次异步保存未提交。');
  }
  return result;
}
function afterCommit(fn) { if(effects)effects.push(fn);else fn(); }
function setTimeoutAfterCommit(fn, delay) { afterCommit(function() { setTimeout(fn,delay); }); }
function revision() { return state().revision; }
module.exports = {initialize:initialize,get:get,set:set,transaction:transaction,revision:revision,afterCommit:afterCommit,setTimeoutAfterCommit:setTimeoutAfterCommit};
