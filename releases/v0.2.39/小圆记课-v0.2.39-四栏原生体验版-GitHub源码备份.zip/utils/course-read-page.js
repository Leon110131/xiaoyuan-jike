const store = require('./store');
const grid = require('./calendar-grid');
const view = require('./course-read-view');
const withBack = require('./back-navigation');
const withTab = require('./tab-page');
const feedback = require('./page-feedback');
const drafts = require('./workout-drafts');

module.exports = function (existing, name, tabIndex) {
  const isCalendar = name === 'calendar';
  const todayDate = () => store.formatDate(new Date());
  const page = Object.assign({}, existing, {
    // Existing write handlers remain in the source configuration for later batches.
    // The B-2 view owns its read lifecycle and binds only read actions.
    data: {
      loading: true, readError: '', today: {}, calendar: {}, date: todayDate(), mode: 'day',
      statusIndex: 0, rangeIndex: 0, statuses: view.statuses, rangeLabels: ['当日', '本周', '本月', '全部'],
      showCourseDetail: false, panel: '', detail: null, detailReadError: false,
      groups: [], rangeCount: 0, sheetScrollTop: 0, timelineAnchor: '', monthExpanded: false,
      workDrafts: [], workoutMembers: [], workoutMemberQuery: ''
    },
    onLoad() {
      if (!isCalendar) return;
      const context = getApp().globalData.workCalendar;
      if (context) this.setData(context);
    },
    onReady() {},
    onShow() {
      if (isCalendar) {
        const app = getApp();
        const jump = app.globalData.calendarFilter;
        if (jump) {
          app.globalData.calendarFilter = null;
          this._returnToRange = false;
          this._detailId = null;
          const ranges = { 日: 0, 周: 1, 月: 2, 全部: 3 };
          const statusMap = { 预约中: 1, 已完成: 3, 已取消: 4 };
          this.setData({ date: jump.date || todayDate(), mode: jump.viewMode === 'list' ? 'day' : jump.filter === '月' ? 'month' : 'week',
            statusIndex: statusMap[jump.filter] || 0, rangeIndex: ranges[jump.filter] || 0,
            panel: '', showCourseDetail: false, detail: null, timelineAnchor: '' });
          if (jump.viewMode === 'list' || jump.filter === '月' || jump.filter === '已完成') this.openRange(null, false);
        }
      }
      this.loadCourses(!this._rows);
      this._readTimer = setInterval(() => {
        if (!this.data.showCourseDetail && !this.data.readError) this.loadCourses(false);
      }, 15000);
    },
    onHide() { clearInterval(this._readTimer); },
    onUnload() {
      clearInterval(this._readTimer);
      if (!isCalendar) return;
      const { date, mode, statusIndex, rangeIndex, monthExpanded } = this.data;
      getApp().globalData.workCalendar = { date, mode, statusIndex, rangeIndex, monthExpanded };
    },
    loadCourses(showLoading = true) {
      const read = () => {
        try {
          if (!store.canUseFeature(isCalendar ? 'calendar' : 'members', false)) throw Error('当前资料不可用');
          this._rows = view.read();
          this._renderCourses(!this.data.timelineAnchor);
          this.setData({ loading: false, readError: '' });
        } catch (error) {
          const patch = { loading: false, readError: '课程资料暂未能读取' };
          if (this.data.panel === 'detail') Object.assign(patch, { detail: null, detailReadError: true });
          this.setData(patch);
        }
      };
      if (showLoading) this.setData({ loading: true, readError: '' }, read);
      else read();
    },
    retryCourses() { this.loadCourses(true); },
    _renderCourses(resetTimeline = false) {
      const rows = this._rows || [];
      const patch = {};
      if (this.data.panel === 'detail') {
        patch.detail = rows.find(row => row.id === this._detailId) || null;
        patch.detailReadError = false;
      }
      if (!isCalendar) {
        this.setData(Object.assign(patch, { today: view.today(rows, todayDate()), workDrafts: drafts.workList() }));
        return;
      }
      const calendar = view.schedule(rows, this.data.date, this.data.mode, this.data.statusIndex, Date.now());
      patch.calendar = calendar;
      if (resetTimeline) patch.timelineAnchor = calendar.timelineAnchor;
      if (this.data.panel === 'range') Object.assign(patch,
        view.rangeRows(rows, this.data.date, this.data.rangeIndex, this.data.statusIndex));
      this.setData(patch);
    },
    openCoursePage(event) {
      feedback.navigateTo({ url: '/pages/course-detail/index?id=' + encodeURIComponent(event.currentTarget.dataset.id) });
    },
    openReadCourse(event) {
      const id = event.currentTarget.dataset.id;
      this._returnToRange = this.data.panel === 'range';
      this._detailId = id;
      let detail = null;
      let unavailable = false;
      try {
        detail = view.read().find(row => row.id === id) || null;
      } catch (error) { unavailable = true; }
      this.setData({ showCourseDetail: true, panel: 'detail', detail, detailReadError: unavailable });
    },
    closeCourseDetail() {
      this._detailId = null;
      if (this.data.panel === 'detail' && this._returnToRange) {
        this._returnToRange = false;
        this.setData({ panel: 'range', detail: null, sheetScrollTop: this._rangeScrollTop || 0 });
        this._renderCourses();
        return;
      }
      this._returnToRange = false;
      // The backing page stays mounted and the sheet mask blocks its scroll.
      this.setData({ showCourseDetail: false, panel: '', detail: null });
    },
    goReadCalendar() {
      if (this._calendarOpening) return;
      this._calendarOpening = true;
      feedback.navigateTo({ url: '/pages/calendar/index', complete: () => { this._calendarOpening = false; } });
    },
    goWorkToday() {
      const pages = getCurrentPages();
      const source = pages[pages.length - 2];
      if (source && source.route === 'pages/dashboard/index') feedback.navigateBack({ delta: 1 });
      else feedback.switchTab({ url: '/pages/dashboard/index' });
    },
    startUnscheduledWorkout() {
      this.setData({ showCourseDetail: true, panel: 'members', workoutMemberQuery: '' });
      this.searchWorkoutMember({ detail: { value: '' } });
    },
    searchWorkoutMember(event) {
      const query = event.detail.value.trim().toLowerCase();
      const members = store.visibleMembers().filter(member => member.status !== '已结课' &&
        (!query || (member.name || '').toLowerCase().includes(query) || (member.phone || '').includes(query)));
      this.setData({ workoutMemberQuery: event.detail.value, workoutMembers: members });
    },
    chooseWorkoutMember(event) {
      const id = event.currentTarget.dataset.id;
      const member = store.visibleMembers().find(row => row.id === id && row.status !== '已结课');
      if (!member) {
        this.searchWorkoutMember({ detail: { value: this.data.workoutMemberQuery } });
        return wx.showToast({ title: '该会员已不可用，请重新选择', icon: 'none' });
      }
      feedback.navigateTo({ url: '/pages/workout/index?fresh=1&memberId=' + encodeURIComponent(id),
        success: () => this.closeCourseDetail() });
    },
    openWorkDraft(event) {
      const id = event.currentTarget.dataset.id;
      const draft = drafts.workList().find(row => row.id === id);
      if (!draft) {
        this.loadCourses(false);
        return wx.showToast({ title: '草稿已变化，请重新选择', icon: 'none' });
      }
      let query = 'draftId=' + encodeURIComponent(draft.id) + '&memberId=' + encodeURIComponent(draft.memberId);
      if (draft.editingExisting) query += '&workoutId=' + encodeURIComponent(draft.workoutId);
      else if (draft.courseId) query += '&courseId=' + encodeURIComponent(draft.courseId);
      feedback.navigateTo({ url: '/pages/workout/index?' + query });
    },
    selectReadMode(event) {
      const mode = event.currentTarget.dataset.mode;
      if (mode === this.data.mode || !['week', 'day', 'month'].includes(mode)) return;
      this.setData({ mode, timelineAnchor: '', monthExpanded: false });
      this._renderCourses(true);
    },
    selectReadDate(event) {
      this.setData({ date: event.currentTarget.dataset.date, timelineAnchor: '', monthExpanded: false });
      this._renderCourses(true);
    },
    pickReadDate(event) { this.selectReadDate({ currentTarget: { dataset: { date: event.detail.value } } }); },
    toggleMonthDay() { this.setData({ monthExpanded: !this.data.monthExpanded }); },
    stepReadDate(event) {
      const step = Number(event.currentTarget.dataset.step);
      if (step !== 1 && step !== -1) return;
      const { mode, date } = this.data;
      this.selectReadDate({ currentTarget: { dataset: {
        date: mode === 'month' ? view.monthStep(date, step) : grid.shift(date, step * (mode === 'week' ? 7 : 1))
      } } });
    },
    goReadToday() {
      this.selectReadDate({ currentTarget: { dataset: { date: todayDate() } } });
    },
    openRange(event, render = true) {
      this._rangeScrollTop = 0;
      this.setData({ showCourseDetail: true, panel: 'range', sheetScrollTop: 0 });
      if (render) this._renderCourses();
    },
    trackRangeScroll(event) { if (this.data.panel === 'range') this._rangeScrollTop = event.detail.scrollTop; },
    chooseReadRange(event) {
      this._rangeScrollTop = 0;
      this.setData({ rangeIndex: Number(event.detail.value), sheetScrollTop: 0 });
      this._renderCourses();
    },
    chooseReadStatus(event) {
      this._rangeScrollTop = 0;
      this.setData({ statusIndex: Number(event.detail.value), sheetScrollTop: 0 });
      this._renderCourses();
    },
    clearReadStatus() {
      this.chooseReadStatus({ detail: { value: 0 } });
    }
  });
  const wired = require('./course-write-page')(page, isCalendar, existing.data);
  return withBack('pages/' + name + '/index', isCalendar ? wired : withTab(tabIndex, wired));
};
