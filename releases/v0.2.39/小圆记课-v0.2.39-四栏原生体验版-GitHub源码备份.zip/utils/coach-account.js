// 教练手机号入口校验；真实身份校验仍由正式服务端实现。
function validPhone(value){return /^1[3-9]\d{9}$/.test(String(value||'').trim());}
module.exports={validPhone:validPhone};
