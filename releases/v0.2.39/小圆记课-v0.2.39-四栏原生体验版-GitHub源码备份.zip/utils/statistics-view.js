function yuan(amount, showPlus) {
  const value = Number(amount) || 0;
  const parts = Math.abs(value).toFixed(2).split('.');
  const sign = value < 0 ? '−' : showPlus && value > 0 ? '+' : '';
  return sign + '¥' + parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',') + '.' + parts[1];
}

function openMember(store, memberId) {
  if (!store.byId('members', memberId)) {
    wx.showToast({ title: '会员资料已不可用', icon: 'none' });
    return;
  }
  require('./page-feedback').navigateTo({ url: '/pages/member-detail/index?id=' + encodeURIComponent(memberId) });
}

function openPackage(store, packageId, memberId) {
  const pack = store.byId('packages', packageId);
  if (!pack || pack.archived || pack.memberId !== memberId || !store.byId('members', memberId)) {
    wx.showToast({ title: '关联课时包已不可用', icon: 'none' });
    return;
  }
  require('./page-feedback').navigateTo({ url: '/pages/packages/index?memberId=' + encodeURIComponent(memberId) +
    '&packageId=' + encodeURIComponent(packageId) });
}

module.exports = { yuan, openMember, openPackage };
