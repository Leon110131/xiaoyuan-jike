// Called inside store.removeMember's single durable transaction. No startup cleanup.
var local=require('./local-state');
var collections=['packages','courses','workouts','plans','workoutDrafts','measurements','nutritionGoals','nutritionLogs','photos','reports','financialEntries','ledger'];
function purge(memberId){
  var rows={},removed={},links={packageId:'packages',courseId:'courses',sourceCourseId:'courses',workoutId:'workouts',planId:'plans'};
  collections.forEach(function(key){rows[key]=local.get(key)||[];removed[key]={};});
  function belongs(row){
    if(!row||typeof row!=='object')return false;
    if(row.memberId===memberId)return true;
    return Object.keys(links).some(function(k){return row[k]&&removed[links[k]][row[k]];});
  }
  // Follow real foreign keys as well as direct membership (including old rows
  // that only carry package/course identifiers). Never match names or notes.
  var changed=true;
  while(changed){changed=false;collections.forEach(function(key){rows[key].forEach(function(row,i){
    if(!removed[key]['@'+i]&&(belongs(row)||belongs(row.data))){
      removed[key]['@'+i]=true;if(row.id)removed[key][row.id]=true;changed=true;
    }
  });});}
  var counts={};
  collections.forEach(function(key){var kept=rows[key].filter(function(row,i){return !removed[key]['@'+i];});counts[key]=rows[key].length-kept.length;if(counts[key])local.set(key,kept);});
  local.set('members',(local.get('members')||[]).filter(function(m){return m.id!==memberId;}));
  return {memberId:memberId,deleted:counts};
}
module.exports={purge:purge};
