// Count only whole elapsed seconds, complementary to the rounded-up countdown.
function Tracker(now){this.now=now||Date.now;this.startedAt=this.now();this.segment=this.startedAt;this.elapsedMs=0;this.paused=false;this.finished=false;}
Tracker.prototype.elapsed=function(deadline,at){at=at===undefined?this.now():at;var extra=this.paused||this.finished?0:Math.max(0,Math.min(at,deadline===undefined?at:deadline)-this.segment);return Math.max(0,Math.floor((this.elapsedMs+extra)/1000));};
Tracker.prototype.pause=function(deadline,at){if(this.paused||this.finished)return;at=at===undefined?this.now():at;this.elapsedMs+=Math.max(0,Math.min(at,deadline)-this.segment);this.paused=true;};
Tracker.prototype.resume=function(at){if(this.finished||!this.paused)return;this.paused=false;this.segment=at===undefined?this.now():at;};
Tracker.prototype.finish=function(deadline,at){if(!this.finished){at=at===undefined?this.now():at;if(!this.paused)this.elapsedMs+=Math.max(0,Math.min(at,deadline)-this.segment);this.finished=true;}return Math.max(0,Math.floor(this.elapsedMs/1000));};
module.exports=Tracker;
