// Read-only projections. Stored workouts and reusable templates remain independent.
function pad(n){return ('0'+n).slice(-2);}
function end(w){
 var date=w.date||'', time=w.time||'';
 if(!/^\d{4}-\d{2}-\d{2}$/.test(date))return {date:'',label:'时间未填写',key:''};
 if(!/^([01]\d|2[0-3]):[0-5]\d$/.test(time))return {date:date,label:date+' · 未记录具体时间',key:date};
 var parts=date.split('-').map(Number), t=time.split(':').map(Number), d=new Date(parts[0],parts[1]-1,parts[2],t[0],t[1]);
 d=new Date(d.getTime()+Math.max(0,Number(w.duration)||0)*60000);
 var day=d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate()), clock=pad(d.getHours())+':'+pad(d.getMinutes());
 return {date:day,label:day+' '+clock,key:day+' '+clock};
}
function period(w,e){
 var date=w.date||'',time=w.time||'',duration=w.duration;
 var validTime=/^([01]\d|2[0-3]):[0-5]\d$/;
 if(!e.date)return e.label;
 if(validTime.test(time)&&duration!==''&&duration!==undefined&&duration!==null&&isFinite(Number(duration))&&Number(duration)>=0&&e.key.length>10){
  return e.date===date?date+' · '+time+'–'+e.key.slice(11):date+' '+time+'–'+e.key;
 }
 return date+' · 未记录完整时段';
}
function decorate(w,memberName){var e=end(w), snap=w.templateSnapshot;return Object.assign({},w,{memberName:memberName,setCount:(w.sets||[]).length,endDate:e.date,endLabel:e.label,periodLabel:period(w,e),endKey:e.key,trainingTitle:snap?(snap.name+(snap.dayName?' · '+snap.dayName:'')):'自主训练'});}
function days(rows){
 var groups=[];
 rows.forEach(function(w){
  var date=w.endDate||'', group=groups[groups.length-1];
  if(!group||group.date!==date){
   group={date:date,label:date?Number(date.slice(5,7))+'月'+Number(date.slice(8,10))+'日':'日期未填写',rows:[]};
   groups.push(group);
  }
  var label=w.periodLabel, period=label.indexOf(date+' · ')===0?label.slice(date.length+3):label;
  var actions=new Set((w.sets||[]).map(function(set){return set.exerciseInstanceId||(Number.isInteger(set.exerciseOrder)?'order:'+set.exerciseOrder:set.exerciseId||set.exerciseName);}));
  group.rows.push(Object.assign({},w,{period:period,exerciseCount:actions.size}));
 });
 return groups;
}
function sort(a,b){return b.endKey.localeCompare(a.endKey)||String(b.id).localeCompare(String(a.id));}
function group(rows){var groups=[];rows.forEach(function(w){var g=groups.filter(function(x){return x.memberId===w.memberId;})[0];if(!g){g={memberId:w.memberId,memberName:w.memberName,count:0,latestEnd:'',endKey:''};groups.push(g);}g.count++;if(!g.endKey||w.endKey>g.endKey){g.endKey=w.endKey;g.latestEnd=w.endLabel;}});return groups.sort(function(a,b){return b.endKey.localeCompare(a.endKey)||a.memberName.localeCompare(b.memberName);});}
function matches(w,q){q=(q||'').toLowerCase();return [w.memberName,w.trainingTitle,w.notes||'',w.date||''].join(' ').toLowerCase().indexOf(q)>=0;}
module.exports={end:end,decorate:decorate,group:group,sort:sort,matches:matches,days:days};
