const cash = require('./cash-records');
const { yuan } = require('./statistics-view');
const money = value => Number(value || 0).toFixed(2);
const inMonth = (date, month) => String(date || '').slice(0, 7) === month;
const titles = { completed: '完成课时明细', learners: '上课会员明细', income: '确认课时收入明细' };

function load(store, kind, month, memberId) {
  if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(month)) throw Error('统计月份无效。');
  if (['sales', 'cashIncome', 'cashExpense', 'cashBalance'].includes(kind)) return cash.load(store, kind, month);
  if (!Object.prototype.hasOwnProperty.call(titles, kind)) throw Error('统计明细类型无效。');
  const packages = store.list('packages');
  const ledger = store.list('ledger');
  const completedStatus = store.list('courses').filter(c => c.status === 'completed' && (!memberId || c.memberId === memberId));
  const completed = completedStatus.filter(c => inMonth(c.date, month));
  const recognized = completedStatus.filter(c => inMonth(c.completedAt || c.date, month));

  // Keep the legacy detail rate, including historic negative amounts.
  function rate(course) {
    const entry = !course.packageId && ledger.find(row => row.courseId === course.id && row.packageId);
    const id = course.packageId || (entry && entry.packageId);
    const pack = packages.find(row => row.id === id);
    return pack && pack.total > 0 ? Number(pack.saleAmount || 0) / Number(pack.total) : 0;
  }

  const courses = (kind === 'income' ? recognized : completed).sort((a, b) => (b.date + b.time).localeCompare(a.date + a.time))
    .map(c => {
      const debitLabel = c.deducted === true ? '已扣课' : c.deducted !== false ? '扣课待核对' :
        c.autoTimeStatus && !c.completedAt ? '到期 · 未扣课' : '未扣课';
      return { id: c.id, memberId: c.memberId, name: store.memberName(c.memberId), date: c.date, time: c.time,
        title: c.title || '私教训练', deducted: c.deducted === true, debitLabel, incomeText: money(rate(c)),
        incomeDisplay: yuan(rate(c)), recognitionDate: c.completedAt || c.date,
        crossMonth: !inMonth(c.date, month) };
    });
  const counts = new Map();
  completed.forEach(c => counts.set(c.memberId, (counts.get(c.memberId) || 0) + 1));
  const members = Array.from(counts, ([id, count]) => ({ id, count, name: store.memberName(id) }));
  return { kind, month, title: titles[kind], courses, members,
    amountText: money(recognized.reduce((n, c) => n + rate(c), 0)), courseCount: completed.length, memberCount: members.length };
}

module.exports = { load };
