// Isolated local fixtures. These actions never suspend or edit real coach accounts.
var s=require('./store'),access=require('./admin-access'),KEY='leonExperienceAdminDemoV1',draft=null;
function clone(v){return JSON.parse(JSON.stringify(v));}
function ensure(){if(!access.isDeveloper())throw Error('当前环境未授权本地管理演示');}
function initial(){return {revision:1,coaches:[{id:'example_1',name:'示例教练 林教练',phone:'138****0001',status:'active',createdAt:s.dateOffset(-10),lastActive:s.dateOffset(-1),memberCount:12,courseCount:26,workoutCount:18,note:'虚构样例账号，数据不来自其他教练'},{id:'example_2',name:'示例教练 陈教练',phone:'139****0002',status:'suspended',createdAt:s.dateOffset(-30),lastActive:s.dateOffset(-15),memberCount:8,courseCount:16,workoutCount:11,note:'虚构样例账号'}],tickets:[{id:'example_ticket',coachId:'example_1',title:'课程时间显示建议',description:'希望在课程列表中显示结束时间（虚构反馈）',status:'open',priority:'normal',reply:'',createdAt:s.dateOffset(-1),updatedAt:s.dateOffset(-1)}],logs:[],requests:[]};}
function state(){ensure();if(draft)return draft;var current=wx.getStorageSync(KEY);if(!current){current=initial();wx.setStorageSync(KEY,current);}if(!current.sampleRegistry){var reference=initial(),one=current.coaches.filter(function(x){return x.id==='example_1';})[0],two=current.coaches.filter(function(x){return x.id==='example_2';})[0],anchor=one?Date.parse(one.createdAt+'T00:00:00Z')+10*86400000:two?Date.parse(two.createdAt+'T00:00:00Z')+30*86400000:NaN,delta=anchor-Date.parse(s.dateOffset(0)+'T00:00:00Z');function shift(v){if(typeof v==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(v))return new Date(Date.parse(v+'T00:00:00Z')+delta).toISOString().slice(0,10);if(Array.isArray(v))return v.map(shift);if(v&&typeof v==='object'){var out={};Object.keys(v).forEach(function(k){out[k]=shift(v[k]);});return out;}return v;}current.sampleRegistry=[];if(Number.isFinite(delta))['coaches','tickets'].forEach(function(k){reference[k].forEach(function(sample){var rows=current[k].filter(function(x){return x.id===sample.id;});if(rows.length===1&&require('./sample-plan').stable(rows[0])===require('./sample-plan').stable(shift(sample)))current.sampleRegistry.push({collection:k,id:sample.id,fingerprint:require('./sample-plan').stable(rows[0])});});});wx.setStorageSync(KEY,current);}if(current.revision<1||!Array.isArray(current.coaches)||!Array.isArray(current.tickets)||!Array.isArray(current.logs))throw Error('管理演示数据格式异常');return clone(current);}
function mutate(action,target,requestId,fn){ensure();if(!requestId)throw Error('缺少操作请求标识');if(draft)throw Error('操作尚未完成');var before=state();if(before.requests.indexOf(requestId)>=0)return before;draft=clone(before);try{fn(draft);draft.logs.unshift({id:s.uid('audit'),action:action,target:target,actor:'本地演示管理员',time:new Date().toISOString(),source:'本地演示'});draft.requests.push(requestId);draft.revision++;wx.setStorageSync(KEY,draft);return clone(draft);}finally{draft=null;}}
function coaches(){var current=state(),p=s.get('coachProfile')||{},workouts=s.list('workouts'),courses=s.list('courses');var dates=courses.map(function(c){return c.createdAt||c.date;}).concat(workouts.map(function(w){return w.date;})).sort();return [{id:'local_coach',name:p.name||'当前本机教练',phone:p.phone||'未登记',status:'active',createdAt:p.createdAt||s.dateOffset(0),lastActive:dates[dates.length-1]||'',memberCount:s.list('members').length,courseCount:courses.length,workoutCount:workouts.length,note:'来自本机教练数据；不是其他用户的云端使用统计',local:true}].concat(current.coaches);}
function tickets(){var current=state();return s.list('feedbacks').map(function(t){return {id:t.id,coachId:'local_coach',title:t.title,description:t.description,status:'open',priority:'normal',reply:'',createdAt:t.updatedAt,updatedAt:t.updatedAt,local:true};}).concat(current.tickets).map(function(t){var edit=current.tickets.filter(function(x){return x.id===t.id;})[0];return edit||t;}).filter(function(t,i,all){return all.findIndex(function(x){return x.id===t.id;})===i;});}
function readCoachReplies(){
  if(!access.isDeveloper())return [];
  var current=wx.getStorageSync(KEY);
  return current&&Array.isArray(current.tickets)?current.tickets.filter(function(row){return row.coachId==='local_coach'&&row.reply;}):[];
}
function overview(){var cs=coaches(),ts=tickets();return {coachCount:cs.length,active:cs.filter(function(c){return c.status==='active';}).length,suspended:cs.filter(function(c){return c.status==='suspended';}).length,recentActive:cs.filter(function(c){return c.lastActive>=s.dateOffset(-6);}).length,newCoaches:cs.filter(function(c){return c.createdAt>=s.dateOffset(-6);}).length,memberCount:cs.reduce(function(n,c){return n+c.memberCount;},0),courseCount:cs.reduce(function(n,c){return n+c.courseCount;},0),workoutCount:cs.reduce(function(n,c){return n+c.workoutCount;},0),openTickets:ts.filter(function(t){return t.status!=='closed';}).length,localCount:1,exampleCount:cs.length-1};}
function detail(id){var c=coaches().filter(function(c){return c.id===id;})[0];if(!c)throw Error('教练不存在');return c;}
function updateCoach(row){if(!row||['active','suspended'].indexOf(row.status)<0)throw Error('账号状态无效');if(!row.reason||!row.reason.trim()||row.reason.length>500)throw Error('请填写调整原因，最多500字');var c=detail(row.id);if(c.local)throw Error('本机教练只能查看，状态操作仅对虚构样例生效');return mutate('调整样例账号状态：'+row.reason.trim(),row.id,row.requestId,function(d){var target=d.coaches.filter(function(c){return c.id===row.id;})[0];if(target.status!==row.expectedStatus)throw Error('账号状态已变化，请刷新后重试');target.status=row.status;});}
function saveNote(row){if(!row||typeof row.note!=='string'||row.note.length>500)throw Error('管理备注最多500字');var c=detail(row.id);if(c.local)throw Error('本机教练请在个人资料中修改');return mutate('更新样例管理备注',row.id,row.requestId,function(d){d.coaches.filter(function(c){return c.id===row.id;})[0].note=row.note.trim();});}
function updateTicket(row){if(!row||['open','processing','closed'].indexOf(row.status)<0)throw Error('反馈状态无效');if(typeof row.reply!=='string'||row.reply.length>2000)throw Error('回复最多2000字');if(row.status==='closed'&&!row.reply.trim())throw Error('解决反馈前请填写处理结果');var t=tickets().filter(function(t){return t.id===row.id;})[0];if(!t)throw Error('反馈不存在');return mutate('处理反馈：'+row.status,row.id,row.requestId,function(d){var index=d.tickets.findIndex(function(t){return t.id===row.id;});var item=clone(t);item.status=row.status;item.reply=row.reply.trim();item.updatedAt=new Date().toISOString();if(index<0)d.tickets.unshift(item);else d.tickets[index]=item;});}
function logs(){return state().logs;}
function csv(rows,columns){function cell(v){var text=String(v==null?'':v);if(/^[\s]*[=+@-]/.test(text))text="'"+text;return '"'+text.replace(/"/g,'""')+'"';}return columns.map(function(c){return cell(c.label);}).join(',')+'\r\n'+rows.map(function(row){return columns.map(function(c){return cell(row[c.key]);}).join(',');}).join('\r\n');}
function planSamples(d) {
  var remove={coaches:new Set(),tickets:new Set()},stable=require('./sample-plan').stable;
  var registry=d.sampleRegistry||[];
  registry.forEach(function(e){
    if(!e||!Object.prototype.hasOwnProperty.call(remove,e.collection)||typeof e.id!=='string'||!e.id)return;
    if(registry.filter(function(r){return r&&r.collection===e.collection&&r.id===e.id;}).length!==1)return;
    var rows=d[e.collection].filter(function(x){return x&&x.id===e.id;});
    if(rows.length!==1||rows[0].local||e.id==='local_coach'||(e.collection==='tickets'&&rows[0].coachId==='local_coach'))return;
    if(stable(rows[0])===e.fingerprint)remove[e.collection].add(e.id);
  });
  var blockedReason='';
  d.tickets.forEach(function(t){
    if(!t||typeof t.coachId!=='string'||!t.coachId.trim()||t.coachId.trim()!==t.coachId){
      blockedReason='存在无法核对教练归属的反馈，请修复关联后重新预览。';
    }else if(!remove.tickets.has(t.id))remove.coaches.delete(t.coachId);
  });
  var coaches=Array.from(remove.coaches),tickets=Array.from(remove.tickets);
  return {revision:d.revision,coaches:coaches,tickets:tickets,blockedReason:blockedReason,total:blockedReason?0:coaches.length+tickets.length};
}
function previewSamples(){return planSamples(state());}
function clearSamples(options){
  var errors=require('./operation-errors');
  var p=previewSamples();
  if(!options||options.revision!==p.revision)throw errors.create('CONFLICT','数据已变化，请重新预览。');
  if(p.blockedReason)throw errors.create('VALIDATION',p.blockedReason);
  if(!p.total)return p;
  mutate('仅清除未修改的管理示例','builtin-samples',options.requestId||s.uid('cleanup_request'),function(d){
    if(d.revision!==options.revision)throw errors.create('CONFLICT','数据已变化，请重新预览。');
    var verified=planSamples(d);
    if(verified.blockedReason)throw errors.create('VALIDATION',verified.blockedReason);
    d.coaches=d.coaches.filter(function(x){return verified.coaches.indexOf(x.id)<0;});
    d.tickets=d.tickets.filter(function(x){return verified.tickets.indexOf(x.id)<0;});
  });
  return p;
}
module.exports={previewSamples:previewSamples,clearSamples:clearSamples,coaches:coaches,tickets:tickets,readCoachReplies:readCoachReplies,overview:overview,detail:detail,updateCoach:updateCoach,saveNote:saveNote,updateTicket:updateTicket,logs:logs,csv:csv};
