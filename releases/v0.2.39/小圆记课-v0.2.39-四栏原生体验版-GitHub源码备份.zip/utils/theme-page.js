var theme=require('./theme');
module.exports=function(config){config=require('./input-continuity')(require('./layer-motion')(config));var load=config.onLoad,show=config.onShow,hide=config.onHide;
if(config._feature==='backup'&&typeof config.refresh==='function'){var refresh=config.refresh;config.refresh=function(){var result=refresh.apply(this,arguments);theme.broadcast(theme.current(),this);return result;};}
config.data=Object.assign({themePaletteIcon:'/assets/themes/blue/palette.png',themeChooserOpen:false,themePopoverMaxHeight:216,themeId:'blue',themeName:'清透蓝',themePrimary:theme.palettes[0].primary,themeSoft:theme.palettes[0].soft,themeStyle:theme.palettes[0].style,themeChoices:theme.choices()},config.data||{});
config.onLoad=function(){theme.apply(this);if(load)return load.apply(this,arguments);};
config.onShow=function(){var result;if(show)result=show.apply(this,arguments);theme.apply(this);theme.nativeColors(theme.current());return result;};
config.onHide=function(){if(this.data.themeChooserOpen)this.setData({themeChooserOpen:false});if(hide)return hide.apply(this,arguments);};
config.openThemeChooser=function(){if(this.data.themeChooserOpen){this.closeThemeChooser();return;}theme.apply(this);var self=this;this.setData({themeChooserOpen:true,themePopoverMaxHeight:216});if(wx.createSelectorQuery&&wx.getSystemInfoSync){try{var height=wx.getSystemInfoSync().windowHeight;wx.createSelectorQuery().select('#theme-entry-anchor').boundingClientRect(function(rect){if(rect&&self.data.themeChooserOpen)self.setData({themePopoverMaxHeight:Math.max(72,Math.min(216,height-rect.bottom-156))});}).exec();}catch(ignore){}}};
config.closeThemeChooser=function(){this.setData({themeChooserOpen:false});};
config.themeNoop=function(){};
config.selectTheme=function(e){var id=e&&e.currentTarget&&e.currentTarget.dataset.id;try{var t=theme.save(id);theme.broadcast(t,this);this.setData({themeChooserOpen:false});}catch(error){wx.showModal({title:'主题未保存',content:'未能保存主题颜色，请检查本地存储空间后重试。当前资料与原主题保持。',showCancel:false});}};
return config;};
