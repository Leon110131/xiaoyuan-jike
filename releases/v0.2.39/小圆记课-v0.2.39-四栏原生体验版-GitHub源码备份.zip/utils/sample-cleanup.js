var local=require('./local-state'),planner=require('./sample-plan');
var labels={members:'会员',packages:'课时包',courses:'课程',plans:'计划',measurements:'体测',workouts:'训练',nutritionGoals:'营养目标',nutritionLogs:'历史营养记录',photos:'照片记录',reports:'报告',financialEntries:'收支',ledger:'课时流水'};
function state(){
 var drafts=local.get('workoutDrafts'),x={sampleRegistry:local.get('sampleRegistry')||[],workoutDrafts:drafts===null?[]:drafts};
 planner.coach.forEach(function(k){x[k]=local.get(k)||[];});
 return x;
}
function authorize(domain){if(domain!=='coach'||local.get('demoRole')!=='coach')throw Error('体验版只允许清理当前教练的示例记录');}
function register(domain,collections){authorize(domain);var registry=local.get('sampleRegistry')||[];Object.keys(collections).forEach(function(k){if(planner.coach.indexOf(k)<0)throw Error('不支持的示例集合');collections[k].forEach(function(row){var id=planner.identity(k,row);if(id&&!registry.some(function(e){return e.domain==='coach'&&e.collection===k&&e.id===id;}))registry.push({domain:'coach',collection:k,id:id,origin:'builtin-factory',fingerprint:planner.stable(row)});});});local.set('sampleRegistry',registry);}
function legacyAdopt(){if(local.get('sampleCatalogVersion')===1)return;var legacy=require('./legacy-coach-samples'),first=(local.get('members')||[]).filter(function(x){return x.id==='m_1001';})[0],course=(local.get('courses')||[]).filter(function(x){return x.id==='c_3001';})[0],anchor=first&&first.createdAt||course&&course.createdAt,delta=Date.parse(anchor+'T00:00:00Z')-Date.parse(legacy.anchor+'T00:00:00Z');function shift(v){if(typeof v==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(v))return new Date(Date.parse(v+'T00:00:00Z')+delta).toISOString().slice(0,10);if(Array.isArray(v))return v.map(shift);if(v&&typeof v==='object'){var a={};Object.keys(v).forEach(function(k){a[k]=shift(v[k]);});return a;}return v;}
 if(Number.isFinite(delta)){var matched={};Object.keys(legacy.collections).forEach(function(k){matched[k]=[];legacy.collections[k].forEach(function(example){var id=planner.identity(k,example),rows=(local.get(k)||[]).filter(function(x){return planner.identity(k,x)===id;});if(rows.length===1&&planner.stable(rows[0])===planner.stable(shift(example)))matched[k].push(rows[0]);});});register('coach',matched);}local.set('sampleCatalogVersion',1);}
function preview(domain){authorize(domain);var p=planner.plan(state(),'coach');p.revision=local.revision();p.rows.forEach(function(x){x.label=labels[x.collection];});return p;}
function clear(domain,revision){authorize(domain);return local.transaction(function(){
 if(revision!==local.revision())throw require('./operation-errors').create('CONFLICT','数据已变化，请重新预览。');
 var p=preview(domain);
 if(p.blockedReason)throw require('./operation-errors').create('VALIDATION',p.blockedReason);
 if(!p.total)return p;
 p.rows.forEach(function(row){if(row.count)local.set(row.collection,(local.get(row.collection)||[]).filter(function(x){return row.ids.indexOf(planner.identity(row.collection,x))<0;}));});
 var history=local.get('cleanupHistory')||[];
 history.push({id:require('./store').uid('cleanup'),domain:'coach',removed:p.total,protectedCount:p.protectedCount,createdAt:new Date().toISOString()});
 local.set('cleanupHistory',history);
 return p;
 });}
function confirm(domain,page){
 var p;
 try{p=preview(domain);}catch(e){wx.showModal({title:'暂不能安全清理',content:e.message,showCancel:false});return;}
 if(p.blockedReason){wx.showModal({title:'暂不能安全清理',content:p.blockedReason,showCancel:false});return;}
 if(!p.total){wx.showModal({title:'无需清理',content:'没有可安全清除的示例数据。自行录入、修改过、未识别或有关联的记录均保留。',showCancel:false});return;}
 wx.showModal({title:'仅清除示例数据',content:p.rows.filter(function(x){return x.count;}).map(function(x){return x.label+' '+x.count+' 条';}).join('；')+'。自行录入、修改过或有引用的记录及训练草稿均保留。只操作本机，不删除图片原文件。',confirmText:'确认清除',success:function(r){
  if(!r.confirm)return;
  try{clear(domain,p.revision);if(page.refresh)page.refresh();wx.showToast({title:'示例已清除，其余保留',icon:'none'});}
  catch(e){wx.showModal({title:'未能清除',content:e.message,showCancel:false});}
 }});
}
module.exports={register:register,legacyAdopt:legacyAdopt,preview:preview,clear:clear,confirm:confirm};
