function decorate(rows){return rows.map(function(ex){var done=0,volume=0;(ex.sets||[]).forEach(function(st){if(st.done){done++;var n=Number(st.weight)*Number(st.reps);if(isFinite(n))volume+=n;}});return Object.assign({},ex,{doneCount:done,doneVolume:Math.round(volume*100)/100,progressDots:(ex.sets||[]).map(function(st){return !!st.done;})});});}module.exports=function(config){var load=config.onLoad;config.onLoad=function(){if(!this._viewWrapped){this._viewWrapped=true;var base=this.setData;this.setData=function(patch,callback){if(patch.exercises){
  var rows=decorate(patch.exercises);
  patch=Object.assign({},patch,{
    exercises:rows,
    trainingSetCount:rows.reduce(function(n,row){return n+(row.sets||[]).length;},0),
    trainingDoneCount:rows.reduce(function(n,row){return n+row.doneCount;},0)
  });
}return base.call(this,patch,callback);};}if(load)return load.apply(this,arguments);};return config;};module.exports.decorate=decorate;
