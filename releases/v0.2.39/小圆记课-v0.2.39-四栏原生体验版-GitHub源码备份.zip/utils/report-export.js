// UTF-8文本报告：小程序生成本地文件后打开微信文件分享，网页直接下载。
module.exports=function(options){return new Promise(function(resolve,reject){
 var name=options.fileName,text=options.text;if(typeof text!=='string'||!text.trim())return reject(Error('报告内容为空。'));if(typeof name!=='string'||/[\\/]/.test(name))return reject(Error('报告文件名无效。'));
 function fail(error){reject(Error(error&&error.errMsg||'导出失败，请重试。'));}
 if(typeof wx.exportTextFile==='function'){wx.exportTextFile({fileName:name,text:text,success:function(){resolve({mode:'download-requested'});},fail:fail});return;}
 if(typeof wx.getFileSystemManager!=='function'||!wx.env||!wx.env.USER_DATA_PATH){wx.setClipboardData({data:text,success:function(){resolve({mode:'clipboard'});},fail:fail});return;}
 var path=wx.env.USER_DATA_PATH+'/'+name;try{wx.getFileSystemManager().writeFile({filePath:path,data:'\uFEFF'+text,encoding:'utf8',success:function(){try{if(typeof wx.shareFileMessage!=='function'){wx.setClipboardData({data:text,success:function(){resolve({mode:'clipboard',filePath:path});},fail:fail});return;}wx.shareFileMessage({filePath:path,fileName:name,success:function(){resolve({mode:'shared',filePath:path});},fail:function(error){if(error&&/cancel/i.test(error.errMsg||''))resolve({mode:'cancelled',filePath:path});else fail(error);}});}catch(error){reject(error);}},fail:fail});}catch(error){reject(error);}
});};
