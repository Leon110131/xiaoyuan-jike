// Refresh time-derived course labels while a visible page stays open; never debit or write data.
module.exports=function(config){var show=config.onShow,hide=config.onHide,unload=config.onUnload;
  function stop(page){if(page._timeStatusInterval&&typeof clearInterval==='function')clearInterval(page._timeStatusInterval);page._timeStatusInterval=null;}
  config.onShow=function(){if(show)show.apply(this,arguments);stop(this);var page=this;if(typeof setInterval==='function'&&typeof this.refresh==='function'&&require('./store').list('courses').some(function(c){return c.autoTimeStatus;}))this._timeStatusInterval=setInterval(function(){if(!page.data.showCourseDetail&&!page.data.showBookingDrawer&&!page.data.showForm)page.refresh();},15000);};
  config.onHide=function(){stop(this);if(hide)return hide.apply(this,arguments);};config.onUnload=function(){stop(this);if(unload)return unload.apply(this,arguments);};return config;
};
