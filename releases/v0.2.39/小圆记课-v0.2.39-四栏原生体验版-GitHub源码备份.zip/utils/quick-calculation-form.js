function message(value, rule) {
  if (value == null || value === '') return '';
  const number = Number(value);
  if (!Number.isFinite(number) || number < rule.min || number > rule.max ||
      (rule.integer && !Number.isInteger(number))) {
    return rule.message;
  }
  return '';
}

function complete(value) {
  return value != null && /^\d+(?:\.\d+)?$/.test(String(value));
}

function copy(text, successTitle) {
  wx.setClipboardData({
    data: text,
    success() { wx.showToast({ title: successTitle, icon: 'success' }); },
    fail() { wx.showToast({ title: '复制失败，请重试', icon: 'none' }); }
  });
}

module.exports = { message, complete, copy };
