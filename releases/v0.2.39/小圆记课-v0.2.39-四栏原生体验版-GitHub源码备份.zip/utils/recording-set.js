function blank(rest){return {id:require('./store').uid('set'),setType:'正式组',weight:'',reps:'',rest:rest===undefined?120:Number(rest)||0,done:false};}
function copy(previous){var out=blank(previous.restPlanned===undefined?previous.rest:previous.restPlanned);out.weight=previous.weight===undefined?'':previous.weight;out.reps=previous.reps===undefined?'':previous.reps;out.setType=previous.setType||'正式组';out.restCustomized=!!previous.restCustomized;return out;}
module.exports={blank:blank,copy:copy};
