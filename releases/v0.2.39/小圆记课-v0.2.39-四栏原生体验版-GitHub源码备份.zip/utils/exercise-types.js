var types=['杠铃','哑铃','器械','绳索','自重','体能','其它'];
var presets=require('./exercise-catalog').merge(require('./exercise-defaults'));
function preset(x){return !!x&&presets.some(function(p){return p.id===x.id;});}
function infer(x){if(x.group==='有氧'||/波比|战绳|跑步|跳绳|农夫行走|壶铃摆荡/.test(x.name||''))return '体能';var e=x.equipment||'';if(/绳索/.test(e))return '绳索';if(e==='杠铃'||e==='哑铃'||e==='自重')return e;if(/固定器械|器械|机器/.test(e))return '器械';return '其它';}
function category(x){if(x.categoryVersion===2&&types.indexOf(x.equipmentCategory)>=0)return x.equipmentCategory;if(x.custom&&!preset(x)&&types.indexOf(x.equipmentCategory)>=0){if(x.equipmentCategory==='器械'&&/绳索/.test(x.equipment||''))return '绳索';if(x.equipmentCategory==='器械'&&/壶铃|弹力带|其他|其它/.test(x.equipment||''))return infer(x);return x.equipmentCategory;}return infer(x);}
function normalize(x){var a=Object.assign({},x);a.equipmentCategory=category(a);a.categoryVersion=2;a.custom=preset(a)?false:!!a.custom;a.imagePath=require('./exercise-images').path(a);return a;}
function complete(rows){var a=(rows||[]).slice();require('./exercise-defaults').forEach(function(p){if(!a.some(function(x){return x.id===p.id;}))a.push(p);});return require('./preset-parameters').apply(require('./exercise-catalog').merge(a).map(normalize));}
module.exports={complete:complete,types:types,preset:preset,category:category,normalize:normalize};
