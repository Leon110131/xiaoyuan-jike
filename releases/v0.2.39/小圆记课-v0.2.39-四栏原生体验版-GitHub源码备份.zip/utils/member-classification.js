// One shared vocabulary for member editing, display and filtering; no startup rewrite.
var goals=['增肌','减脂','塑形','康复','运动表现','体能'],tags=['重点跟进','课时预警'];
var legacy={'增肌期':['增肌'],'减脂期':['减脂'],'塑形期':['塑形'],'增肌塑形':['增肌','塑形'],'减脂塑形':['减脂','塑形'],'减脂健康':['减脂'],'提升运动表现':['运动表现'],'体能提升':['体能'],'康复训练':['康复']};
function goalLabel(value){var a=legacy[value];return a&&a.length===1?a[0]:(value||'未设置目标');}
function matches(value,goal){return value===goal||!!(legacy[value]&&legacy[value].indexOf(goal)>=0);}
function managed(list){return (list||[]).filter(function(x){return tags.indexOf(x)>=0;});}
function mergeTags(original,choice,changed){if(!changed)return (original||[]).slice();var result=(original||[]).filter(function(t){return tags.indexOf(t)<0;});if(tags.indexOf(choice)>=0)result.push(choice);return result;}
module.exports={goals:goals,tags:tags,goalLabel:goalLabel,matches:matches,managed:managed,mergeTags:mergeTags};
