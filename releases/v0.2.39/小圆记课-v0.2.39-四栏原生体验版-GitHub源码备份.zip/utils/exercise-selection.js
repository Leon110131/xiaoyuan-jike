// Picker selections are derived from the current draft; never write saved history here.
function matches(draft,exercise){return draft.exerciseId?draft.exerciseId===exercise.id:draft.name===exercise.name;}
function mark(groups,draft){return groups.map(function(group){return Object.assign({},group,{items:group.items.map(function(ex){return Object.assign({},ex,{selected:draft.some(function(row){return matches(row,ex);})});})});});}
module.exports={matches:matches,mark:mark};
