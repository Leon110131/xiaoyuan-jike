const limits = require('./nutrition-calculators').carbLimits;

const allocation = [
  { key: 'days', suffix: 'Days', label: '天数', target: 7 },
  { key: 'carbs', suffix: 'CarbShare', label: '碳水占比', target: 100 },
  { key: 'fat', suffix: 'FatShare', label: '脂肪占比', target: 100 }
];

const dayTypes = ['high', 'mid', 'low'].map((key, index) => ({
  name: ['高碳日', '中碳日', '低碳日'][index],
  fields: allocation.map(column => ({
    key: key + column.suffix, label: column.label, type: column.key === 'days' ? 'number' : 'digit'
  }))
}));

const placeholders = {
  weight: '填写当前体重', target: '填写目标体重',
  carbCoefficient: '填写系数', proteinCoefficient: '填写系数', fatCoefficient: '填写系数',
  startCarbs: '填写起始量', decrement: '填写减少量', minimumCarbs: '填写下限',
  stages: '填写阶段数', stageDays: '填写天数', protein: '填写蛋白质', fat: '填写脂肪'
};

function totals(form) {
  return Object.fromEntries(allocation.map((column, index) => {
    const sum = dayTypes.reduce((total, day) => {
      const value = Number(form[day.fields[index].key]);
      return total + (Number.isFinite(value) ? value : 0);
    }, 0);
    return [column.key, sum];
  }));
}

function validate(kind, fields, form, submitted) {
  const fieldErrors = {};
  const distributionErrors = [];
  const sum = totals(form);
  fields.forEach(({ key }) => {
    const rule = limits[key];
    if (!rule) return;
    const raw = String(form[key] == null ? '' : form[key]).trim();
    if (!raw) {
      if (submitted) fieldErrors[key] = '请填写';
      return;
    }
    const value = Number(raw);
    if (!Number.isFinite(value) || value < rule.min || value > rule.max ||
        (rule.integer && !Number.isInteger(value))) {
      fieldErrors[key] = '请输入 ' + rule.min + '–' + rule.max + (rule.integer ? ' 的整数' : '');
    }
  });
  if (kind === 'cycle') {
    allocation.forEach((column, index) => {
      const filled = dayTypes.every(day => {
        const key = day.fields[index].key;
        return String(form[key] || '').trim() && !fieldErrors[key];
      });
      if (filled && Math.abs(sum[column.key] - column.target) > 0.00001) {
        distributionErrors.push(column.key === 'days' ? '三种日型天数须合计 7 天' : column.label + '须合计 100%');
      }
    });
  } else if (kind === 'taper' && !fieldErrors.minimumCarbs && !fieldErrors.startCarbs &&
             Number(form.startCarbs) > 0 && Number(form.minimumCarbs) > Number(form.startCarbs)) {
    fieldErrors.minimumCarbs = '碳水下限不能高于起始量';
  }
  const displayTotals = Object.fromEntries(Object.entries(sum).map(([key, value]) => [key, Number(value.toFixed(6))]));
  return { fieldErrors, distributionErrors, allocationTotals: displayTotals };
}

module.exports = { dayTypes, placeholders, validate };
