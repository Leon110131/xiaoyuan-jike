function removeCopy(path) {
  return new Promise(resolve => {
    function legacy() {
      if (typeof wx.removeSavedFile !== 'function') return resolve();
      try { wx.removeSavedFile({ filePath: path, complete: resolve }); }
      catch (error) { resolve(); }
    }
    try {
      const fs = typeof wx.getFileSystemManager === 'function' && wx.getFileSystemManager();
      if (fs && fs.unlink) {
        fs.unlink({ filePath: path, success: resolve, fail: legacy });
        return;
      }
    } catch (error) {}
    legacy();
  });
}

function discard(paths) { return Promise.all(paths.map(removeCopy)); }

function save(path, filePath) {
  return new Promise((resolve, reject) => {
    if (typeof path !== 'string' || !path) return reject(Error('没有获取到照片文件'));
    const options = {
      tempFilePath: path,
      success: result => result && result.savedFilePath ? resolve(result.savedFilePath) : reject(Error('照片未保存，请重新选择')),
      fail: () => reject(Error('照片无法保存，请检查本机空间和权限'))
    };
    const fs = typeof wx.getFileSystemManager === 'function' && wx.getFileSystemManager();
    if (filePath) options.filePath = filePath;
    if (fs && fs.saveFile) fs.saveFile(options);
    else if (!filePath && typeof wx.saveFile === 'function') wx.saveFile(options);
    else reject(Error('当前微信环境不支持保存照片'));
  });
}

async function saveAll(files) {
  if (!Array.isArray(files) || files.length < 1 || files.length > 3) throw Error('请选择 1–3 张照片');
  const root = wx.env && wx.env.USER_DATA_PATH;
  if (!root) throw Error('当前微信环境不支持保存照片');
  const batch = 'photo-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2);
  const destinations = [];
  const saved = [];
  try {
    for (const file of files) {
      const extension = (String(file.tempFilePath || '').match(/\.[a-z0-9]{1,5}$/i) || ['.jpg'])[0];
      // Explicit destinations keep rollback isolated even when the same image is selected again.
      const destination = root + '/' + batch + '-' + destinations.length + extension;
      destinations.push(destination);
      saved.push({ path: await save(file.tempFilePath, destination), size: Number(file.size) || 0 });
    }
    return saved;
  } catch (error) {
    await discard(destinations);
    throw error;
  }
}

module.exports = { save, saveAll, discard };
