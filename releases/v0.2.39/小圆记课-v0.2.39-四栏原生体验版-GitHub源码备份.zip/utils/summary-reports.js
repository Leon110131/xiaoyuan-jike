const store = require('./store');
const errors = require('./operation-errors');
const layout = require('./report-layout');
const { yuan } = require('./statistics-view');

const templates = [
  { id: 'coach', name: '教练工作简报' },
  { id: 'member', name: '会员训练复盘' },
  { id: 'business', name: '经营数据报表' }
];

function rangeFor(period, now = new Date()) {
  const end = store.formatDate(now);
  if (period === 'month') return { start: end.slice(0, 7) + '-01', end };
  const monday = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 12);
  monday.setDate(monday.getDate() - ((monday.getDay() + 6) % 7));
  return { start: store.formatDate(monday), end };
}

function generate(period, templateId, now = new Date()) {
  const { start, end } = rangeFor(period, now);
  const createdAt = store.formatDate(now);
  const title = templates.find(item => item.id === templateId).name;
  const inRange = date => date >= start && date <= end;
  const courses = store.list('courses').filter(c => inRange(c.date));
  const completed = courses.filter(c => c.status === 'completed').length;
  const workouts = store.list('workouts').filter(w => inRange(w.date)).length;
  const packages = store.list('packages');
  const packs = packages.filter(p => inRange(p.saleDate || p.createdAt || ''));
  const sum = (rows, field) => rows.reduce((total, row) => total + Number(row[field] || 0), 0);
  const sales = sum(packs, 'saleAmount');
  const week = period === 'week';
  const label = week ? start + ' 周报' : end.slice(0, 7) + ' 月报';
  const heading = '【小圆记课 · ' + label + '】\n报告类型：' + title + '\n周期：' + start + ' 至 ' + end +
    '\n生成日期：' + createdAt + '\n\n';
  let body;
  if (templateId === 'coach') {
    const members = store.list('members');
    const newMembers = members.filter(m => inRange(m.createdAt || '')).length;
    const threshold = Number((store.get('reminderRules') || {}).firstWarning || 5);
    const warnings = members.filter(m => m.status === '正常训练' && sum(store.activePackages(m.id), 'remaining') <= threshold).length;
    body = [
      '一、工作概况', '会员档案总数：' + members.length + ' 位', '本期新增会员：' + newMembers + ' 位',
      '本期预约课程：' + courses.length + ' 节', '本期完成课程：' + completed + ' 节',
      '本期训练记录：' + workouts + ' 条', '课时预警会员：' + warnings + ' 位', '',
      '二、下阶段待办', '1. 跟进课时不足会员', '2. 检查尚未补全的训练记录', '3. 按阶段计划安排体测复盘'
    ];
  } else if (templateId === 'member') {
    const measurements = store.list('measurements').filter(m => inRange(m.date)).length;
    const nutrition = store.list('nutritionLogs').filter(n => inRange(n.date));
    const adherence = nutrition.length ? Math.round(sum(nutrition, 'adherence') / nutrition.length) : 0;
    body = [
      '一、训练执行', '完成课程：' + completed + ' 节', '训练记录：' + workouts + ' 条', '体测记录：' + measurements + ' 次',
      '', '二、营养跟踪', '营养记录：' + nutrition.length + ' 天', '平均执行度：' + adherence + '%',
      '', '三、教练复盘建议',
      '结合各会员的训练表现、身体数据和主观反馈，逐一确认下一阶段训练重点。本报告为汇总视图，不替代单个会员的完整阶段报告。'
    ];
  } else {
    const entries = store.list('financialEntries').filter(e => inRange(e.date));
    const manual = sum(entries.filter(e => e.type === 'income'), 'amount');
    const expense = sum(entries.filter(e => e.type === 'expense'), 'amount');
    const income = sales + manual;
    const renewals = packs.filter(p => !!p.renewal).length;
    const activeRemaining = sum(packages.filter(p => p.status === 'active'), 'remaining');
    body = [
      '一、售课与收支', '新单课时包：' + (packs.length - renewals) + ' 个', '续费课时包：' + renewals + ' 个',
      '售课记录金额：' + yuan(sales), '手工记账收入：' + yuan(manual), '本期收入：' + yuan(income),
      '本期支出：' + yuan(expense), '本期收支净额：' + yuan(income - expense), '',
      '二、课时情况', '生成时启用课包剩余：' + activeRemaining + ' 节', '',
      '售课金额取自课包登记，未经独立核实收款。'
    ];
  }

  return { id: store.uid('sumrep'), reportType: 'summary', templateId, period, startDate: start,
    endDate: end, title, createdAt, text: layout.polish(heading + body.join('\n')),
    metrics: { courses: courses.length, completed, workouts, sales } };
}

function history() {
  return store.list('reports').filter(report => report.reportType === 'summary')
    .sort((a,b) => (b.createdAt || '').localeCompare(a.createdAt || '')).slice(0, 10);
}

function read(id) {
  const row = store.byId('reports', id);
  return row && row.reportType === 'summary' ? row : null;
}

function remove(id, expected) {
  const row = read(id);
  if (!row || JSON.stringify(row) !== expected) throw errors.create('CONFLICT', '这份报告已变化，请返回历史核对。');
  store.set('reports', store.list('reports').filter(report => report.id !== id || report.reportType !== 'summary'));
}

function presentation(text) {
  const lines = typeof text === 'string' ? text.split('\n') : [];
  if (lines[1] !== layout.rule || !lines[2]?.startsWith('报告类型：') ||
      !lines[3]?.startsWith('周期：') || !lines[4]?.startsWith('生成日期：')) return null;
  const sections = [];
  let section;
  for (const line of lines.slice(5)) {
    if (!line || line === layout.rule) continue;
    const heading = line.match(/^【[一二三四五六七八九十]+、(.+)】$/);
    if (heading) {
      section = { heading: heading[1], rows: [] };
      sections.push(section);
    } else if (section) {
      const field = line.match(/^([^：]+)：(.+)$/);
      section.rows.push({ key: section.rows.length, label: field ? field[1] : '', value: field ? field[2] : line });
    } else {
      return null;
    }
  }
  return sections.length ? sections : null;
}

module.exports = { templates, rangeFor, generate, history, read, remove, presentation };
