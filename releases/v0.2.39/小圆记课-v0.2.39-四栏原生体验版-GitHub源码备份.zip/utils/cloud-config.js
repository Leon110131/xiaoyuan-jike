// v0.1固定为本地体验模式，不初始化云SDK或调用云服务。后续接入需重新开发验证。
module.exports={mode:'local',enabled:false};
