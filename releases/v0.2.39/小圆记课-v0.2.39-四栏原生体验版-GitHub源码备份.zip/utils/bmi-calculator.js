const form = require('./quick-calculation-form');
const limits = {
  height: { min: 100, max: 250, message: '身高请输入 100–250 cm' },
  weight: { min: 20, max: 400, message: '体重请输入 20–400 kg' }
};

function compute(height, weight) {
  if (String(height == null ? '' : height).trim() === '' ||
      String(weight == null ? '' : weight).trim() === '') return null;
  const error = form.message(height, limits.height) || form.message(weight, limits.weight);
  if (error) throw Error(error);
  const bmi = Number(weight) / Math.pow(Number(height) / 100, 2);
  const level = bmi < 18.5 ? 0 : bmi < 24 ? 1 : bmi < 28 ? 2 : 3;
  return { value: bmi.toFixed(2), raw: bmi, level, label: ['体重偏低', '正常范围', '超重', '肥胖'][level] };
}

module.exports = { compute, limits };
