const store = require('./store');
const feedback = require('./page-feedback');

module.exports = function confirmMemberRemoval(id, original, present) {
  const member = store.byId('members', id);
  if (!member || member.listRemoved || (original && JSON.stringify(member) !== original)) {
    feedback.showToast({ title: '会员资料已变化，请重新读取', icon: 'none' });
    return;
  }
  const expected = JSON.stringify(member);
  const match = String(member.phone || '').match(/\d{4}$/);
  const phoneTail = match ? match[0] : '';
  const identity = phoneTail ? '电话尾号 ' + phoneTail + ' · ' : '';
  const remove = () => {
    store.removeMember(id, expected);
    feedback.showToast({ title: '会员及关联记录已删除', icon: 'none' });
    feedback.switchTab({ url: '/pages/members/index' });
  };
  if (present) {
    present({ id, name: member.name, phoneTail }, remove);
    return;
  }
  feedback.showModal({
    title: '永久删除此会员？',
    content: member.name + ' · ' + identity + '会员 ID ' + id +
      '\n将删除该会员的课程、课时包、流水、训练记录与草稿、专属计划、体测、营养、照片记录、报告和关联收支，并重算统计。手机相册原图保留。此操作不可撤销。',
    confirmText: '永久删除', confirmColor: '#A2323A',
    success(result) {
      if (!result.confirm) return;
      remove();
    }
  });
};
