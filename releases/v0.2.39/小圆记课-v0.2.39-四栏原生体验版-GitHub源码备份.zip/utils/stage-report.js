const store = require('./store');
const layout = require('./report-layout');
const validate = require('./validation');

function delta(first, last, field, unit) {
  const from = Number(first && first[field]);
  const to = Number(last && last[field]);
  if (!Number.isFinite(from) || !Number.isFinite(to) || from <= 0 || to <= 0) return '暂无';
  const change = Number((to - from).toFixed(1));
  return (change > 0 ? '+' : '') + change.toFixed(1) + ' ' + unit;
}

function generate(memberId, startDate, endDate, comment) {
  validate.date(startDate, '开始日期');
  validate.date(endDate, '结束日期');
  validate.assert(startDate <= endDate, '开始日期不能晚于结束日期。');
  const member = store.byId('members', memberId);
  validate.assert(member && !member.listRemoved, '请选择有效会员。');
  const inRange = collection => store.list(collection).filter(row =>
    row.memberId === memberId && row.date >= startDate && row.date <= endDate);
  // The store inserts new records first. Preserve that order for equal dates before reversing.
  const measures = inRange('measurements').sort((a, b) => b.date.localeCompare(a.date));
  const first = measures[measures.length - 1], last = measures[0];
  const workouts = inRange('workouts');
  const courses = inRange('courses');
  const nutrition = inRange('nutritionLogs');
  const adherence = nutrition.length ? Math.round(nutrition.reduce((sum, row) => sum + Number(row.adherence || 0), 0) / nutrition.length) : 0;
  const blocks = [
    ['身体数据', [
      ['体测记录', measures.length + ' 次'], ['体重变化', delta(first, last, 'weight', 'kg')],
      ['体脂率变化', delta(first, last, 'bodyFat', '个百分点')], ['骨骼肌变化', delta(first, last, 'muscle', 'kg')],
      ['腰围变化', delta(first, last, 'waist', 'cm')]
    ]],
    ['训练执行', [
      ['训练记录', workouts.length + ' 条'], ['期间课程', courses.length + ' 节'],
      ['已完成', courses.filter(row => row.status === 'completed').length + ' 节']
    ]],
    ['营养跟踪', [['营养记录', nutrition.length + ' 条'], ['平均执行度', adherence + '%']]],
    ['教练阶段总结', [['', String(comment || '').trim() || '未填写']]]
  ];
  const sections = blocks.map(([heading, fields]) => ({ heading, rows: fields.map(([label, value], key) => ({ label, value, key })) }));
  const text = layout.polish([
    '【小圆记课 · 会员阶段报告】', '会员：' + member.name, '报告周期：' + startDate + ' 至 ' + endDate,
    ...sections.flatMap(({ heading, rows }, i) => ['', '一二三四'[i] + '、' + heading,
      ...rows.map(({ label, value }) => (label ? label + '：' : '') + value)]),
    '', '注：请教练复核报告内容后再对外分享。'
  ].join('\n'));
  return {
    id: store.uid('rep'), memberId, memberName: member.name, startDate, endDate, createdAt: store.formatDate(new Date()),
    bodyMeasures: measures.length, workoutCount: workouts.length, courseCount: courses.length, sections, text
  };
}

function read(id, memberId) {
  const row = store.byId('reports', id);
  return row && row.reportType !== 'summary' && row.memberId && (!memberId || row.memberId === memberId) ? row : null;
}

module.exports = { generate, read };
