const store = require('./store');
const records = require('./package-records');
const history = require('./ledger-history');
const service = require('./local-service');
const grid = require('./calendar-grid');
const feedback = require('./page-feedback');

function project(pack, today) {
  const statusLabels = { active: '有效', paused: '已暂停' };
  const availability = pack.startDate && pack.startDate > today ? '未开始' :
    pack.endDate && pack.endDate < today ? '已到期' : !(Number(pack.remaining) > 0) ? '余额为零' : '';
  const statusLabel = pack.status === 'active' ? availability || '有效' : statusLabels[pack.status] || '已结束';
  return Object.assign({}, pack, {
    statusLabel, availability: availability !== statusLabel ? availability : '',
    available: statusLabel === '有效', saleAmountText: Number(pack.saleAmount || 0).toFixed(2)
  });
}

function editForm(pack) {
  return { name: pack.name, type: pack.type, total: String(pack.total), saleAmount: String(pack.saleAmount || 0),
    renewal: Boolean(pack.renewal), startDate: pack.startDate, endDate: pack.endDate || '',
    saleDate: pack.saleDate || pack.createdAt || store.formatDate(new Date()) };
}

const methods = {
  pickSaleType(event) {
    this.setData({ form: Object.assign({}, this.data.form, { renewal: Number(event.detail.value) === 1 }) });
  },
  packageBack() {
    if (this.data.packageConfirm) this.closePackageConfirm();
    else if (this.data.packageTasksOpen) this.closePackageTasks();
    else if (this.data.showForm) this.closeForm();
    else if (this.data.ledgerDetail) this.closeLedgerDetail();
    else if (this.data.showLedger) this.closeLedger();
    else if (this.data.showPackageDetail) this.closePackageDetail();
    else this.requestPageLeave();
  },
  openLedger(event) {
    const id = event.currentTarget.dataset.id || '';
    this.setData({ showLedger: true, ledgerIndex: id ? this.data.packages.findIndex(pack => pack.id === id) + 1 : 0,
      ledgerPackageId: id });
    this.refreshLedger();
  },
  refreshLedger() {
    const index = this.data.packages.findIndex(pack => pack.id === this.data.ledgerPackageId);
    this.setData({ ledgerIndex: index + 1, ledgerView: history.visible(this.memberId, this.data.ledgerPackageId).sort((a, b) =>
      String(b.date || '').localeCompare(String(a.date || ''))) });
  },
  selectLedgerFilter(event) {
    const pack = this.data.packages[Number(event.detail.value) - 1];
    this.setData({ ledgerPackageId: pack ? pack.id : '' });
    this.refreshLedger();
  },
  closeLedger() { this.setData({ showLedger: false, ledgerDetail: null }); },
  openLedgerDetail(event) {
    const row = history.read(event.currentTarget.dataset.id, this.memberId);
    if (row.historyHidden) return;
    const pack = this.data.packages.find(p => p.id === row.packageId);
    const course = row.courseId && store.byId('courses', row.courseId);
    const fields = { name: '名称', type: '类型', total: '总课时', saleAmount: '售课金额', renewal: '新单／续费',
      startDate: '开始日期', endDate: '到期日期', saleDate: '售课日期' };
    this.setData({ ledgerDetail: Object.assign({}, row, {
      packageName: pack ? pack.name : '课包资料不可用',
      linkedCourse: course && !course.archived && course.memberId === this.memberId ? course.id : '',
      changeRows: Object.keys(row.changes || {}).map(key => ({ name: fields[key] || key,
        before: String(row.changes[key].before === '' ? '—' : row.changes[key].before),
        after: String(row.changes[key].after === '' ? '—' : row.changes[key].after) }))
    }) });
  },
  closeLedgerDetail() { this.setData({ ledgerDetail: null }); },
  openLedgerCourse() {
    const id = this.data.ledgerDetail && this.data.ledgerDetail.linkedCourse;
    if (id) feedback.navigateTo({ url: '/pages/course-detail/index?id=' + encodeURIComponent(id) });
  },
  reloadPackage() {
    if (this.data.reviewState === 'loaded') { this.setData({ reviewState: '' }); return; }
    try {
      const latest = records.read(this.data.editingId, this.memberId);
      const baseline = editForm(JSON.parse(this._packageSnapshot));
      const current = editForm(latest);
      const form = Object.assign({}, this.data.form);
      const conflicts = [];
      const labels = { name: '课包名称', type: '课程类型', total: '总课时', saleAmount: '售课金额',
        renewal: '售课类型', startDate: '开始日期', endDate: '到期日期', saleDate: '售课日期' };
      for (const key of Object.keys(current)) {
        if (current[key] === baseline[key]) continue;
        if (form[key] !== baseline[key] && form[key] !== current[key]) conflicts.push(labels[key]);
        form[key] = current[key];
      }
      this._packageSnapshot = JSON.stringify(latest);
      this.setData({ form, reviewState: 'loaded', conflicts, editingUsed: Number(latest.used) || 0,
        reviewedPackage: project(latest, store.formatDate(new Date())), operationError: null,
        typeIndex: Math.max(0, this.data.types.indexOf(form.type)) });
    } catch (error) {
      this.setData({ operationError: { message: error.message } });
    }
  },
  openPackageTasks() { this.setData({ packageTasksOpen: true, packageTaskError: '', extendChoicesOpen: false }); },
  closePackageTasks() { this.setData({ packageTasksOpen: false, packageTaskError: '', extendChoicesOpen: false }); },
  showExtendChoices() { this.setData({ extendChoicesOpen: true }); },
  closePackageConfirm() { this._packageAction = null; this.setData({ packageConfirm: null }); },
  previewPackageAction(event) {
    const { action, days } = event.currentTarget.dataset;
    const selected = this.data.selectedPackage;
    if (!selected || !['gift', 'return', 'extend', 'pause'].includes(action) || this.data.packageConfirm) return;
    const pack = records.read(selected.id, this.memberId);
    if (!['active', 'paused'].includes(pack.status)) {
      this.setData({ packageTaskError: '已结束的课时包不可调整。' });
      return;
    }
    const n = Number(days);
    if (action === 'extend' && ![7, 30, 90].includes(n)) return;
    if (action === 'return' && Number(pack.used || 0) < 1) {
      this.setData({ packageTaskError: '已使用课时不足，不能退回更多课时。' });
      return;
    }
    const title = action === 'pause' ? (pack.status === 'paused' ? '恢复课时包' : '暂停课时包') :
      action === 'extend' ? '延期 ' + n + ' 天' : action === 'gift' ? '赠送 1 节' : '退回 1 节课时？';
    const note = action === 'return' ? '已使用 ' + pack.used + ' → ' + (Number(pack.used) - 1) +
      ' 节\n剩余 ' + pack.remaining + ' → ' + (Number(pack.remaining) + 1) +
      ' 节，总课时 ' + pack.total + ' 节\n仅调整课时数量，不撤销课程记录，不产生现金退款。' :
      action === 'gift' ? '总课时 ' + pack.total + ' → ' + (Number(pack.total) + 1) +
        ' 节\n剩余 ' + pack.remaining + ' → ' + (Number(pack.remaining) + 1) + ' 节' :
      action === 'extend' ? '新到期日期 ' + grid.shift(pack.endDate || store.formatDate(new Date()), n) + '，课时余额保持不变。' :
      pack.status === 'paused' ? '恢复后按有效期及余额判断是否可扣课。' : '暂停期间不能扣课，余额和有效期保留。';
    this._packageAction = { action, days: n, id: pack.id, expected: JSON.stringify(pack) };
    const returnSummary = action === 'return' ? {
      name: pack.name, used: pack.used, usedAfter: Number(pack.used) - 1,
      remaining: pack.remaining, remainingAfter: Number(pack.remaining) + 1, total: pack.total
    } : null;
    this.setData({ packageConfirm: { title, content: pack.name + '\n' + note, returnSummary }, packageTaskError: '' });
  },
  commitPackageAction() {
    const pending = this._packageAction;
    if (!pending || this.data.saving) return;
    this.closePackageConfirm();
    const result = service.execute(() => {
      store.assertCoachWrite();
      records.check(pending.id, this.memberId, pending.expected);
      const outcome = pending.action === 'extend' ? store.extendPackage(pending.id, pending.days) :
        pending.action === 'pause' ? store.togglePackagePause(pending.id) :
        store.packageAdjust(pending.id, 1, pending.action === 'return' ? '退回课时' : '赠送课时',
          pending.action === 'return' ? '手动退回 1 节课时' : '教练赠送 1 节课时');
      if (!outcome.ok) throw Error(outcome.msg);
      return outcome;
    });
    this.refresh();
    if (!result.ok) { this.setData({ packageTaskError: result.error.message }); return; }
    this.closePackageTasks();
    feedback.showToast({ title: result.data.msg, icon: 'success' });
  }
};

module.exports = { project, editForm, methods, data: { saleTypes: ['新单', '续费'], usableSessions: 0, showLedger: false, ledgerPackageId: '',
  ledgerIndex: 0, ledgerFilters: [], ledgerDetail: null, reviewState: '', reviewedPackage: null, conflicts: [],
  packageTasksOpen: false, extendChoicesOpen: false, extendDays: [7, 30, 90], packageTaskError: '', packageConfirm: null } };
