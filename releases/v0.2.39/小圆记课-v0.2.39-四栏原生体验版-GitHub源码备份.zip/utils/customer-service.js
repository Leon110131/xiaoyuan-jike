// 客服通道配置：正式上线时由项目管理员在此选择实际已开通的渠道。
// miniProgram 使用 WXML 的 button open-type="contact"，并需在公众平台配置客服人员。
// wecom 需要有效的企业微信客服 corpId 与 url；请勿将密钥写入前端。
var config={mode:'unconfigured',wecomCorpId:'',wecomUrl:''};
function openWeCom(){if(!config.wecomCorpId||!config.wecomUrl){wx.showModal({title:'客服尚未配置',content:'当前尚未绑定官方客服。请先在本页保存问题反馈，一键复制后联系项目负责人。配置微信客服或企业微信客服后才能在线联系。',showCancel:false});return;}wx.openCustomerServiceChat({corpId:config.wecomCorpId,extInfo:{url:config.wecomUrl},success:function(){},fail:function(){wx.showToast({title:'暂时无法打开客服，请稍后重试',icon:'none'});}});}
module.exports={mode:config.mode,openWeCom:openWeCom};
