// Estimates / configurable arithmetic only. Never writes meals, plans or exercise data.
function n(form,key,min,max,integer){var raw=form[key];if(raw===null||raw===undefined||String(raw).trim()==='')throw Error('请完整填写所有计算参数');var v=Number(raw);if(!Number.isFinite(v)||v<min||v>max||(integer&&!Number.isInteger(v)))throw Error('参数超出范围：'+key+'（'+min+'～'+max+'）');return v;}
var tdeeLimits = {
  age: { min: 18, max: 100, integer: true, message: '年龄请输入 18–100 岁整数' },
  height: { min: 100, max: 250, message: '身高请输入 100–250 cm' },
  weight: { min: 20, max: 400, message: '体重请输入 20–400 kg' },
  activity: { min: 1, max: 2.5, message: '活动系数请输入 1–2.5' }
};
var tdeeFormula = 'Mifflin–St Jeor：10×体重kg + 6.25×身高cm − 5×年龄 + 性别常数（男5 / 女−161）；TDEE = 静息估算 × 活动系数。适用于成人估算，实际消耗可能有差异。';
function tdeeNumber(form,key) {
  var rule = tdeeLimits[key];
  return n(form,key,rule.min,rule.max,rule.integer);
}
var carbLimits = {
  weight: { min: 20, max: 400 },
  target: { min: 20, max: 400 },
  carbCoefficient: { min: 0.1, max: 15 },
  proteinCoefficient: { min: 0.1, max: 5 },
  fatCoefficient: { min: 0.1, max: 5 },
  highDays: { min: 1, max: 5, integer: true },
  midDays: { min: 1, max: 5, integer: true },
  lowDays: { min: 1, max: 5, integer: true },
  highCarbShare: { min: 1, max: 98 },
  midCarbShare: { min: 1, max: 98 },
  lowCarbShare: { min: 1, max: 98 },
  highFatShare: { min: 1, max: 98 },
  midFatShare: { min: 1, max: 98 },
  lowFatShare: { min: 1, max: 98 },
  startCarbs: { min: 1, max: 1500 },
  decrement: { min: 1, max: 300 },
  minimumCarbs: { min: 1, max: 1500 },
  stages: { min: 1, max: 12, integer: true },
  stageDays: { min: 1, max: 30, integer: true },
  protein: { min: 1, max: 500 },
  fat: { min: 1, max: 300 }
};
function carbNumber(form,key) {
  var rule = carbLimits[key];
  return n(form,key,rule.min,rule.max,rule.integer);
}
function round(v){return Math.round(v*10+1e-9)/10;}
function macro(name,days,c,p,f){return {name:name,days:days,carbs:round(c),protein:round(p),fat:round(f),kcal:Math.round(c*4+p*4+f*9)};}
function calculate(kind,a){var rows=[],summary='',formula='';
if(kind==='tdee'){var w=tdeeNumber(a,'weight'),h=tdeeNumber(a,'height'),age=tdeeNumber(a,'age'),activity=tdeeNumber(a,'activity');if(a.sex!=='male'&&a.sex!=='female')throw Error('请选择公式性别');var ree=10*w+6.25*h-5*age+(a.sex==='male'?5:-161);if(ree<=0)throw Error('参数组合无法形成有效估算');rows=[{name:'静息能量估算',value:Math.round(ree)+' kcal/日'},{name:'TDEE 每日总能量估算',value:Math.round(ree*activity)+' kcal/日'}];summary='活动系数 '+activity;formula=tdeeFormula;}
else if(kind==='cycle'){var current=carbNumber(a,'weight'),target=carbNumber(a,'target'),cc=carbNumber(a,'carbCoefficient'),pc=carbNumber(a,'proteinCoefficient'),fc=carbNumber(a,'fatCoefficient'),hd=carbNumber(a,'highDays'),md=carbNumber(a,'midDays'),ld=carbNumber(a,'lowDays');if(hd+md+ld!==7)throw Error('高、中、低碳日天数之和必须为7');var ch=carbNumber(a,'highCarbShare'),cm=carbNumber(a,'midCarbShare'),cl=carbNumber(a,'lowCarbShare'),fh=carbNumber(a,'highFatShare'),fm=carbNumber(a,'midFatShare'),fl=carbNumber(a,'lowFatShare');if(Math.abs(ch+cm+cl-100)>0.00001||Math.abs(fh+fm+fl-100)>0.00001)throw Error('碳水分配比例与脂肪分配比例必须各合计100%');var wc=target*cc*7,wf=target*fc*7,protein=current*pc;rows=[macro('高碳日',hd,wc*ch/100/hd,protein,wf*fh/100/hd),macro('中碳日',md,wc*cm/100/md,protein,wf*fm/100/md),macro('低碳日',ld,wc*cl/100/ld,protein,wf*fl/100/ld)];summary='7天总碳水 '+round(wc)+' g · 总蛋白 '+round(protein*7)+' g · 总脂肪 '+round(wf)+' g';formula='参考图参数：周碳水/脂肪 = 目标体重 × 相应g/kg系数 × 7；各类每日量 = 周总量 × 分配比例 ÷ 天数；每日蛋白 = 当前体重 × 蛋白系数；热量按蛋白/碳水4、脂肪9 kcal/g。此分配为可调整的计算模型。';}
else if(kind==='taper'){var start=carbNumber(a,'startCarbs'),step=carbNumber(a,'decrement'),minimum=carbNumber(a,'minimumCarbs'),stages=carbNumber(a,'stages'),days=carbNumber(a,'stageDays'),p=carbNumber(a,'protein'),f=carbNumber(a,'fat');if(minimum>start)throw Error('碳水下限不能高于起始量');for(var i=0;i<stages;i++){rows.push(macro('第'+(i+1)+'阶段',days,Math.max(minimum,start-step*i),p,f));}summary='每阶段 '+days+' 天 · 每阶段递减 '+step+' g · 下限 '+minimum+' g';formula='阶段碳水 = max（碳水下限，起始碳水 − 每阶段递减量 × 已递减阶段数）。蛋白质与脂肪保持输入值；仅输出参数推算，不自动安排或更改饮食。碳水渐降没有统一标准配方。';}
else throw Error('不支持的计算类型');var result={kind:kind,rows:rows,summary:summary,formula:formula};result.text=['小圆记课 · '+({tdee:'TDEE',cycle:'碳水循环',taper:'碳水渐降'}[kind]),'【输入参数】',(kind==='tdee'?'公式性别：'+(a.sex==='male'?'男性':'女性')+'\n':'')+fields[kind].map(function(f){return f[1]+'：'+a[f[0]];}).join('\n'),'【结果概览】',summary].concat(rows.map(function(r){return r.value?r.name+'：'+r.value:'【'+r.name+' × '+r.days+'天】\n每日热量：'+r.kcal+' kcal\n碳水化合物：'+r.carbs+' g/日\n蛋白质：'+r.protein+' g/日\n脂肪：'+r.fat+' g/日';})).concat(['','【计算依据】',formula]).join('\n\n');result.text=require('./report-layout').polish(result.text);return result;}
var fields={tdee:[['weight','体重 kg','72'],['height','身高 cm','175'],['age','年龄（成人）','30'],['activity','活动系数（1～2.5）','1.55']],cycle:[['weight','当前体重 kg','72'],['target','目标体重 kg','69'],['carbCoefficient','碳水系数 g/kg','3'],['proteinCoefficient','蛋白系数 g/kg','2'],['fatCoefficient','脂肪系数 g/kg','1'],['highDays','高碳日天数','2'],['midDays','中碳日天数','3'],['lowDays','低碳日天数','2'],['highCarbShare','高碳日占周碳水 %','50'],['midCarbShare','中碳日占周碳水 %','35'],['lowCarbShare','低碳日占周碳水 %','15'],['highFatShare','高碳日占周脂肪 %','15'],['midFatShare','中碳日占周脂肪 %','35'],['lowFatShare','低碳日占周脂肪 %','50']],taper:[['startCarbs','起始碳水 g/日','250'],['decrement','每阶段减少 g','20'],['minimumCarbs','碳水下限 g/日','150'],['stages','阶段数量（1～12）','6'],['stageDays','每阶段天数','7'],['protein','蛋白质 g/日','140'],['fat','脂肪 g/日','65']]};
function defaults(kind){if(!fields[kind])throw Error('计算类型不存在');var form={sex:'male'},list=fields[kind].map(function(f){form[f[0]]=f[2];return {key:f[0],label:f[1],value:f[2],advanced:f[0].indexOf('Share')>=0};});return {form:form,fields:list};}
module.exports={calculate:calculate,defaults:defaults,carbLimits:carbLimits,tdeeLimits:tdeeLimits,tdeeFormula:tdeeFormula};
