var local = require('./local-state');
var service = require('./local-service');
var feedback = {};
['showToast','showModal','showActionSheet','navigateBack','navigateTo','redirectTo','switchTab'].forEach(function(name) {
  feedback[name] = function(options) {
    // Preserve caller-owned options when a modal configuration is reused.
    var params = Object.assign({}, options || {});
    if ((name === 'showActionSheet' || name === 'showModal') && params.success) {
      var callback = params.success;
      params.success = function(result) {
        var outcome = service.execute(function() { return callback(result); });
        if (!outcome.ok) {
          wx.showModal({title:'操作未完成',content:outcome.error.message + '\n' + outcome.error.hint,showCancel:false});
          return false;
        }
        return outcome.data;
      };
    }
    if (name === 'navigateBack' || name === 'navigateTo' || name === 'redirectTo' || name === 'switchTab') {
      var fail = params.fail;
      params.fail = function(result) {
        wx.showToast({title:'页面跳转未完成，请重试',icon:'none'});
        if (typeof fail === 'function') fail(result);
      };
    }
    local.afterCommit(function() { wx[name](params); });
  };
});
module.exports = feedback;
