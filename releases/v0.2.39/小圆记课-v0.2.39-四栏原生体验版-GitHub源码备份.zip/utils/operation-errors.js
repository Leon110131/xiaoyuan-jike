// Only intentional validation messages are shown verbatim. Internal errors stay local.
function create(code, message) {
  var error = new Error(message);
  error.code = code;
  return error;
}
function storage(error) {
  var message = String(error && (error.errMsg || error.message) || '');
  var quota = /quota|exceed|storage.*limit|空间|容量|上限/i.test(message);
  return create(quota ? 'STORAGE_QUOTA' : 'STORAGE_UNAVAILABLE', quota
    ? '本机存储空间不足，本次修改未保存。'
    : '暂时无法读写本机数据，本次操作未完成。');
}
function describe(error) {
  var code = error && error.code || 'INTERNAL_ERROR';
  var hints = {
    STORAGE_QUOTA:'请先导出备份，再释放设备空间后重试。请勿清除小程序数据。',
    STORAGE_UNAVAILABLE:'请保留当前输入，稍后重试。请勿卸载或清除小程序数据。',
    INVALID_STATE:'请保留本机数据并联系支持，不要清缓存。可在有效环境中用已有备份恢复。',
    CONFLICT:'请返回并重新打开最新资料，再确认修改。',
    VALIDATION:'请检查输入后重试，当前内容已保留。',
    ASYNC_TRANSACTION:'请重试或联系支持，本地事务只支持同步保存。',
    INTERNAL_ERROR:'当前内容已保留，请稍后重试；仍失败时请联系支持。'
  };
  if (!hints[code]) code = 'INTERNAL_ERROR';
  return {code:code, message:code === 'INTERNAL_ERROR' ? '操作暂未完成，请重试。' : error.message,
    hint:hints[code], retryable:code === 'STORAGE_QUOTA' || code === 'STORAGE_UNAVAILABLE' || code === 'INTERNAL_ERROR'};
}
module.exports = {create:create, storage:storage, describe:describe};
