function nonNegative(value, fallback) {
  return typeof value === 'number' && isFinite(value) && value >= 0 ? value : fallback;
}

function readMetrics(api) {
  var info = null;
  try {
    info = typeof api.getWindowInfo === 'function' ? api.getWindowInfo() : api.getSystemInfoSync();
  } catch (error) {
    try { if (typeof api.getSystemInfoSync === 'function') info = api.getSystemInfoSync(); } catch (ignored) {}
  }
  info = info || {};
  var width = nonNegative(info.windowWidth, 0);
  var height = nonNegative(info.windowHeight, 0);
  var status = nonNegative(info.statusBarHeight, 0);
  var menu = null;
  try { if (typeof api.getMenuButtonBoundingClientRect === 'function') menu = api.getMenuButtonBoundingClientRect(); } catch (ignored) {}
  var menuValid = menu && isFinite(menu.top) && isFinite(menu.bottom) && menu.bottom > menu.top && menu.left > 0 && menu.left < width;
  var navHeight = menuValid ? Math.max(44, menu.bottom - menu.top + 2 * Math.max(0, menu.top - status)) : 44;
  var safeBottom = info.safeArea && info.screenHeight ? Math.max(0, info.screenHeight - info.safeArea.bottom) : 0;
  return {
    valid: width > 0 && height > 0,
    windowWidth: width,
    windowHeight: height,
    statusBarHeight: status,
    navHeight: navHeight,
    menuRight: menuValid ? Math.max(16, width - menu.left + 8) : 16,
    safeBottom: nonNegative(safeBottom, 0)
  };
}

module.exports = { readMetrics: readMetrics };
