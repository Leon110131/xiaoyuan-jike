// Each native Tab page owns an instance of the shared bar.
const tabs = [
  { pagePath: '/pages/dashboard/index', text: '工作', icon: 'work' },
  { pagePath: '/pages/members/index', text: '会员', icon: 'member' },
  { pagePath: '/pages/tools/index', text: '工具', icon: 'tool' },
  { pagePath: '/pages/statistics/index', text: '经营', icon: 'business' }
];

function hasOverlay(data) {
  return Boolean(data.showBookingDrawer || data.showCourseDetail || data.showPackageChooser || data.showQuickFinance || data.showHistory || data.showStatsMonth || data.showSale);
}

module.exports = function (index, config) {
  const { onLoad, onShow, onReady, onHide } = config;
  function sync(page, data = page.data) {
    const bar = typeof page.getTabBar === 'function' && page.getTabBar();
    if (!bar) return;
    const hidden = hasOverlay(data);
    const state = bar.data || {};
    if (state.selected !== index || state.hidden !== hidden) bar.setData({ selected: index, hidden });
  }
  function setup(page) {
    if (page._tabStateWrapped) return;
    page._tabStateWrapped = true;
    const setData = page.setData;
    page.setData = function (patch, callback) {
      sync(this, Object.assign({}, this.data, patch));
      return setData.call(this, patch, callback);
    };
  }

  config.onLoad = function () { setup(this); if (onLoad) return onLoad.apply(this, arguments); };
  config.onShow = function () { setup(this); sync(this); if (onShow) return onShow.apply(this, arguments); };
  config.onReady = function () { sync(this); if (onReady) return onReady.apply(this, arguments); };
  config.onHide = function () { if (onHide) return onHide.apply(this, arguments); };
  return config;
};
module.exports.tabs = tabs;
