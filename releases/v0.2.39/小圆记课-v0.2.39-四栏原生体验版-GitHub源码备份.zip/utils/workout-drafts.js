// Drafts are isolated from committed workouts, but included in full backup v5.
var fields=['memberId','workoutId','courseId','courseTitle','editingExisting','planId','date','time','duration','subjective','notes','exercises','templateSnapshot','planChoiceLabel','launchedFromPlan','launchPlanId'];
function store(){return require('./store');}function copy(x){return JSON.parse(JSON.stringify(x));}
function key(d){return 'draft:'+d.workoutId;}
function all(){return store().list('workoutDrafts');}
function resumable(memberId, courseId, rows = all(), workouts = store().list('workouts')) {
  const committed = new Set(workouts.map(row => row.id));
  return rows.filter(row => {
    const data = row.data;
    const links = data && [row.courseId, data.courseId].filter(Boolean);
    return row.memberId === memberId && data && data.memberId === memberId &&
      typeof row.workoutId === 'string' && row.workoutId && row.workoutId === data.workoutId &&
      row.id === key(data) && Array.isArray(data.exercises) && !data.editingExisting &&
      !committed.has(row.workoutId) && (!row.sourceCourseId || row.sourceCourseId === courseId) &&
      (courseId ? links.length > 0 && links.every(id => id === courseId) : links.length === 0);
  }).sort((a, b) => b.updatedAt - a.updatedAt);
}
function choose(q,memberId){if(q.fresh==='1')return;
 if(q.draftId&&q.supplementCourse==='1'){
  var source=store().byId('courses',q.courseId);
  if(source&&!source.archived&&source.memberId===q.memberId&&store().byId('members',q.memberId)){
   return resumable(q.memberId,q.courseId).find(function(row){return row.id===q.draftId;});
  }
  return;
 }
 var rows=all().filter(function(r){return store().byId('members',r.memberId);});if(q.draftId)return rows.find(function(r){
 if(r.id!==q.draftId||!r.data||r.data.memberId!==r.memberId||r.data.workoutId!==r.workoutId||
    (q.memberId&&r.memberId!==q.memberId)||(q.workoutId&&r.workoutId!==q.workoutId)||(q.courseId&&r.courseId!==q.courseId))return false;
 var course=r.courseId&&store().byId('courses',r.courseId);
 if(course&&course.memberId!==r.memberId)return false;
 if(!r.data.editingExisting)return true;
 var workout=store().byId('workouts',r.workoutId);
 return Boolean(workout&&workout.memberId===r.memberId);
});if(q.workoutId)return rows.filter(function(r){return r.data.editingExisting&&r.workoutId===q.workoutId;})[0];if(q.courseId)return rows.filter(function(r){return r.courseId===q.courseId||r.sourceCourseId===q.courseId;})[0];rows=rows.filter(function(r){return !r.data.editingExisting&&!store().byId('members',r.memberId).listRemoved&&(!q.memberId||r.memberId===memberId);});return rows.sort(function(a,b){return b.updatedAt-a.updatedAt;})[0];}
function read(page){var d={};fields.forEach(function(k){if(page.data[k]!==undefined)d[k]=copy(page.data[k]);});var c=page._restClock,t=page._restTracker,rest=null;if(c&&c.active&&t&&!t.finished){rest={clock:{active:c.active,paused:c.paused,remaining:c.remaining,deadline:c.deadline},tracker:{startedAt:t.startedAt,segment:t.segment,elapsedMs:t.elapsedMs,paused:t.paused,finished:t.finished},ui:{timerSetId:page.data.timerSetId,timerExerciseId:page.data.timerExerciseId,timerTitle:page.data.timerTitle,timerTarget:page.data.timerTarget}};}return {id:key(d),memberId:d.memberId,workoutId:d.workoutId,courseId:d.courseId||'',sourceCourseId:page._draftSourceCourseId||d.courseId||'',data:d,baseWorkoutSnapshot:page._workoutSnapshot||null,restState:rest,updatedAt:Date.now()};}
function signature(r){return JSON.stringify({id:r.id,data:r.data,base:r.baseWorkoutSnapshot,rest:r.restState,sourceCourseId:r.sourceCourseId||''});}
function put(page){var s=store();if(!s.coachWriteAllowed()||!page.data.memberId||!page.data.workoutId||page.data.editError||!s.byId('members',page.data.memberId)||(page.data.editingExisting&&!s.byId('workouts',page.data.workoutId)))return false;var row=read(page),previous=all().filter(function(x){return x.id===row.id;})[0];if(previous&&signature(previous)===signature(row))return true;s.upsert('workoutDrafts',row);return true;}
function remove(d){var s=store(),id=key(d);s.set('workoutDrafts',all().filter(function(r){return r.id!==id;}));}
function validate(rows,backup){function check(ok,msg){if(!ok)throw Error('训练草稿：'+msg);}check(Array.isArray(rows),'集合必须是数组。');var ids={};rows.forEach(function(r){check(r&&typeof r==='object'&&!Array.isArray(r),'记录格式无效。');var d=r.data;check(d&&typeof d==='object'&&Array.isArray(d.exercises),'动作格式无效。');check(typeof r.id==='string'&&r.id===key(d)&&!ids[r.id],'ID无效或重复。');ids[r.id]=true;check(typeof r.memberId==='string'&&r.memberId===d.memberId&&backup.members.some(function(m){return m.id===r.memberId;}),'会员关联无效。');check(typeof d.workoutId==='string'&&!!d.workoutId&&d.workoutId===r.workoutId,'训练ID无效。');check((d.courseId||'')===(r.courseId||''),'课程ID不一致。');if(d.courseId){var course=backup.courses.filter(function(c){return c.id===d.courseId;})[0];check(!course||course.memberId===r.memberId,'课程关联无效。');}check(r.sourceCourseId===undefined||typeof r.sourceCourseId==='string','原课程标记无效。');check(typeof d.editingExisting==='boolean'&&(!d.editingExisting||backup.workouts.some(function(x){return x.id===d.workoutId&&x.memberId===r.memberId;})),'原训练关联无效。');check(typeof r.updatedAt==='number'&&isFinite(r.updatedAt)&&r.updatedAt>=0,'更新时间无效。');check(r.baseWorkoutSnapshot===null||typeof r.baseWorkoutSnapshot==='string','编辑快照无效。');['date','time','notes','subjective','planChoiceLabel','planId','launchPlanId','courseTitle'].forEach(function(k){check(typeof d[k]==='string',k+'格式无效。');});check(/^\d{4}-\d{2}-\d{2}$/.test(d.date)&&/^([01]\d|2[0-3]):[0-5]\d$/.test(d.time),'日期时间无效。');check(typeof d.duration==='number'&&isFinite(d.duration)&&d.duration>=0,'时长无效。');check(typeof d.launchedFromPlan==='boolean','模板入口状态无效。');var exIds={},setIds={};d.exercises.forEach(function(ex){check(ex&&typeof ex.id==='string'&&ex.id&&!exIds[ex.id]&&typeof ex.name==='string'&&Array.isArray(ex.sets),'动作无效或重复。');exIds[ex.id]=true;ex.sets.forEach(function(st){check(st&&typeof st.id==='string'&&st.id&&!setIds[st.id]&&typeof st.done==='boolean'&&typeof st.setType==='string','训练组无效或重复。');setIds[st.id]=true;['weight','reps','rest'].forEach(function(k){var val=st[k];check((typeof val==='string'||typeof val==='number')&&(k==='weight'?/^\d*(?:\.\d*)?$/:/^\d*$/).test(String(val)),k+'格式无效。');});});});if(r.restState){var c=r.restState.clock,t=r.restState.tracker,u=r.restState.ui;check(c&&t&&u&&c.active===true&&typeof c.paused==='boolean'&&typeof t.paused==='boolean'&&t.finished===false,'休息状态无效。');['remaining','deadline'].forEach(function(k){check(typeof c[k]==='number'&&isFinite(c[k])&&c[k]>=0,'倒计时无效。');});['startedAt','segment','elapsedMs'].forEach(function(k){check(typeof t[k]==='number'&&isFinite(t[k])&&t[k]>=0,'实际休息无效。');});check(d.exercises.some(function(ex){return ex.id===u.timerExerciseId&&ex.sets.some(function(st){return st.id===u.timerSetId;});}),'休息组不存在。');}});return true;}
function workList() {
  var s=store(), members=new Map(s.list('members').map(function(row){return [row.id,row];}));
  var courses=new Map(s.list('courses').map(function(row){return [row.id,row];}));
  var workouts=new Map(s.list('workouts').map(function(row){return [row.id,row.memberId];}));
  return all().filter(function(row) {
    var course=courses.get(row.courseId);
    return row.data && row.data.memberId===row.memberId && row.data.workoutId===row.workoutId &&
      members.has(row.memberId) && (!course || course.memberId===row.memberId) &&
      (!row.data.editingExisting || workouts.get(row.workoutId)===row.memberId);
  }).sort(function(a,b){return b.updatedAt-a.updatedAt;}).map(function(row) {
    var data=row.data, course=courses.get(row.courseId), linked=course&&course.memberId===row.memberId;
    return {id:row.id,memberId:row.memberId,workoutId:row.workoutId,editingExisting:data.editingExisting,
      courseId:linked?course.id:'',name:members.get(row.memberId).name,date:data.date,time:data.time,
      kind:data.editingExisting?'训练记录编辑':linked?'课程训练':row.courseId||row.sourceCourseId?'原课程已不可用':'无预约训练'};
  });
}
module.exports={workList:workList,fields:fields,read:read,signature:signature,key:key,all:all,choose:choose,put:put,remove:remove,validate:validate,resumable:resumable};
