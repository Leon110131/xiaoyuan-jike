function status(c,now){if(!c.autoTimeStatus||c.deducted||['scheduled','completed'].indexOf(c.status)<0)return c.status;var end=new Date(c.date+'T'+c.time+':00').getTime()+Number(c.duration)*60000;return isFinite(end)&&end<=(now===undefined?Date.now():now)?'completed':'scheduled';}
function project(c,now){return Object.assign({},c,{status:status(c,now)});}
module.exports={status:status,project:project};
