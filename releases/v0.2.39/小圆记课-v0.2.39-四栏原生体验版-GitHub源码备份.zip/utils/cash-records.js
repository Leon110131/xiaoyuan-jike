// Read-only monthly cash projections. The original amounts remain available to callers.
const { yuan } = require('./statistics-view');
const titles = { sales: '售课记录', cashIncome: '手工记账收入明细', cashExpense: '本月支出明细', cashBalance: '本月收支净额明细' };
const monthOf = date => String(date || '').slice(0, 7);
const money = value => Number(value || 0).toFixed(2);

function sale(store, p) {
  return { key: 'package_' + p.id, id: p.id, memberId: p.memberId, source: 'package',
    sourceLabel: p.renewal ? '续费售课' : '新单售课', type: 'income', title: p.name || '课时包',
    date: String(p.saleDate || p.createdAt || '').slice(0, 10), memberName: store.memberName(p.memberId),
    amount: Number(p.saleAmount) || 0, notes: p.notes || '', total: p.total, archived: !!p.archived };
}

function manual(r) {
  return { key: 'entry_' + r.id, id: r.id, source: 'manual',
    sourceLabel: r.type === 'expense' ? '已记支出' : '已记收入', type: r.type,
    title: r.category || '未分类', date: r.date, memberName: '', amount: Number(r.amount) || 0, notes: r.notes || '' };
}

function present(row) {
  row.amountText = money(row.amount);
  row.displayAmount = row.type === 'expense' ? -Math.abs(row.amount) : row.amount;
  row.signedAmount = yuan(row.displayAmount, true);
  return row;
}

function load(store, kind, month) {
  if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(month)) throw Error('统计月份无效。');
  if (!Object.prototype.hasOwnProperty.call(titles, kind)) throw Error('现金明细类型无效。');
  const sales = store.list('packages').filter(p => monthOf(p.saleDate || p.createdAt) === month).map(p => sale(store, p));
  const entries = store.list('financialEntries').filter(r => monthOf(r.date) === month).map(manual);
  const includesSales = kind === 'sales' || kind === 'cashBalance';
  const rows = kind === 'sales' ? sales : kind === 'cashBalance' ? sales.concat(entries) :
    entries.filter(r => r.type === (kind === 'cashExpense' ? 'expense' : 'income'));
  rows.sort((a, b) => b.date.localeCompare(a.date) || b.key.localeCompare(a.key));
  let total = 0;
  rows.forEach(row => { present(row); total += (kind === 'cashBalance' && row.type === 'expense' ? -1 : 1) * row.amount; });
  const negative = includesSales ? sales.reduce((n, r) => n + Math.min(0, r.amount), 0) : 0;
  return { kind, month, cashOnly: true, title: titles[kind], totalText: money(total), records: rows,
    includesSales, hasMonthRecords: !!(sales.length || entries.length),
    historicalNegativeText: Number(money(negative)) < 0 ? yuan(negative) : '',
    incomeDisplay: yuan(sales.reduce((n, r) => n + r.amount, 0) + entries.reduce((n, r) => n + (r.type === 'income' ? r.amount : 0), 0)),
    expenseDisplay: yuan(entries.reduce((n, r) => n + (r.type === 'expense' ? r.amount : 0), 0)) };
}

function read(store, key, month) {
  const match = /^(package|entry)_(.+)$/.exec(key);
  if (!match) throw Error('记录已不可用');
  const [, source, id] = match;
  const row = store.byId(source === 'package' ? 'packages' : 'financialEntries', id);
  if (!row) throw Error('记录已不可用');
  const record = source === 'package' ? sale(store, row) : manual(row);
  if (monthOf(record.date) !== month) throw Error('记录月份已变化，请返回刷新');
  return present(record);
}

module.exports = { load, read };
