// Synchronous local boundary. No HTTP, cloud SDK, login, or remote persistence.
var local = require('./local-state');
var errors = require('./operation-errors');
function execute(handler, options) {
  options = options || {};
  var before;
  try {
    before = local.revision();
    if (options.expectedRevision != null && options.expectedRevision !== before) {
      throw errors.create('CONFLICT', '资料已发生变化，本次修改未保存。');
    }
    var data = local.transaction(handler), revision;
    // Once transaction returns, the write is durable. A later read error cannot roll it back.
    try { revision = local.revision(); } catch (ignored) { revision = null; }
    return {ok:true, data:data, error:null, revision:revision, changed:revision === null || revision !== before};
  } catch (error) {
    return {ok:false, data:null, error:errors.describe(error), revision:before == null ? null : before, changed:false};
  }
}
module.exports = {execute:execute, contractVersion:1, mode:'local'};
