// UI-only leave protection. No form draft or business data is written here.
var feedback=require('./page-feedback'),local=require('./local-state');
function snapshot(kind,page,data){
  if(kind==='member')return JSON.stringify({form:data.form,tagChoice:data.tagChoice,tagsChanged:!!page._tagsChanged});
  if(kind==='modal')return JSON.stringify({form:data.form,editingId:data.editingId});
  var days=(data.days||[]).map(function(day){return {id:day.id,name:day.name,exerciseNames:day.exerciseNames.slice()};});
  var active=days[data.activeDayIndex];
  if(active){active.name=data.dayName;active.exerciseNames=(data.selectedNames||[]).slice();}
  return JSON.stringify({form:data.form,days:days});
}
module.exports=function(kind,config){
  var load=config.onLoad;
  config.data=Object.assign({hasUnsavedChanges:false},config.data||{});
  config.onLoad=function(){
    if(load)load.apply(this,arguments);
    this._formCleanSnapshot=snapshot(kind,this,this.data);
    var base=this.setData;
    this.setData=function(patch,callback){
      var next=Object.assign({},this.data,patch);
      if(kind==='modal'&&!this.data.showForm&&next.showForm&&!Object.prototype.hasOwnProperty.call(patch,'hasUnsavedChanges'))this._formCleanSnapshot=snapshot(kind,this,next);
      var changed=snapshot(kind,this,next)!==this._formCleanSnapshot;
      return base.call(this,Object.assign({},patch,{hasUnsavedChanges:kind==='modal'?!!next.showForm&&changed:changed}),callback);
    };
    this.setData({hasUnsavedChanges:false});
  };
  config.markFormSaved=function(){
    this._formCleanSnapshot=snapshot(kind,this,this.data);
    this.setData({hasUnsavedChanges:false});
  };
  config.confirmUnsavedLeave=function(leave){
    if(!this.data.hasUnsavedChanges){leave();return;}
    if(this._formLeavePrompt)return;
    var self=this;
    this._formLeavePrompt=true;
    this.setData({});
    feedback.showModal({title:'放弃未保存的修改？',content:'离开后，本次填写的内容不会保存。',cancelText:'继续编辑',confirmText:'放弃修改',
      success:function(result){
        self._formLeavePrompt=false;
        if(result.confirm)local.afterCommit(leave);
        else self.setData({});
      },
      fail:function(){self._formLeavePrompt=false;self.setData({});wx.showToast({title:'未完成确认，已保留当前填写内容',icon:'none'});}
    });
  };
  if(kind==='modal'){
    var close=config.closeForm;
    config.closeForm=function(){var self=this,args=arguments;this.confirmUnsavedLeave(function(){close.apply(self,args);});};
  }
  return config;
};
