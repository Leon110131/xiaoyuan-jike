const store = require('../../utils/store');
const admin = require('../../utils/admin-access');
const feedback = require('../../utils/page-feedback');
const withBack = require('../../utils/back-navigation');

Page(withBack('pages/mine/index', {
  data: {
    profile: {}, adminAvailable: false,
    settings: [
      { id: 'profile', label: '教练资料', path: '/pages/profile/index' },
      { id: 'rules', label: '课程规则', path: '/pages/system-settings/index' },
      { id: 'backup', label: '备份与恢复', path: '/pages/data-tools/index' },
      { id: 'help', label: '帮助与反馈', path: '/pages/about-help/index' }
    ]
  },
  onShow() { this.refresh(); },
  refresh() {
    const profile = store.get('coachProfile') || {};
    this.setData({ profile: Object.assign({}, profile, { initial: Array.from(profile.name || '教')[0] }) });
    admin.session().then(access => this.setData({ adminAvailable: access.allowed }))
      .catch(() => this.setData({ adminAvailable: false }));
  },
  openSetting(event) {
    const url = event.currentTarget.dataset.path;
    if (url === '/pages/auth/index' || this.data.settings.some(item => item.path === url)) feedback.navigateTo({ url });
  },
  openAdmin() {
    admin.session().then(access => {
      if (!access.allowed) throw Error(access.reason || '无平台管理权限');
      feedback.navigateTo({ url: '/pages/experience-admin/index' });
    }).catch(error => {
      this.setData({ adminAvailable: false });
      wx.showModal({ title: '未能进入', content: error.message, showCancel: false });
    });
  },
  clearSamples() { feedback.navigateTo({ url: '/pages/data-tools/index?cleanup=1' }); }
}));
