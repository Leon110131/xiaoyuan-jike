const store = require('../../utils/store');
const view = require('../../utils/course-read-view');
const withBack = require('../../utils/back-navigation');
const withWrites = require('../../utils/course-write-page');

Page(require('../../utils/theme-page')(withBack('pages/course-detail/index', withWrites({
  data: { isCoursePage: true, panel: 'detail', detail: null, loading: true, detailReadError: false,
    courseOptionsOpen: false, courseConfirmation: null, selectedPackageId: '' },
  onLoad(query) { this._detailId = (query || {}).id || ''; },
  onShow() { this.loadCourses(); },
  loadCourses() {
    try {
      const course = store.byId('courses', this._detailId);
      const detail = view.read().find(row => row.id === this._detailId) || null;
      if (detail) {
        const pack = course.packageId ? store.byId('packages', course.packageId) : null;
        detail.packageLabel = pack && pack.memberId === course.memberId ? pack.name :
          course.packageId ? '原课时包待核对' : '';
        detail.location = course.location || '';
      }
      this.setData({ detail, loading: false, detailReadError: false });
    } catch (error) {
      this.setData({ detail: null, loading: false, detailReadError: true });
    }
  },
  closeCourseDetail() { this.requestPageLeave(); },
  openCourseTransactions() {
    if (!this.data.courseActions.cancel && !this.data.courseActions.remove) return;
    if (this.data.courseActions.cancel) {
      this.openCancelChoices();
      return;
    }
    this.setData({ panel: 'transactions', courseOptionsOpen: true, writeError: '' });
  },
  chooseDebitPackage(event) { this.setData({ selectedPackageId: event.currentTarget.dataset.id }); },
  confirmSelectedPackage() {
    if (!this.data.selectedPackageId) return;
    this.confirmReadDebit({ currentTarget: { dataset: { id: this.data.selectedPackageId } } });
  },
  showCourseConfirmation(options) {
    this._confirmation = options;
    this.setData({ courseConfirmation: {
      title: options.title, content: options.content, confirmText: options.confirmText, danger: Boolean(options.confirmColor)
    } });
  },
  finishCourseConfirmation(confirm) {
    const options = this._confirmation;
    if (!options) return;
    this._confirmation = null;
    this.setData({ courseConfirmation: null });
    options.success({ confirm });
  },
  cancelCourseConfirmation() { this.finishCourseConfirmation(false); },
  acceptCourseConfirmation() { this.finishCourseConfirmation(true); }
}, false, {}))));
