const calc = require('../../utils/nutrition-calculators');
const input = require('../../utils/quick-calculation-form');
const store = require('../../utils/store');
const sync = require('../../utils/nutrition-sync');
const feedback = require('../../utils/page-feedback');
const carb = require('../../utils/carbohydrate-form');
const memberChoice = require('../../utils/member-choice');

const branches = [
  { key: 'tdee', title: '快速 TDEE' },
  { key: 'cycle', title: '碳水循环' },
  { key: 'taper', title: '碳水渐降' }
];
const activities = [
  { label: '几乎不运动', value: 1.2 },
  { label: '每周运动 1–3 天', value: 1.375 },
  { label: '每周运动 3–5 天', value: 1.55 },
  { label: '每周运动 6–7 天', value: 1.725 },
  { label: '长时间运动 / 体力劳动', value: 1.9 }
];

function emptyBranch(kind, memberSelection) {
  const { fields, form } = calc.defaults(kind);
  form.sex = '';
  fields.forEach(field => {
    field.value = field.key === 'activity' ? field.value : '';
    field.placeholder = carb.placeholders[field.key] || '';
    field.type = calc.carbLimits[field.key] && calc.carbLimits[field.key].integer ? 'number' : 'digit';
    form[field.key] = field.value;
  });
  return {
    fields, form, result: null, quickEnergy: null, fieldErrors: {}, error: '',
    showAdvanced: kind === 'cycle', showCarbResult: false, carbSubmitted: false,
    allocationTotals: { days: 0, carbs: 0, fat: 0 }, distributionErrors: [], sexIndex: -1, rowNames: [], rowIndex: 0, syncHint: '',
    customActivity: false, activityLabel: activities[2].label, operationError: null,
    memberId: memberSelection.id, memberIndex: memberSelection.index
  };
}

function updateField(page, key, value) {
  const form = Object.assign({}, page.data.form, { [key]: value });
  const fields = page.data.fields.map(field => field.key === key ? Object.assign({}, field, { value }) : field);
  page.setData({ form, fields, result: null, quickEnergy: null, error: '', syncHint: '', rowNames: [], rowIndex: 0, showCarbResult: false });
}

function eligibleMembers() {
  return memberChoice.describe(store.visibleMembers().filter(memberChoice.eligible));
}

function energyText(value) {
  return value.split(' ')[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

const config = {
  data: {
    branches, dayTypes: carb.dayTypes, showCarbResult: false, contentScrollTop: 0,
    carbApplyOpen: false, carbApplying: false, carbApplyError: '', carbApplyMemberError: '',
    carbApplyMembers: [], carbApplyNames: [], carbApplyRowOptions: [], carbApplyId: '', carbApplyName: '', carbApplyLabel: '', carbApplyIndex: -1, carbApplyRow: -1,
    kind: '', title: '饮食计算', fields: [], form: {}, fieldErrors: {},
    result: null, quickEnergy: null, sexIndex: -1, sexOptions: ['男性公式', '女性公式'],
    bodyFields: [
      { key: 'age', label: '年龄（岁）', type: 'number', placeholder: '填写年龄' },
      { key: 'height', label: '身高（cm）', type: 'digit', placeholder: '填写身高' },
      { key: 'weight', label: '体重（kg）', type: 'digit', placeholder: '填写体重' }
    ],
    members: [], memberNames: [], memberId: '', memberIndex: -1, rowNames: [], rowIndex: 0,
    error: '', syncHint: '', customActivity: false
  },
  onLoad(query) {
    const branch = branches.find(item => item.key === (query.kind || 'cycle'));
    if (!branch) {
      this.setData({ error: '计算类型不存在' });
      return;
    }
    const members = store.visibleMembers();
    const memberId = query.memberId || (query.tool !== '1' && members[0] && members[0].id) || '';
    const memberIndex = members.findIndex(member => member.id === memberId);
    this._sourceMemberId = query.memberId || '';
    this._branches = {};
    this._initialMember = { id: memberId, index: memberIndex };
    this.setData(Object.assign(emptyBranch(branch.key, this._initialMember), {
      kind: branch.key, title: branch.title, members, memberNames: members.map(member => member.name),
      error: query.tool === '1' || memberIndex >= 0 ? '' : '请选择有效会员'
    }));
  },
  switchBranch(event) {
    const branch = branches.find(item => item.key === event.currentTarget.dataset.kind);
    if (!branch || branch.key === this.data.kind) return;
    this.finishKeyboardEditing();
    const current = emptyBranch(this.data.kind, this._initialMember);
    Object.keys(current).forEach(key => { current[key] = this.data[key]; });
    this._branches[this.data.kind] = current;
    this.setData(Object.assign({}, this._branches[branch.key] || emptyBranch(branch.key, this._initialMember),
      { kind: branch.key, title: branch.title }));
    this.resetCarbScroll();
  },
  onQuickInput(event) {
    this.onInput(event);
    this.quickCalculate();
  },
  chooseQuickSex(event) {
    const index = Number(event.currentTarget.dataset.value);
    this.onSex({ detail: { value: index } });
    this.quickCalculate();
  },
  chooseActivity() {
    this.finishKeyboardEditing();
    const itemList = activities.map(item => item.label + ' ×' + item.value);
    wx.showActionSheet({
      itemList,
      success: ({ tapIndex }) => {
        if (this.data.kind !== 'tdee') return;
        const activity = activities[tapIndex];
        if (!activity) return;
        updateField(this, 'activity', String(activity.value));
        this.setData({ activityLabel: activity.label, customActivity: false });
        this.quickCalculate();
      }
    });
  },
  customizeActivity() { this.setData({ customActivity: true, activityLabel: '自定义活动系数' }); },
  quickCalculate() {
    const form = this.data.form;
    const rules = calc.tdeeLimits;
    const fieldErrors = {};
    for (const key of Object.keys(rules)) {
      const error = input.message(form[key], rules[key]);
      if (error) fieldErrors[key] = error;
    }
    if (!form.sex || Object.keys(fieldErrors).length || !Object.keys(rules).every(key => input.complete(form[key]))) {
      this.setData({ fieldErrors, result: null, quickEnergy: null, error: '' });
      return;
    }
    try {
      const result = calc.calculate('tdee', form);
      this.setData({ fieldErrors, result, error: '', quickEnergy: {
        rest: result.rows[0].value, total: result.rows[1].value,
        restText: energyText(result.rows[0].value), totalText: energyText(result.rows[1].value)
      } });
    } catch (error) {
      this.setData({ fieldErrors, result: null, quickEnergy: null, error: error.message });
    }
  },
  openFullPlan() {
    this.finishKeyboardEditing();
    const member = this._sourceMemberId;
    feedback.navigateTo({ url: '/pages/tdee-plan/index' + (member ? '?memberId=' + encodeURIComponent(member) : '') });
  },
  showSource() {
    wx.showModal({
      title: '计算依据与参考来源', content: calc.tdeeFormula, confirmText: '复制来源', cancelText: '关闭',
      success: result => { if (result.confirm) this.copySource(); }
    });
  },
  copySource() { input.copy('https://pubmed.ncbi.nlm.nih.gov/2305711/', '参考来源已复制'); },
  toggleAdvanced() { this.setData({ showAdvanced: !this.data.showAdvanced }); },
  onInput(event) {
    const key = event.currentTarget.dataset.key;
    if (!this.data.fields.some(field => field.key === key)) return;
    if (this.data.form[key] === event.detail.value) return;
    updateField(this, key, event.detail.value);
    if (this.data.kind !== 'tdee') this.validateCarb(this.data.carbSubmitted);
  },
  onSex(event) {
    const index = Number(event.detail.value);
    if (index !== 0 && index !== 1) return;
    const form = Object.assign({}, this.data.form, { sex: index ? 'female' : 'male' });
    this.setData({ sexIndex: index, form, result: null, quickEnergy: null, error: '', syncHint: '', rowNames: [], rowIndex: 0 });
  },
  onMemberChange(event) {
    const index = Number(event.detail.value);
    const member = this.data.members[index];
    if (member) this.setData({ memberIndex: index, memberId: member.id, syncHint: '', error: '' });
  },
  onResultRow(event) {
    const index = Number(event.detail.value);
    if (!this.data.result || !Number.isInteger(index) || index < 0 || index >= this.data.result.rows.length) return;
    this.setData({ rowIndex: index, syncHint: '' });
  },
  resetCarbScroll() {
    this.setData({ contentScrollTop: this.data.contentScrollTop ? 0 : 1 });
  },
  backCalculator() {
    if (this.data.carbApplyOpen) return this.closeCarbApply();
    if (this.data.showCarbResult) return this.editCarbParameters();
    this.requestPageLeave();
  },
  editCarbParameters() {
    this.setData({ showCarbResult: false });
    this.resetCarbScroll();
  },
  showCarbFormula() {
    if (this.data.result) wx.showModal({ title: '计算依据', content: this.data.result.formula, showCancel: false });
  },
  validateCarb(submitted) {
    const { kind, fields, form } = this.data;
    const state = carb.validate(kind, fields, form, submitted);
    this.setData(Object.assign({ carbSubmitted: submitted }, state));
    return !Object.keys(state.fieldErrors).length && !state.distributionErrors.length;
  },
  openCarbApply() {
    if (!this.data.showCarbResult || !this.data.result || this.data.kind === 'tdee') return;
    const members = eligibleMembers();
    const source = this._sourceMemberId;
    const index = members.findIndex(member => member.id === source);
    const member = members[index];
    this.setData({
      carbApplyOpen: true, carbApplyMembers: members, carbApplyNames: ['选择会员'].concat(members.map(memberChoice.display)),
      carbApplyIndex: index, carbApplyId: member ? member.id : '', carbApplyName: member ? member.name : '', carbApplyLabel: member ? memberChoice.display(member) : '',
      carbApplyRow: -1, carbApplyRowOptions: [this.data.kind === 'cycle' ? '选择日型' : '选择阶段'].concat(this.data.rowNames),
      carbApplyError: '', carbApplyMemberError: source && !member ? '原会员已失效，请重新选择。计算结果已保留。' : ''
    });
  },
  closeCarbApply() {
    if (!this.data.carbApplying) this.setData({ carbApplyOpen: false });
  },
  chooseCarbMember(event) {
    const index = Number(event.detail.value) - 1;
    const member = this.data.carbApplyMembers[index];
    if (!member || this.data.carbApplying) return;
    this.setData({ carbApplyIndex: index, carbApplyId: member.id, carbApplyName: member.name, carbApplyLabel: memberChoice.display(member),
      carbApplyMemberError: '', carbApplyError: '' });
  },
  chooseCarbRow(event) {
    const index = Number(event.detail.value) - 1;
    if (!this.data.result || !this.data.result.rows[index] || this.data.carbApplying) return;
    this.setData({ carbApplyRow: index, carbApplyError: '' });
  },
  confirmCarbApply() {
    const data = this.data;
    if (this._carbApplying || !data.carbApplyOpen || data.kind === 'tdee' ||
        !data.showCarbResult || !data.result || !data.result.rows[data.carbApplyRow] || !data.carbApplyId) return false;
    this._carbApplying = true;
    this.setData({ carbApplying: true, carbApplyError: '' });
    let appliedId;
    try {
      const members = eligibleMembers();
      const member = members.find(item => item.id === data.carbApplyId);
      if (!member) {
        this.setData({ carbApplyMembers: members, carbApplyNames: ['选择会员'].concat(members.map(memberChoice.display)),
          carbApplyIndex: -1, carbApplyId: '', carbApplyName: '', carbApplyLabel: '', carbApplyMemberError: '会员已失效，请重新选择。计算结果已保留。' });
        return false;
      }
      const current = calc.calculate(data.kind, data.form);
      if (current.text !== data.result.text) {
        this.setData({ carbApplyOpen: false, showCarbResult: false, result: null, error: '参数已变更，请重新计算' });
        return false;
      }
      sync(member.id, data.kind, data.form, data.carbApplyRow);
      this.setData({ carbApplyOpen: false });
      wx.showToast({ title: '每日营养目标已同步', icon: 'success' });
      appliedId = member.id;
    } catch (error) {
      this.setData({ carbApplyError: '未能应用营养目标。会员、选择和计算结果已保留。' });
      return false;
    } finally {
      this._carbApplying = false;
      this.setData({ carbApplying: false });
    }
    this.returnToNutrition(appliedId);
    return true;
  },
  returnToNutrition(memberId) {
    const pages = typeof getCurrentPages === 'function' ? getCurrentPages() : [];
    const source = pages[pages.length - 2];
    if (!source || source.route !== 'pages/nutrition/index') return;
    if (source.data.memberId === memberId) this.requestPageLeave({ waitForLayer: true });
    else feedback.redirectTo({ url: '/pages/nutrition/index?memberId=' + encodeURIComponent(memberId) });
  },
  calculate() {
    this.finishKeyboardEditing();
    if (this.data.kind !== 'tdee' && !this.validateCarb(true)) {
      this.setData({ result: null, showCarbResult: false, error: Object.keys(this.data.fieldErrors).some(key => this.data.fieldErrors[key] === '请填写') ? '请完整填写所有计算参数' : '', syncHint: '' });
      return;
    }
    try {
      const result = calc.calculate(this.data.kind, this.data.form);
      this.setData({ result, showCarbResult: this.data.kind !== 'tdee', rowNames: result.rows.map(row => row.name), rowIndex: 0, error: '', syncHint: '' });
      if (this.data.showCarbResult) this.resetCarbScroll();
    } catch (error) {
      this.setData({ result: null, error: error.message, syncHint: '' });
      wx.showToast({ title: error.message, icon: 'none' });
    }
  },
  saveGoal() {
    if (!this.data.result) {
      wx.showToast({ title: '请先重新计算', icon: 'none' });
      return false;
    }
    const member = store.byId('members', this.data.memberId);
    if (!member) throw Error('请选择有效会员');
    sync(member.id, this.data.kind, this.data.form, this.data.rowIndex);
    const action = this.data.kind === 'tdee' ? '已同步热量，原有营养素目标保留' : '已同步' + this.data.rowNames[this.data.rowIndex];
    this.setData({ syncHint: member.name + ' · ' + action });
    wx.showToast({ title: '每日营养目标已同步', icon: 'success' });
    return true;
  },
  copyResult() {
    if (this.data.result) input.copy(this.data.result.text, '计算结果已复制');
  }
};

const guard = require('../../utils/page-guard')(config);
const feature = require('../../utils/feature-page')('nutrition', guard);
Page(require('../../utils/theme-page')(require('../../utils/back-navigation')('pages/nutrition-calculator/index', feature)));
