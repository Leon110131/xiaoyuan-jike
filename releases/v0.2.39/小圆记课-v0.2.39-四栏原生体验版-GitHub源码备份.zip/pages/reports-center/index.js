const store = require('../../utils/store');
const reports = require('../../utils/summary-reports');
const service = require('../../utils/local-service');
const errors = require('../../utils/operation-errors');
const feedback = require('../../utils/page-feedback');

const route = 'pages/reports-center/index';
const currentStack = () => typeof getCurrentPages === 'function' ? getCurrentPages() : [];
const previousPage = () => currentStack().slice(-2, -1)[0];

Page(require('../../utils/theme-page')(require('../../utils/back-navigation')(route,
  require('../../utils/feature-page')('reports', {
    data: { screen: 'generate', period: 'week', templates: reports.templates, selectedTemplate: 'coach',
      range: null, history: [], report: null, sections: null, saved: false, generating: false, saving: false,
      copying: false, removing: false, reportDeleteOpen: false, missing: false, issue: '', deleteIssue: '' },
    onLoad(q = {}) {
      const screen = ['preview', 'history', 'detail'].includes(q.screen) ? q.screen : 'generate';
      this.reportId = q.id || '';
      this.setData({ screen, period: q.period === 'month' ? 'month' : 'week' });
      if (screen === 'preview') {
        const source = previousPage();
        const report = source?.route === route && source.generated?.id === this.reportId ? source.generated : null;
        this.showReport(report);
      }
    },
    onShow() {
      const { screen, period } = this.data;
      if (screen === 'generate') this.setData({ range: reports.rangeFor(period) });
      if (screen === 'history') this.refreshHistory();
      if (screen === 'detail') this.refreshDetail();
    },
    showReport(report) {
      this.setData({ report, missing: !report, sections: report ? reports.presentation(report.text) : null });
    },
    refreshHistory() {
      const result = service.execute(reports.history);
      this.setData(result.ok ? { history: result.data, issue: '' } : { issue: '历史报告暂时无法读取，请重试。' });
    },
    refreshDetail() {
      const result = service.execute(() => reports.read(this.reportId));
      if (result.ok) {
        this.expected = result.data && JSON.stringify(result.data);
        this.setData({ issue: '' });
        this.showReport(result.data);
      } else {
        this.expected = null;
        this.setData({ report: null, sections: null, issue: '报告暂时无法读取，请重试。' });
      }
    },
    choosePeriod(e) {
      const period = e.currentTarget.dataset.period;
      if (!['week', 'month'].includes(period) || period === this.data.period) return;
      this.generated = null;
      this.setData({ period, range: reports.rangeFor(period), issue: '' });
    },
    chooseTemplate(e) {
      const selectedTemplate = e.currentTarget.dataset.id;
      if (!reports.templates.some(item => item.id === selectedTemplate) || selectedTemplate === this.data.selectedTemplate) return;
      this.generated = null;
      this.setData({ selectedTemplate, issue: '' });
    },
    generate() {
      if (this.data.generating || this.data.featureLocked) return;
      this.setData({ generating: true, issue: '' });
      const result = service.execute(() => reports.generate(this.data.period, this.data.selectedTemplate));
      if (!result.ok) {
        this.setData({ generating: false, issue: '报告生成失败。已保留选择，可重新生成。' });
        return;
      }
      this.generated = result.data;
      this.setData({ range: { start: result.data.startDate, end: result.data.endDate } });
      feedback.navigateTo({ url: '/' + route + '?screen=preview&id=' + encodeURIComponent(result.data.id),
        complete: () => this.setData({ generating: false }) });
    },
    openHistory() { feedback.navigateTo({ url: '/' + route + '?screen=history' }); },
    openDetail(e) {
      const id = e.currentTarget.dataset.id;
      if (!this.data.history.some(row => row.id === id)) return;
      feedback.navigateTo({ url: '/' + route + '?screen=detail&id=' + encodeURIComponent(id) });
    },
    save() {
      const { report, saved, saving, featureLocked, screen } = this.data;
      if (screen !== 'preview' || !report || saved || saving || featureLocked) return;
      this.setData({ saving: true, issue: '' });
      const result = service.execute(() => {
        const existing = store.byId('reports', report.id);
        if (!existing) store.upsert('reports', { ...report });
        else if (JSON.stringify(existing) !== JSON.stringify(report)) {
          throw errors.create('CONFLICT', '报告标识已存在，请返回重新生成。');
        }
      });
      this.setData({ saving: false, saved: result.ok, issue: result.ok ? '' : result.error.message + '已保留预览内容。' });
      if (result.ok) feedback.showToast({ title: '报告已保存', icon: 'success' });
    },
    copy() {
      const { report, copying } = this.data;
      if (!report || copying || !report.text || this.data.featureLocked) return;
      this.setData({ copying: true, issue: '' });
      const failed = () => this.setData({ copying: false, issue: '复制失败。已保留报告，可重新复制。' });
      try {
        wx.setClipboardData({ data: report.text, success: () => {
          this.setData({ copying: false });
          feedback.showToast({ title: '报告已复制', icon: 'success' });
        }, fail: failed });
      } catch (error) { failed(); }
    },
    openReportDelete() {
      if (this.data.screen === 'detail' && this.data.report && !this.data.featureLocked) {
        this.setData({ reportDeleteOpen: true, deleteIssue: '' });
      }
    },
    closeReportDelete() {
      if (!this.data.removing) this.setData({ reportDeleteOpen: false, deleteIssue: '' });
    },
    confirmReportDelete() {
      if (!this.data.reportDeleteOpen || this.data.removing || this.data.featureLocked) return;
      this.setData({ removing: true, deleteIssue: '' });
      const result = service.execute(() => reports.remove(this.reportId, this.expected));
      if (!result.ok) {
        if (result.error.code === 'CONFLICT') {
          this.setData({ removing: false, reportDeleteOpen: false });
          this.refreshDetail();
          if (this.data.report) this.setData({ issue: result.error.message });
        } else {
          this.setData({ removing: false, deleteIssue: result.error.message });
        }
        return;
      }
      this.expected = null;
      this.setData({ removing: false, reportDeleteOpen: false, missing: true, report: null }, () => {
        // Allow the native page-container to close before navigating.
        setTimeout(() => {
          if (currentStack().at(-1) !== this && currentStack().length) return;
          this.backToHistory();
          feedback.showToast({ title: '报告已删除', icon: 'none' });
        }, 320);
      });
    },
    backToHistory() {
      const parent = previousPage();
      if (parent?.route === route && parent.data.screen === 'history') this.requestPageLeave();
      else wx.redirectTo({ url: '/' + route + '?screen=history' });
    },
    backToGenerate() {
      const parent = previousPage();
      if (parent?.route === route && parent.data.screen === 'generate') this.requestPageLeave();
      else wx.redirectTo({ url: '/' + route });
    },
    leaveReports() {
      if (this.data.reportDeleteOpen) this.closeReportDelete();
      else this.requestPageLeave();
    }
  }))));
