const store = require('../../utils/store');
const archive = require('../../utils/training-archive');
const courseView = require('../../utils/course-read-view');
const feedback = require('../../utils/page-feedback');

Page(require('../../utils/theme-page')(require('../../utils/time-status-page')(
  require('../../utils/back-navigation')('pages/member-courses/index', require('../../utils/feature-page')('calendar', {
    data: { member: null, courses: [], workouts: [], error: '', training: false,
      filter: '已完成', filters: ['已完成', '全部', '预约中'], count: 0, totalCount: 0, month: '', endDate: '' },
    onLoad(query) {
      const q = query || {};
      this.memberId = q.memberId || '';
      this.setData({ training: q.mode === 'training', filter: q.all === '1' ? '全部' : '已完成',
        month: /^\d{4}-\d{2}$/.test(q.month || '') ? q.month : '' });
      const channel = typeof this.getOpenerEventChannel === 'function' && this.getOpenerEventChannel();
      if (!q.month && channel && typeof channel.once === 'function') channel.once('memberCourseMonth', month => this.pickMonth({ detail: { value: month } }));
    },
    onShow() { this.refresh(); },
    refresh() {
      try {
        const member = store.byId('members', this.memberId);
        if (!member) throw Error('会员不存在');
        const { filter, month, endDate, training } = this.data;
        const allWorkouts = training ? store.list('workouts').filter(w => w.memberId === member.id) : [];
        const allCourses = training ? [] : courseView.read().filter(row => row.memberId === member.id);
        const courses = allCourses.filter(row => (!month || row.date.slice(0, 7) === month) &&
          (filter === '全部' || (filter === '预约中' ? row.storedStatus === 'scheduled' : row.storedStatus === 'completed'))).reverse().map(row => Object.assign(row, { shortDate: row.date.slice(5).replace('-', '.') }));
        const workouts = allWorkouts.map(w => Object.assign(archive.decorate(w, member.name), {
          exerciseCount: new Set((w.sets || []).map(set => set.exerciseInstanceId || set.exerciseId || set.exerciseName).filter(Boolean)).size
        }))
          .filter(w => !endDate || w.endDate === endDate).sort(archive.sort);
        this.setData({ member, initial: Array.from(member.name || '?')[0], courses, workouts, count: courses.length,
          totalCount: allCourses.length + allWorkouts.length, error: '' });
      } catch (error) {
        this.setData({ member: null, courses: [], workouts: [], count: 0, totalCount: 0, error: error.message });
      }
    },
    chooseFilter(event) {
      const filter = event.currentTarget.dataset.filter;
      if (!this.data.filters.includes(filter)) return;
      this.setData({ filter });
      this.refresh();
    },
    pickFilter(event) { this.chooseFilter({ currentTarget: { dataset: { filter: this.data.filters[Number(event.detail.value)] } } }); },
    pickMonth(event) { this.setData({ month: event.detail.value }); this.refresh(); },
    pickEnd(event) { this.setData({ endDate: event.detail.value }); this.refresh(); },
    clearFilters() { this.setData({ month: '', endDate: '', filter: '全部' }); this.refresh(); },
    openCourse(event) { this.openOwnedCourse(event, '/pages/course-detail/index?id='); },
    openReport(event) { this.openOwnedCourse(event, '/pages/session-report/index?courseId='); },
    openOwnedCourse(event, route) {
      const course = store.byId('courses', event.currentTarget.dataset.id);
      if (!course || course.archived || course.memberId !== this.memberId) {
        wx.showToast({ title: '课程不存在或不属于该会员', icon: 'none' });
        return;
      }
      feedback.navigateTo({ url: route + encodeURIComponent(course.id) });
    },
    openWorkout(event) {
      const workout = store.byId('workouts', event.currentTarget.dataset.id);
      if (!workout || workout.memberId !== this.memberId) { wx.showToast({ title: '训练记录不可用', icon: 'none' }); return; }
      feedback.navigateTo({ url: '/pages/session-report/index?workoutId=' + encodeURIComponent(workout.id) });
    }
  }))
)));
