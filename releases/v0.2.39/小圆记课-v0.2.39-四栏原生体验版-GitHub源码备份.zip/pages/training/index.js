var defineThemePage=function(config){Page(require('../../utils/theme-page')(config));};
var s=require('../../utils/store');
var archive=require('../../utils/training-archive');
var drafts=require('../../utils/workout-drafts');
var feedback=require('../../utils/page-feedback');
defineThemePage(require('../../utils/back-navigation')('pages/training/index',require('../../utils/feature-page')('training',require('../../utils/page-guard')({data:{detailPage:false,historyFilter:'',logsFrom:'',logsTo:'',planLaunchFilters:['全部','正常训练','重点跟进','课时预警'],planLaunchFilterIndex:0,planLaunchOpen:false,planLaunchQuery:'',planLaunchMemberId:'',planDayIndex:0,planDetailOpen:false,planDetail:null,memberRecordsOpen:false,archiveMemberId:'',archiveMemberName:'',archiveFrom:'',archiveTo:'',archiveRecords:[],archiveTotal:0,archiveError:'',memberArchives:[],tab:'plans',plans:[],workouts:[],exercises:[],members:[],selectedMemberId:'',selectedMemberName:'全部会员',search:'',filterTarget:'全部'},onLoad:function(q){q=q||{};this._detailId=q.planId||'';if(this._detailId)this.setData({detailPage:true});if(q.tab==='logs')this.setData({tab:'logs'});var app=getApp();if(app.globalData&&app.globalData.memberFilterId){this.setData({selectedMemberId:app.globalData.memberFilterId});app.globalData.memberFilterId='';}},onShow:function(){var app=getApp();if(app.globalData&&app.globalData.memberFilterId){this.setData({selectedMemberId:app.globalData.memberFilterId});app.globalData.memberFilterId='';}this.refresh();},refresh:function(){var ms=s.list('members');var plans=require('../../utils/plan-templates').available().map(function(p){return Object.assign({},p,{statusLabel:'通用模板',memberName:''});});var ws=s.list('workouts').map(function(w){return archive.decorate(w,s.memberName(w.memberId));});var es=s.list('exercises');var sel=this.data.selectedMemberId;this.setData({members:ms,memberFilterNames:['全部会员'].concat(ms.map(function(m){return m.name;})),memberFilterIndex:sel?Math.max(0,ms.findIndex(function(m){return m.id===sel;})+1):0,plans:plans,workouts:ws,exercises:es});if(sel){this.setData({selectedMemberName:s.memberName(sel)});}this.applyFilter();this.refreshMemberRecords();if(this._detailId){
 var stored=s.byId('plans',this._detailId),series=stored&&(stored.seriesId||stored.id);
 var latest=plans.find(function(plan){return (plan.seriesId||plan.id)===series;});
 if(latest){if(!this.data.planDetail||this.data.planDetail.id!==latest.id)this.openPlanDetail({currentTarget:{dataset:{id:latest.id}}});}
 else this.setData({planDetail:null,detailMissing:true});
}else if(this.data.planDetailOpen){var current=plans.filter(function(p){return p.id===this.data.planDetail.id;},this)[0];if(!current)this.closePlanDetail();}},applyFilter:function(){var q=(this.data.search||'').toLowerCase(),sel=this.data.selectedMemberId;var plans=this.data.plans.filter(function(p){return (!q||p.name.toLowerCase().indexOf(q)>=0||p.memberName.toLowerCase().indexOf(q)>=0);});var from=this.data.logsFrom,to=this.data.logsTo,error=from&&to&&from>to?'开始日期不能晚于结束日期':'';var workouts=error?[]:this.data.workouts.filter(function(w){return (!sel||w.memberId===sel)&&archive.matches(w,q)&&(!from||(w.endDate&&w.endDate>=from))&&(!to||(w.endDate&&w.endDate<=to));}).sort(archive.sort);this.setData({filteredPlans:plans,filteredWorkouts:workouts,logGroups:archive.days(workouts),logsDateError:error,memberArchives:archive.group(this.data.workouts.filter(function(w){return workouts.some(function(hit){return hit.memberId===w.memberId;});}))});},openPlanDetail:function(e){var p=require('../../utils/plan-templates').read(e.currentTarget.dataset.id);var images=require('../../utils/exercise-images'),es=this.data.exercises;var detail=Object.assign({},p,{days:(p.days||[]).map(function(day){return {name:day.name,actions:day.exerciseNames.map(function(name,index){var ex=es.filter(function(x){return x.name===name;})[0]||{name:name};return {name:name,index:index+1,image:images.path(ex)};})};})});this.setData({planDetail:detail,planDetailOpen:!this._detailId,detailMissing:false,planDayIndex:0});},
viewPlan:function(e){wx.navigateTo({url:'/pages/training/index?planId='+encodeURIComponent(e.currentTarget.dataset.id)});},
closePlanDetail:function(){this.setData({planDetailOpen:false,planDetail:null});},
openMemberRecords:function(e){var id=e.currentTarget.dataset.id;if(!this.data.workouts.some(function(w){return w.memberId===id;}))return;this.setData({archiveMemberId:id,archiveMemberName:s.memberName(id),archiveFrom:'',archiveTo:'',archiveError:'',memberRecordsOpen:true});this.refreshMemberRecords();},
closeMemberRecords:function(){this.setData({memberRecordsOpen:false});},
refreshMemberRecords:function(){if(!this.data.memberRecordsOpen)return;var id=this.data.archiveMemberId,from=this.data.archiveFrom,to=this.data.archiveTo;var all=this.data.workouts.filter(function(w){return w.memberId===id;});var error=from&&to&&from>to?'开始日期不能晚于结束日期':'';var rows=error?[]:all.filter(function(w){return (!from||(w.endDate&&w.endDate>=from))&&(!to||(w.endDate&&w.endDate<=to));}).sort(archive.sort);this.setData({archiveMemberName:s.memberName(id),archiveTotal:all.length,archiveRecords:rows,archiveError:error});},
onArchiveDate:function(e){var field=e.currentTarget.dataset.field;if(field!=='archiveFrom'&&field!=='archiveTo')return;var patch={};patch[field]=e.detail.value;this.setData(patch);this.refreshMemberRecords();},
clearArchiveDates:function(){this.setData({archiveFrom:'',archiveTo:''});this.refreshMemberRecords();},
noop:function(){},
chooseTab:function(e){var tab=e.currentTarget.dataset.tab;if(tab==='plans'||tab==='logs')this.setData({tab:tab});},onSearch:function(e){this.setData({search:e.detail.value});this.applyFilter();},clearMemberFilter:function(){this.setData({selectedMemberId:'',selectedMemberName:'全部会员'});this.applyFilter();},newPlan:function(){wx.navigateTo({url:'/pages/plan-form/index'});},newWorkout:function(){wx.navigateTo({url:'/pages/workout/index'+(this.data.selectedMemberId?'?memberId='+this.data.selectedMemberId:'')});},openLibrary:function(){wx.navigateTo({url:'/pages/exercise-library/index'});},newVersion:function(e){wx.navigateTo({url:'/pages/plan-form/index?sourceId='+e.currentTarget.dataset.id});},filterMember:function(e){var id=e.currentTarget.dataset.id;wx.navigateTo({url:'/pages/member-detail/index?id='+id});},memberName:function(id){return s.memberName(id);},setPlanDay:function(e){
  var index=Number(e.currentTarget.dataset.index);
  if(this.data.planDetail.days[index])this.setData({planDayIndex:index});
},
goWorkoutForPlan:function(e){
  var plan=require('../../utils/plan-templates').read(e.currentTarget.dataset.id);
  var index=this.data.planDetail&&this.data.planDetail.id===plan.id?this.data.planDayIndex:0;
  if(!plan.days[index])throw Error('训练日已变化，请重新选择。');
  this._launchPlan={id:plan.id,index:index,expected:JSON.stringify(plan)};
  this.setData({planLaunchOpen:true,planLaunchFilterIndex:0,planLaunchQuery:'',planLaunchMemberId:'',planLaunchLabel:plan.name,planLaunchStage:'member',planLaunchDays:plan.days});
  this.filterLaunchMembers('');
},
filterLaunchMembers:function(query){
  var q=query.trim().toLowerCase(),filter=this.data.planLaunchFilters[this.data.planLaunchFilterIndex];
  var threshold=Number((s.get('reminderRules')||{}).firstWarning||5);
  var members=s.visibleMembers().filter(function(m){
    if(m.status==='已结课'||(q&&(m.name+' '+(m.phone||'')).toLowerCase().indexOf(q)<0))return false;
    if(filter==='重点跟进')return (m.tags||[]).includes(filter);
    if(filter==='课时预警')return s.activePackages(m.id).reduce(function(n,p){return n+Number(p.remaining||0);},0)<=threshold;
    return filter==='全部'||m.status===filter;
  });
  this.setData({planLaunchQuery:query,planLaunchMembers:members});
},
pickPlanLaunchFilter:function(e){this.setData({planLaunchFilterIndex:Number(e.detail.value)});this.filterLaunchMembers(this.data.planLaunchQuery);},
onPlanLaunchSearch:function(e){this.filterLaunchMembers(e.detail.value);},
pickPlanMember:function(e){this.setData({planLaunchMemberId:e.currentTarget.dataset.id});},
selectLaunchMember:function(e){
 this.pickPlanMember(e);
 if(this.data.planLaunchDays.length===1)this.confirmPlanLaunch();
 else this.setData({planLaunchStage:'day'});
},
backToLaunchMembers:function(){this.setData({planLaunchStage:'member'});},
selectLaunchDay:function(e){
 var index=Number(e.currentTarget.dataset.index);
 if(this._launchPlan&&this.data.planLaunchDays[index]){this._launchPlan.index=index;this.confirmPlanLaunch();}
},
closePlanLaunch:function(){this._launchPlan=null;this.setData({planLaunchOpen:false,planLaunchDrafts:[],planLaunchError:''});},
selectLaunchDraft:function(e){this.confirmPlanLaunch(e.currentTarget.dataset.id);},
confirmPlanLaunch:function(draftId){
  var launch=this._launchPlan,id=this.data.planLaunchMemberId;
  if(!launch||!id||launch.navigating)return;
  var plan=s.byId('plans',launch.id);
  if(JSON.stringify(plan)!==launch.expected||!s.visibleMembers().some(function(m){return m.id===id&&m.status!=='已结课';})){
    this.setData({planLaunchError:'训练计划或会员已变化，请关闭后重新选择。'});
    return;
  }
  var eligible=drafts.resumable(id,'');
  var chosen=draftId?eligible.find(function(row){return row.id===draftId;}):eligible.length===1?eligible[0]:null;
  if(draftId&&(!chosen||!launch.draftSnapshots||drafts.signature(chosen)!==launch.draftSnapshots.get(draftId))){
    this.setData({planLaunchError:'这份草稿已变化，请关闭后重新选择。'});
    return;
  }
  if(!draftId&&eligible.length>1){
    launch.draftSnapshots=new Map(eligible.map(function(row){return [row.id,drafts.signature(row)];}));
    this.setData({planLaunchStage:'draft',planLaunchDrafts:eligible.map(function(row){
      return {id:row.id,date:row.data.date,time:row.data.time};
    })});
    return;
  }
  var self=this;
  var url='/pages/workout/index?memberId='+encodeURIComponent(id)+'&planId='+encodeURIComponent(launch.id)+'&planDay='+launch.index;
  url+=chosen?'&draftId='+encodeURIComponent(chosen.id)+'&planDraft=1&draftUpdatedAt='+chosen.updatedAt:'&fresh=1';
  launch.navigating=true;
  feedback.navigateTo({
    url:url,
    success:function(){self.closePlanLaunch();},
    fail:function(){launch.navigating=false;}
  });
},
pickHistoryMember:function(e){
  var index=Number(e.detail.value),member=this.data.members[index-1];
  this.setData({selectedMemberId:member?member.id:'',memberFilterIndex:index});
  this.applyFilter();
},
openHistoryFilter:function(e){
 var kind=e.currentTarget.dataset.kind;
 this.setData({historyFilter:kind,historyMemberQuery:'',historyMembers:this.data.members,filterFrom:this.data.logsFrom,filterTo:this.data.logsTo,filterDateError:''});
},
closeHistoryFilter:function(){this.setData({historyFilter:''});},
searchHistoryMembers:function(e){
 var query=e.detail.value;
 this.setData({historyMemberQuery:query,historyMembers:this.data.members.filter(function(m){return (m.name+' '+(m.phone||'')).indexOf(query.trim())>=0;})});
},
selectHistoryMember:function(e){
 var id=e.currentTarget.dataset.id||'',m=this.data.members.find(function(row){return row.id===id;});
 this.setData({selectedMemberId:id,selectedMemberName:m?m.name:'全部会员'});
 this.applyFilter();this.closeHistoryFilter();
},
stageLogsDate:function(e){
 var field=e.currentTarget.dataset.field;
 if(field==='filterFrom'||field==='filterTo'){var patch={filterDateError:''};patch[field]=e.detail.value;this.setData(patch);}
},
clearStagedDates:function(){this.setData({filterFrom:'',filterTo:'',filterDateError:''});},
applyLogsDates:function(){
 var from=this.data.filterFrom,to=this.data.filterTo;
 if(from&&to&&from>to){this.setData({filterDateError:'开始日期不能晚于结束日期'});return;}
 this.setData({logsFrom:from,logsTo:to});
 this.applyFilter();this.closeHistoryFilter();
},
resetHistoryFilters:function(){
 this.setData({selectedMemberId:'',selectedMemberName:'全部会员',logsFrom:'',logsTo:''});this.applyFilter();this.closeHistoryFilter();
},
onLogsDate:function(e){
  var key=e.currentTarget.dataset.field;
  if(key!=='logsFrom'&&key!=='logsTo')return;
  var patch={};patch[key]=e.detail.value;
  this.setData(patch);this.applyFilter();
},
clearLogsDates:function(){this.setData({logsFrom:'',logsTo:''});this.applyFilter();},
deletePlan:function(e){var r=require('../../utils/plan-templates'),p=r.read(e.currentTarget.dataset.id),expected=JSON.stringify(p),self=this;require('../../utils/page-feedback').showModal({title:'删除训练计划',content:'删除「'+p.name+'」及其版本后，将不再出现在可选模板中。已经保存的训练记录与课程保留。',confirmText:'删除计划',confirmColor:'#A35D4C',success:function(result){if(!result.confirm)return;r.remove(p.id,expected);require('../../utils/local-state').afterCommit(function(){if(self.data.detailPage)self.requestPageLeave();else self.refresh();wx.showToast({title:'计划已删除',icon:'success'});});}});},openWorkoutDetail:function(e){var id=e.currentTarget.dataset.id;if(!s.byId('workouts',id)){wx.showToast({title:'训练记录不存在',icon:'none'});return;}wx.navigateTo({url:'/pages/session-report/index?workoutId='+encodeURIComponent(id)});},editWorkout:function(e){require('../../utils/workout-actions').edit(e.currentTarget.dataset.id);},deleteWorkout:function(e){var self=this;require('../../utils/workout-actions').remove(e.currentTarget.dataset.id,function(){self.refresh();});},editExercise:function(){wx.navigateTo({url:'/pages/exercise-library/index'});}}))));
