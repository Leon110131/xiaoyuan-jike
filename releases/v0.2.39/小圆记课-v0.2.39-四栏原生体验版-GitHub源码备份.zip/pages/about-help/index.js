const store = require('../../utils/store');
const tickets = require('../../utils/coach-feedback');
const service = require('../../utils/local-service');
const admin = require('../../utils/admin-access');

const sections = { faq: '常见问题', feedback: '问题反馈', legal: '协议与规则' };
const faq = [
  { question: '体验版的数据保存在哪里？', answer: '首次进入是空白工作空间。数据保存在本机微信小程序缓存中，不会同步到云端。请使用虚构测试数据。' },
  { question: '体验功能有期限和人数限制吗？', answer: '本独立教练体验版开放全部教练功能，不设使用期限或会员人数限制。' },
  { question: '会员需要注册或登录吗？', answer: '小圆记课面向独立健身教练。普通会员无需注册或登录，也不在平台内购课。' },
  { question: '如何反馈功能问题？', answer: '在「问题反馈」里写下所在页面、操作步骤和问题现象。保存到本机后，可复制并自行转发。' }
];

function feedbackRows() {
  const developer = admin.isDeveloper();
  return tickets.ownTickets().map(row => ({
    ...row, reply: developer ? row.reply || '' : '',
    statusLabel: developer ? row.statusLabel || '本地待发送' : '本地待发送'
  }));
}

function feedbackTime(value) {
  const date = new Date(value);
  if (!value || isNaN(date.getTime())) return value || '';
  const time = [date.getHours(), date.getMinutes()].map(part => String(part).padStart(2, '0')).join(':');
  return store.formatDate(date) + ' ' + time;
}

const config = {
  data: {
    featureGuides: require('../../utils/feature-guide'), faq, faqIndex: 0,
    legalDocuments: require('../../utils/legal-documents').list(),
    appVersion: (getApp().globalData.demoVersion || '0.1').split('-')[0],
    title: '帮助与反馈', helpSection: '', featureDetailOpen: false, featureDetail: null,
    scrollTop: 0, serviceOpen: false, showFeedback: false, scrollingToFeedback: false,
    feedbackTitle: '', feedbackText: '', feedbackId: '', errors: {}, feedbacks: [], canFeedback: false, notice: null
  },

  onShow() {
    const canFeedback = store.get('demoRole') === 'coach';
    this.setData({ canFeedback, feedbacks: canFeedback ? feedbackRows().map(row => ({
      ...row, displayTime: feedbackTime(row.updatedAt)
    })) : [] });
  },

  navigateSection(patch) {
    this.setData({ scrollTop: 1 - this.data.scrollTop, scrollingToFeedback: false, notice: null, ...patch });
  },

  openSection(event) {
    const section = event.currentTarget.dataset.section;
    if (!Object.prototype.hasOwnProperty.call(sections, section) || section === 'feedback' && !this.data.canFeedback) return;
    this.navigateSection({ helpSection: section, title: sections[section], serviceOpen: false });
  },
  closeHelpSection() { this.navigateSection({ helpSection: '', title: '帮助与反馈' }); },
  openService() { this.setData({ serviceOpen: true }); },
  closeService() { this.setData({ serviceOpen: false }); },

  openFeature(event) {
    const featureDetail = this.data.featureGuides.find(guide => guide.id === event.currentTarget.dataset.target);
    if (featureDetail) this.navigateSection({ featureDetail, featureDetailOpen: true, title: '功能说明' });
  },
  closeFeatureDetail() { this.navigateSection({ featureDetail: null, featureDetailOpen: false, title: '帮助与反馈' }); },
  toggleFaq(event) {
    const index = Number(event.currentTarget.dataset.index);
    this.setData({ faqIndex: this.data.faqIndex === index ? -1 : index });
  },
  openLegal(event) {
    wx.navigateTo({ url: '/pages/legal/index?kind=' + encodeURIComponent(event.currentTarget.dataset.kind) });
  },

  openFeedback() {
    if (!this.data.canFeedback || this.data.showFeedback) return;
    this.navigateSection({
      showFeedback: true, title: '填写问题反馈', feedbackTitle: '', feedbackText: '',
      feedbackId: store.uid('feedback_request'), errors: {}
    });
  },
  closeFeedback() {
    this.finishKeyboardEditing();
    this.navigateSection({ showFeedback: false, title: sections.feedback, errors: {}, feedbackId: '' });
  },
  onFeedbackTitle(event) {
    this.setData({ feedbackTitle: event.detail.value, errors: { ...this.data.errors, title: '' } });
  },
  onFeedbackText(event) {
    this.setData({ feedbackText: event.detail.value, errors: { ...this.data.errors, description: '' } });
  },
  submitFeedback() {
    if (!this.data.showFeedback || this._submitting || !this.data.canFeedback) return false;
    this.finishKeyboardEditing();
    const title = this.data.feedbackTitle.trim();
    const description = this.data.feedbackText.trim();
    const errors = {};
    if (!title) errors.title = '请填写问题标题';
    else if (title.length > 100) errors.title = '问题标题最多 100 字';
    if (!description) errors.description = '请填写问题描述';
    else if (description.length > 2000) errors.description = '问题描述最多 2,000 字';
    this.setData({ errors, notice: null, scrollingToFeedback: false });
    if (Object.keys(errors).length) return false;
    this._submitting = true;
    try {
      const result = service.execute(() => {
        store.assertCoachWrite();
        tickets.submitCoachFeedback({ title, description, requestId: this.data.feedbackId });
      });
      if (!result.ok) {
        this.setData({ notice: { text: '反馈未保存，输入已保留，请重试。', error: true }, scrollingToFeedback: true });
        return false;
      }
      this.closeFeedback();
      this.onShow();
      this.setData({ notice: { text: '反馈已保存在本机，可复制后自行转发。' } });
      return true;
    } finally {
      this._submitting = false;
    }
  },

  copyFeedback() {
    if (!this.data.canFeedback) return;
    const rows = feedbackRows();
    if (!rows.length) return;
    const data = '小圆记课 · 问题反馈\n' + rows.map((row, index) =>
      '【反馈 ' + (index + 1) + '：' + row.title + '】\n更新时间：' + row.updatedAt +
      '\n问题描述：\n' + row.description + (row.reply ? '\n本地演示回复：' + row.reply : '')
    ).join('\n\n');
    const fail = () => this.setData({ notice: { text: '复制失败，请重试。', error: true } });
    try {
      wx.setClipboardData({
        data,
        success: () => this.setData({ notice: { text: '反馈已复制，可自行转发。' } }),
        fail
      });
    } catch (error) {
      fail();
    }
  },

  backHelp() {
    if (this.data.serviceOpen) this.closeService();
    else if (this.data.showFeedback) this.closeFeedback();
    else if (this.data.featureDetailOpen) this.closeFeatureDetail();
    else if (this.data.helpSection) this.closeHelpSection();
    else this.requestPageLeave();
  }
};

Page(require('../../utils/theme-page')(require('../../utils/back-navigation')('pages/about-help/index', config)));
