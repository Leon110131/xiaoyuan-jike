const store = require('../../utils/store');
const records = require('../../utils/manual-finance');
const validate = require('../../utils/validation');
const service = require('../../utils/local-service');
const feedback = require('../../utils/page-feedback');

const categories = ['课时费用', '其他收入', '营养咨询', '场地费用', '器械费用', '交通费用', '其他支出'];
const defaultCategory = type => type === 'expense' ? '场地费用' : '其他收入';

Page(require('../../utils/theme-page')(require('../../utils/back-navigation')('pages/finance-entry/index',
  require('../../utils/feature-page')('finance', {
    data: { entryId: '', type: 'income', date: '', amount: '', category: '其他收入', categories,
      categoryIndex: 1, notes: '', fieldErrors: {}, operationError: null, saving: false, saved: false, receipt: '', focusField: '' },
    onLoad(q = {}) {
      this.sourceMonth = q.month || '';
      this.setData({ entryId: q.id || '' });
      if (q.id) {
        const result = service.execute(() => records.read(q.id));
        if (!result.ok) {
          this.setData({ operationError: result.error, cannotEdit: true });
          return;
        }
        const row = result.data;
        if (this.sourceMonth && row.date.slice(0, 7) !== this.sourceMonth) {
          this.setData({ operationError: { message: '记录月份已变化，请返回明细核对。' }, cannotEdit: true });
          return;
        }
        this.originalMonth = row.date.slice(0, 7);
        this.expected = JSON.stringify(row);
        this.setData({ type: row.type, date: row.date, amount: String(row.amount), category: row.category,
          categoryIndex: categories.indexOf(row.category), notes: row.notes || '' });
        return;
      }
      const type = q.type === 'expense' ? 'expense' : 'income';
      const category = defaultCategory(type);
      const date = store.formatDate(new Date());
      this.sourceMonth = this.sourceMonth || date.slice(0, 7);
      this.setData({ type, date, category, categoryIndex: categories.indexOf(category) });
    },
    chooseType(e) {
      const type = e.currentTarget.dataset.type;
      if ((type !== 'expense' && type !== 'income') || type === this.data.type) return;
      const category = defaultCategory(type);
      this.setData({ type, category, categoryIndex: categories.indexOf(category),
        fieldErrors: { ...this.data.fieldErrors, category: '' } });
    },
    changeField(field, value) {
      this.setData({ [field]: value, fieldErrors: { ...this.data.fieldErrors, [field]: '' } });
    },
    onAmount(e) { this.changeField('amount', e.detail.value); },
    onDate(e) { this.changeField('date', e.detail.value); },
    onCategory(e) {
      const index = Number(e.detail.value);
      this.changeField('category', categories[index] || '');
      this.setData({ categoryIndex: index });
    },
    onNotes(e) { this.setData({ notes: e.detail.value }); },
    requestField(e) {
      const field = e.detail.fieldId;
      if (field && !this.data.saving && !this.data.saved && !this.data.cannotEdit) this.setData({ focusField: field });
    },
    clearFieldFocus() { this.setData({ focusField: '' }); },
    save() {
      if (this.data.saving || this.data.saved || this.data.cannotEdit || this.data.featureLocked) return;
      this.finishKeyboardEditing();
      const { entryId, type, amount, date, category, notes } = this.data;
      const fieldErrors = {};
      const checks = {
        amount: () => {
          validate.financialAmount(amount);
          validate.assert(!/\.\d{3,}/.test(amount), '金额最多保留两位小数。');
        },
        category: () => validate.financialCategory(category),
        date: () => validate.date(date, '收支日期')
      };
      for (const field of Object.keys(checks)) {
        try { checks[field](); } catch (error) { fieldErrors[field] = error.message; }
      }
      this.setData({ fieldErrors, operationError: null });
      if (Object.keys(fieldErrors).length) return;

      this.setData({ saving: true });
      const fields = { type, amount, date, category, notes };
      const result = service.execute(() => records.save(fields, entryId, this.expected));
      if (!result.ok) {
        this.setData({ saving: false, operationError: result.error, cannotEdit: result.error.code === 'CONFLICT' });
        return;
      }
      const moved = date.slice(0, 7) !== (entryId ? this.originalMonth : this.sourceMonth);
      this.returnToList = Boolean(entryId && moved);
      const receipt = moved ? (entryId ? '已移至 ' : '已记入 ') + records.monthLabel(date) : '记录已保存';
      this.setData({ saving: false, saved: true, receipt });
      this.returnSaved();
    },
    returnSaved() {
      if (!this.data.saved || this._returning) return;
      this._returning = true;
      const pages = typeof getCurrentPages === 'function' ? getCurrentPages() : [];
      const source = pages[pages.length - 3];
      const delta = this.returnToList && source && source.route === 'pages/statistics-detail/index' &&
        !source.recordKey && source.data.month === this.originalMonth ? 2 : 1;
      const options = {
        success: () => feedback.showToast({ title: this.data.receipt, icon: 'none', duration: 2400 }),
        fail: () => { this._returning = false; }
      };
      if (pages.length === 1) feedback.switchTab({ url: '/pages/statistics/index', ...options });
      else feedback.navigateBack({ delta, ...options });
    },
    cancel() {
      if (this.data.saving) return;
      if (this.data.saved) this.returnSaved();
      else this.requestPageLeave();
    }
  }))));
