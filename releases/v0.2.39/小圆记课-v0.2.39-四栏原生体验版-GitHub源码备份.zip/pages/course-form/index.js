const feedback = require('../../utils/page-feedback');
const local = require('../../utils/local-state');
const setTimeout = local.setTimeoutAfterCommit;
const s = require('../../utils/store');
const grid = require('../../utils/calendar-grid');
const dateLabel = require('../../utils/course-read-view').dateLabel;
const validation = require('../../utils/validation');
const withUnsaved = require('../../utils/unsaved-form');
const durations = [30, 45, 60, 75, 90, 120];

const config = {
  data: {
    courseId: '', pageTitle: '新建预约', routeMissing: false, saved: false, members: [],
    memberMatches: [], memberIndex: 0, noMembers: false, memberLocked: false,
    courseMemberOpen: false, memberQuery: '', memberFilter: '全部', memberFilters: ['全部', '正常训练', '重点跟进', '课时预警'],
    form: { memberId: '', date: s.formatDate(new Date()), time: '18:00', duration: 60, location: '', title: '私教训练', notes: '', repeat: false, repeatWeeks: 4 },
    durationOptions: durations, durationIndex: 2, durationLabels: durations.map(value => value + ' 分钟'),
    endLabel: '', repeatSummary: '', saveLabel: '保存 1 节预约', fieldError: ''
  },
  onLoad(query) {
    const q = query || {};
    const existing = q.id ? s.byId('courses', q.id) : null;
    if (q.id && (!existing || existing.archived || existing.status !== 'scheduled')) {
      this.setData({ routeMissing: true, pageTitle: '调整预约' });
      return;
    }
    this._originalCourse = existing ? JSON.stringify(existing) : '';
    const members = s.visibleMembers().filter(member => member.status !== '已结课');
    if (existing && !members.some(member => member.id === existing.memberId)) {
      const linked = s.byId('members', existing.memberId);
      if (linked) members.push(linked);
    }
    const ix = Math.max(0, members.findIndex(member => member.id === (existing ? existing.memberId : q.memberId)));
    const form = Object.assign({}, this.data.form);
    if (existing) {
      Object.assign(form, { memberId: existing.memberId, date: existing.date, time: existing.time,
        duration: existing.duration, location: existing.location || '', title: existing.title || '', notes: existing.notes || '' });
    } else {
      if (members[ix]) form.memberId = members[ix].id;
      if (q.date) { validation.date(q.date, '排课日期'); form.date = q.date; }
      if (q.time && /^([01]\d|2[0-3]):[0-5]\d$/.test(q.time)) form.time = q.time;
      if (durations.includes(Number(q.duration))) form.duration = Number(q.duration);
    }
    this.setData({ members, memberIndex: ix, noMembers: !members.length, courseId: existing ? existing.id : '',
      memberLocked: Boolean(existing && existing.workoutId), pageTitle: existing ? '调整预约' : '新建预约',
      durationIndex: Math.max(0, durations.indexOf(Number(form.duration))) });
    this.updateForm(form);
  },
  updateForm(patch) {
    const form = Object.assign({}, this.data.form, patch);
    const end = grid.minute(form.time) + Number(form.duration);
    const count = Number(form.repeatWeeks);
    const valid = Number.isInteger(count) && count >= 1 && count <= 52;
    const lastDate = form.repeat && valid ? grid.shift(form.date, (count - 1) * 7) : '';
    const formDateLabel = dateLabel(form.date);
    this.setData({ form, formDateLabel, fieldError: '', operationError: null, endLabel: (end >= 1440 ? '次日 ' : '') + grid.time(end % 1440),
      repeatSummary: lastDate ? '每' + formDateLabel.split(' ')[1] + ' ' + form.time + '，至 ' + dateLabel(lastDate, false) : '',
      saveLabel: this.data.courseId ? '保存修改' : form.repeat && !valid ? '保存预约' : '保存 ' + (form.repeat ? count : 1) + ' 节预约' });
  },
  openCourseMembers() {
    if (this.data.memberLocked) return;
    this.setData({ courseMemberOpen: true, memberQuery: '', memberFilter: '全部' });
    this.filterCourseMembers();
  },
  closeCourseMembers() { this.setData({ courseMemberOpen: false }); },
  filterCourseMembers() {
    const query = this.data.memberQuery.trim().toLowerCase();
    const filter = this.data.memberFilter;
    const threshold = Number((s.get('reminderRules') || {}).firstWarning || 5);
    const memberMatches = this.data.members.map(member => ({
      id: member.id, name: member.name, initial: (member.name || '会').slice(0, 1), phone: member.phone || '',
      status: member.status, tags: member.tags || [],
      remaining: s.activePackages(member.id).reduce((sum, pack) => sum + Number(pack.remaining || 0), 0)
    })).filter(member => (!query || member.name.toLowerCase().includes(query) || member.phone.includes(query)) &&
      (filter === '全部' || (filter === '重点跟进' && member.tags.includes(filter)) ||
        (filter === '课时预警' && member.remaining <= threshold) || member.status === filter));
    this.setData({ memberMatches });
  },
  searchCourseMembers(event) {
    this.setData({ memberQuery: event.detail.value });
    this.filterCourseMembers();
  },
  chooseCourseMemberFilter(event) {
    this.setData({ memberFilter: event.currentTarget.dataset.value });
    this.filterCourseMembers();
  },
  pickCourseMember(event) {
    const index = this.data.members.findIndex(member => member.id === event.currentTarget.dataset.id);
    if (index >= 0) this.onMemberChange({ detail: { value: index } });
    this.closeCourseMembers();
  },
  onMemberChange(event) {
    const index = Number(event.detail.value);
    const member = this.data.members[index];
    if (!member || this.data.memberLocked) return;
    this.setData({ memberIndex: index });
    this.updateForm({ memberId: member.id });
  },
  onDate(event) { this.updateForm({ date: event.detail.value }); },
  onTime(event) { this.updateForm({ time: event.detail.value }); },
  onDuration(event) {
    const index = Number(event.detail.value);
    this.setData({ durationIndex: index });
    this.updateForm({ duration: durations[index] });
  },
  onInput(event) { this.updateForm({ [event.currentTarget.dataset.key]: event.detail.value }); },
  toggleRepeat(event) { this.updateForm({ repeat: Boolean(event.detail.value) }); },
  onRepeatWeeks(event) { this.updateForm({ repeatWeeks: event.detail.value }); },
  addFirstMember() { feedback.navigateTo({ url: '/pages/member-form/index' }); },
  onShow() {
    if (!this.data.noMembers || this.data.routeMissing) return;
    const members = s.visibleMembers().filter(member => member.status !== '已结课');
    if (!members.length) return;
    this.setData({ members, memberIndex: 0, noMembers: false });
  },
  cancel() { this.requestPageLeave(); },
  save() {
    if (this.data.routeMissing || this.data.saved) return false;
    if (!s.coachWriteAllowed('calendar')) {
      feedback.showToast({ title: '当前体验账号不可用，请重新打开', icon: 'none', duration: 2300 });
      return;
    }
    this.setData({ fieldError: '' });
    const f = this.data.form;
    if (!f.memberId) {
      this.setData({ fieldError: '请选择会员。' });
      feedback.showToast({ title: '请先选择会员', icon: 'none' });
      return;
    }
    const course = { memberId: f.memberId, date: f.date, time: f.time, duration: Number(f.duration),
      location: f.location, title: f.title, notes: f.notes };
    const count = Number(f.repeatWeeks);
    const errors = require('../../utils/operation-errors');
    if (f.repeat && (!Number.isInteger(count) || count < 1 || count > 52)) {
      this.setData({ fieldError: '排课总节数须为 1–52 的整数。' });
      return false;
    }
    let result;
    if (this.data.courseId) {
      const conflict = s.dateRangeConflict(course, this.data.courseId);
      if (conflict) {
        const message = '与 ' + s.memberName(conflict.memberId) + ' 的课程时间重叠，请修改后再保存。';
        this.setData({ fieldError: message });
        feedback.showModal({ title: '发现排课冲突', content: message, showCancel: false });
        return;
      }
      const old = s.byId('courses', this.data.courseId);
      if (!old || old.status !== 'scheduled') {
        feedback.showToast({ title: '仅可调整预约中的课程', icon: 'none' });
        return;
      }
      if (JSON.stringify(old) !== this._originalCourse) throw errors.create('CONFLICT', '课程资料已变化，请返回后重新打开。');
      if (old.workoutId && old.memberId !== course.memberId) {
        wx.showToast({ title: '已关联训练，不能更换会员', icon: 'none' });
        return false;
      }
      s.upsert('courses', Object.assign(old, course));
      result = { ok: true };
    } else {
      result = s.addCourse(Object.assign({}, course));
    }
    if (!result.ok) {
      this.setData({ fieldError: result.msg });
      feedback.showModal({ title: '发现排课冲突', content: result.msg + ' 请修改日期或时间后再保存。', showCancel: false });
      return;
    }
    if (f.repeat && !this.data.courseId) {
      for (let week = 1; week < count; week++) {
        const date = grid.shift(f.date, week * 7);
        const next = s.addCourse(Object.assign({}, course, { date, notes: f.notes + '（重复排课）' }));
        if (!next.ok) throw errors.create('VALIDATION', date + '：' + next.msg + ' 本批预约未保存。');
      }
      feedback.showToast({ title: '已创建 ' + count + ' 节课程', icon: 'success' });
    } else {
      feedback.showToast({ title: this.data.courseId ? '课程已更新' : '已保存排课', icon: 'success' });
    }
    this.setData({ saved: true });
    local.afterCommit(() => this.markFormSaved());
    setTimeout(() => this.requestPageLeave(), 300);
    return true;
  }
};

Page(require('../../utils/theme-page')(require('../../utils/back-navigation')('pages/course-form/index',
  require('../../utils/feature-page')('calendar', withUnsaved('course', require('../../utils/page-guard')(config))))));
