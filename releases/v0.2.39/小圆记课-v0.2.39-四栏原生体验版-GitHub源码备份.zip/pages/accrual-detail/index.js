const store = require('../../utils/store');
const view = require('../../utils/statistics-view');
const feedback = require('../../utils/page-feedback');
const money = value => Number(value || 0).toFixed(2);

Page(require('../../utils/theme-page')(require('../../utils/back-navigation')('pages/accrual-detail/index',
  require('../../utils/feature-page')('finance', {
    data: { memberName: '', error: '', packages: [], memberGroups: [], recognizedTotal: 0,
      recognizedTotalText: '0.00', liabilityTotal: 0, liabilityTotalText: '0.00', remainingLessons: 0,
      rows: [], summaryValue: '', summaryLabel: '', summaryNote: '', readTitle: '', liability: false },
    onLoad(q = {}) {
      this.memberId = q.memberId || '';
      this.setData({ liability: q.mode === 'liability' });
    },
    onShow() { this.refresh(); },
    refresh() {
      try {
        const member = this.memberId && store.byId('members', this.memberId);
        if (this.memberId && !member) throw Error('会员不存在');
        const { liability } = this.data;
        const members = new Map(store.list('members').map(row => [row.id, row]));
        const packages = [];
        let recognizedTotal = 0, liabilityTotal = 0, remainingLessons = 0;
        for (const pack of store.list('packages')) {
          if (member && pack.memberId !== member.id) continue;
          const used = Math.max(0, Number(pack.used || 0)), remaining = Math.max(0, Number(pack.remaining || 0));
          if (!(used > 0 || remaining > 0)) continue;
          const total = Number(pack.total || 0), sale = Number(pack.saleAmount || 0);
          const rate = total > 0 && sale > 0 ? sale / total : 0;
          const eligible = !['closed', 'refunded', 'ended'].includes(pack.status);
          const earned = used * rate, owed = eligible ? remaining * rate : 0;
          const owner = members.get(pack.memberId);
          recognizedTotal += earned;
          liabilityTotal += owed;
          if (eligible) remainingLessons += remaining;
          const status = require('../../utils/package-page-ui').project(pack, store.formatDate(new Date())).statusLabel;
          packages.push({ id: pack.id, memberId: pack.memberId, memberName: owner ? owner.name : '未知会员',
            packageName: pack.name || '私教课时包', statusLabel: status, used, remaining,
            recognizedText: money(earned), liabilityText: money(owed), eligible, earned, owed,
            unitPrice: view.yuan(rate), amountDisplay: view.yuan(liability ? owed : earned),
            unavailable: !!pack.archived || !owner });
        }
        packages.sort((a, b) => a.memberName.localeCompare(b.memberName, 'zh-CN') ||
          a.packageName.localeCompare(b.packageName, 'zh-CN'));
        const groups = new Map();
        for (const pack of packages) {
          if (liability ? !pack.eligible || !pack.remaining : !pack.used) continue;
          if (!groups.has(pack.memberId)) groups.set(pack.memberId, {
            id: pack.memberId, name: pack.memberName, packages: [], amount: 0, unavailable: !members.has(pack.memberId)
          });
          const group = groups.get(pack.memberId);
          group.packages.push(pack);
          group.amount += liability ? pack.owed : pack.earned;
        }
        const memberGroups = Array.from(groups.values(), group => ({ ...group, amountDisplay: view.yuan(group.amount) }));
        const summaryLabel = liability ? '当前未履约估算' : '累计已用课时估算';
        this.setData({ memberName: member ? member.name : '', error: '', packages, memberGroups, recognizedTotal,
          recognizedTotalText: money(recognizedTotal), liabilityTotal, liabilityTotalText: money(liabilityTotal), remainingLessons,
          rows: member ? memberGroups.flatMap(group => group.packages) : memberGroups, liability,
          readTitle: member ? liability ? '未履约明细' : '会员跨月累计' : liability ? '当前未履约估算' : '跨月累计',
          summaryLabel, summaryValue: view.yuan(liability ? Math.round(liabilityTotal * 100) / 100 : recognizedTotal),
          summaryNote: liability ? remainingLessons + ' 节剩余 · 与选月无关' : '按当前课包已用课时 × 单价估算' });
      } catch (error) {
        this.setData({ error: error.message, packages: [], memberGroups: [], rows: [] });
      }
    },
    openMemberEstimate(e) {
      const id = e.currentTarget.dataset.id;
      if (!store.byId('members', id)) {
        wx.showToast({ title: '会员资料已不可用', icon: 'none' });
        return;
      }
      feedback.navigateTo({ url: '/pages/accrual-detail/index?mode=' + (this.data.liability ? 'liability' : 'cumulative') +
        '&memberId=' + encodeURIComponent(id) });
    },
    openMember() { view.openMember(store, this.memberId); },
    openPackage(e) { view.openPackage(store, e.currentTarget.dataset.id, this.memberId); }
  }))));
