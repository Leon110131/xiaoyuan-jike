const store = require('../../utils/store');
const service = require('../../utils/local-service');
const account = require('../../utils/coach-account');
const media = require('../../utils/local-media');
const feedback = require('../../utils/page-feedback');

const config = {
  data: {
    profile: {},
    avatarInitial: '教',
    form: { name: '', brand: '', phone: '', bio: '' },
    fieldErrors: {},
    sourceOpen: false,
    avatarSaving: false,
    saving: false,
    feedback: null,
    scrollToFeedback: false
  },

  onShow() {
    const profile = store.get('coachProfile') || {};
    const avatarInitial = (profile.name || '教').slice(0, 1);
    if (this._draftReady) {
      this.setData({ profile, avatarInitial });
      return;
    }
    this._draftReady = true;
    const form = { name: profile.name || '', brand: profile.brand || '', phone: profile.phone || '', bio: profile.bio || '' };
    this.setData({ profile, avatarInitial, form });
  },

  onUnload() { this._unloaded = true; },

  onInput(event) {
    const key = event.currentTarget.dataset.key;
    if (!Object.prototype.hasOwnProperty.call(this.data.form, key)) return;
    const patch = { ['form.' + key]: event.detail.value };
    if (this.data.fieldErrors[key]) patch['fieldErrors.' + key] = '';
    this.setData(patch);
  },

  chooseAvatar() {
    if (this.data.featureLocked || this.data.avatarSaving || this.data.saving) return;
    this.finishKeyboardEditing();
    this.setData({ sourceOpen: true, feedback: null, scrollToFeedback: false });
  },

  closeAvatarSources() { this.setData({ sourceOpen: false }); },

  backProfile() {
    if (this.data.sourceOpen) this.closeAvatarSources();
    else if (!this.data.avatarSaving && !this.data.saving) this.requestPageLeave();
  },

  showFailure(title, message) {
    this.setData({ feedback: { title, message }, scrollToFeedback: true });
  },

  pickAvatar(event) {
    const source = event.currentTarget.dataset.source;
    if (this.data.featureLocked || !this.data.sourceOpen || this.data.avatarSaving ||
        (source !== 'album' && source !== 'camera')) return;
    this.setData({ sourceOpen: false, avatarSaving: true });
    const fail = error => {
      if (this._unloaded) return;
      this.setData({ avatarSaving: false });
      if (!/cancel/i.test(error && error.errMsg || '')) {
        this.showFailure('头像未保存', '原头像仍在，请重新选择图片。');
      }
    };
    try {
      wx.chooseMedia({
        count: 1,
        mediaType: ['image'],
        sizeType: ['compressed'],
        sourceType: [source],
        success: result => this.saveAvatar(result.tempFiles),
        fail
      });
    } catch (error) {
      fail(error);
    }
  },

  async saveAvatar(files) {
    let avatarPath;
    let profile;
    try {
      const [saved] = await media.saveAll((files || []).slice(0, 1));
      avatarPath = saved.path;
      if (this._unloaded) {
        await media.discard([avatarPath]);
        return;
      }
      const result = service.execute(() => {
        store.assertCoachWrite('profile');
        const profile = { ...store.get('coachProfile'), avatarUrl: avatarPath };
        store.set('coachProfile', profile);
        return profile;
      });
      if (!result.ok) throw result.error;
      profile = result.data;
    } catch (error) {
      if (avatarPath) await media.discard([avatarPath]);
      if (!this._unloaded) this.showFailure('头像未保存', '原头像仍在，请重新选择图片。');
      return;
    } finally {
      if (!this._unloaded) this.setData({ avatarSaving: false });
    }
    this.setData({ profile });
    feedback.showToast({ title: '头像已更新', icon: 'success' });
  },

  save() {
    if (this.data.featureLocked || this.data.avatarSaving || this.data.saving || this._backLeaving) return false;
    this.finishKeyboardEditing();
    this.setData({ saving: true, feedback: null, scrollToFeedback: false });
    const form = this.data.form;
    const name = form.name.trim();
    const phone = form.phone.trim();
    const result = service.execute(() => {
      store.assertCoachWrite('profile');
      const profile = store.get('coachProfile') || {};
      const fieldErrors = {};
      if (!name) fieldErrors.name = '请填写教练名称';
      if (phone && !account.validPhone(phone)) fieldErrors.phone = '请填写有效的 11 位手机号';
      if (!phone && profile.isRegistered) fieldErrors.phone = '注册账号必须保留手机号';
      if (Object.keys(fieldErrors).length) return fieldErrors;

      store.set('coachProfile', {
        ...profile, name, brand: form.brand.trim(), phone, bio: form.bio.trim(),
        initial: name.substring(0, 1), updatedAt: new Date().toISOString()
      });
      return null;
    });
    this.setData({ saving: false, fieldErrors: result.ok && result.data || {} });
    if (!result.ok) {
      this.showFailure('资料未保存', '输入已保留，请重试。');
      return false;
    }
    if (result.data) return false;
    feedback.showToast({ title: '资料已保存', icon: 'success' });
    this.requestPageLeave({ waitForLayer: true });
    return true;
  }
};

Page(require('../../utils/theme-page')(require('../../utils/back-navigation')('pages/profile/index',
  require('../../utils/feature-page')('profile', config))));
