const store = require('../../utils/store');
const api = require('../../utils/admin-service');
const access = require('../../utils/admin-access');
const exportReport = require('../../utils/report-export');
const csv = require('../../utils/experience-admin').csv;

const tabs = [
  { key: 'overview', label: '总览' }, { key: 'coaches', label: '教练账号' },
  { key: 'tickets', label: '问题反馈' }, { key: 'logs', label: '操作日志' }
];
const coachFilters = [{ key: 'all', label: '全部' }, { key: 'active', label: '正常' }, { key: 'suspended', label: '已停用' }];
const ticketActions = [{ key: 'open', label: '待处理' }, { key: 'processing', label: '处理中' }, { key: 'closed', label: '已解决' }];
const ticketFilters = [{ key: 'all', label: '全部' }, ...ticketActions];
const labels = { active: '正常', suspended: '已停用', open: '待处理', processing: '处理中', closed: '已解决' };
const emptyLists = { overview: {}, coaches: [], tickets: [], logs: [], rows: [] };
const columns = {
  coaches: [['id', '账号ID'], ['name', '教练名称'], ['status', '状态'], ['memberCount', '会员数'],
    ['courseCount', '课程数'], ['workoutCount', '训练记录数'], ['lastActive', '最近活动']],
  tickets: [['id', '反馈ID'], ['title', '问题'], ['status', '状态'], ['reply', '处理结果']],
  logs: [['time', '时间'], ['actor', '操作人'], ['action', '操作'], ['target', '对象']]
};
const csvStatus = { active: '正常', suspended: '停用', disabled: '停用', open: '待处理', pending: '待处理',
  processing: '处理中', resolved: '已解决', closed: '已关闭' };
const listLabels = { coaches: '账号列表', tickets: '反馈列表', logs: '操作记录' };
const searchHints = { coaches: '搜索名称、ID 或手机号', tickets: '搜索问题或教练 ID', logs: '搜索操作、对象或操作人' };

function displayTime(value) {
  const d = new Date(value);
  if (!value || isNaN(d.getTime())) return value || '';
  return [d.getHours(), d.getMinutes()].map(n => String(n).padStart(2, '0')).join(':');
}

function displayDate(value) {
  const date = new Date(value);
  return typeof value === 'string' && value.includes('T') && !isNaN(date.getTime()) ? store.formatDate(date) : value || '';
}

function overviewRows(data) {
  return [
    ['账号状态', data.active + ' 正常 / ' + data.suspended + ' 停用'],
    ['近 7 日新增', data.newCoaches + ' 个'], ['近 7 日有记录', data.recentActive + ' 个'],
    ['会员档案', data.memberCount + ' 位'], ['课程记录', data.courseCount + ' 条'],
    ['训练记录', data.workoutCount + ' 条'], ['未关闭反馈', data.openTickets + ' 条']
  ];
}

const config = {
  data: {
    ...emptyLists, tabs, coachFilters, ticketFilters, ticketActions, labels, listLabels, searchHints,
    authorized: false, ready: false, loading: true, readError: false, tab: 'overview',
    search: '', status: 'all', ticketStatus: 'all', listTop: 0, overviewRows: [],
    selectedCoach: null, selectedTicket: null, reason: '', note: '', reply: '', editingNote: false,
    saving: false, statusConfirm: null, exporting: false, error: '', notice: null, lastUpdated: ''
  },

  onLoad() { return this.refresh(); },
  onShow() { if (this._shown) this.refresh(); this._shown = true; },
  onPullDownRefresh() { return this.refresh().finally(() => wx.stopPullDownRefresh()); },

  async refresh() {
    const sequence = (this._loadSequence || 0) + 1;
    this._loadSequence = sequence;
    this.setData({ loading: true, readError: false });
    try {
      const session = await access.session();
      if (sequence !== this._loadSequence) return;
      if (!session.allowed || !access.isDeveloper()) {
        this.setData({ ...emptyLists, authorized: false, ready: false, loading: false, selectedCoach: null, selectedTicket: null, statusConfirm: null });
        return;
      }
      this.setData({ authorized: true });
      const [overview, coaches, tickets, logs] = await Promise.all([api.overview(), api.coaches(), api.tickets(), api.logs()]);
      if (sequence !== this._loadSequence) return;
      this.setData({ overview, coaches,
        tickets: tickets.map(item => ({ ...item, displayDate: displayDate(item.updatedAt) })),
        logs: logs.map(item => ({ ...item, displayTime: displayDate(item.time) + ' ' + displayTime(item.time) })),
        loading: false, ready: true,
        overviewRows: overviewRows(overview), lastUpdated: displayTime(new Date()) });
      this.filter();
    } catch (error) {
      if (sequence === this._loadSequence) this.setData({
        ...emptyLists, authorized: access.isDeveloper(), loading: false, ready: false,
        readError: access.isDeveloper(), selectedCoach: null, selectedTicket: null, statusConfirm: null, notice: null
      });
    }
  },

  chooseTab(event) {
    const tab = event.currentTarget.dataset.tab;
    if (tab === this.data.tab || !tabs.some(item => item.key === tab)) return;
    this.finishKeyboardEditing();
    this.setData({ tab, search: '', status: 'all', ticketStatus: 'all', notice: null, listTop: 1 - this.data.listTop });
    this.filter();
  },
  resetFilters() { this.setData({ search: '', status: 'all', ticketStatus: 'all', notice: null }); this.filter(); },
  onSearch(event) { this.setData({ search: event.detail.value, notice: null }); this.filter(); },
  chooseStatus(event) { this.setData({ status: event.currentTarget.dataset.status, notice: null }); this.filter(); },
  chooseTicketStatus(event) { this.setData({ ticketStatus: event.currentTarget.dataset.status, notice: null }); this.filter(); },
  filter() {
    const { tab, search, status, ticketStatus } = this.data;
    const query = search.trim().toLowerCase();
    const has = (...parts) => parts.join(' ').toLowerCase().includes(query);
    const filtered = {
      coaches: () => this.data.coaches.filter(c => (status === 'all' || c.status === status) && has(c.name, c.id, c.phone)),
      tickets: () => this.data.tickets.filter(t => (ticketStatus === 'all' || t.status === ticketStatus) && has(t.title, t.description, t.coachId)),
      logs: () => this.data.logs.filter(l => has(l.action, l.target, l.actor))
    };
    this.setData({ rows: filtered[tab] ? filtered[tab]() : [] });
  },

  async openCoach(event) {
    this.finishKeyboardEditing();
    const seq = (this._detailSequence || 0) + 1;
    this._detailSequence = seq;
    try {
      const selectedCoach = await api.detail({ id: event.currentTarget.dataset.id });
      if (seq !== this._detailSequence || this.data.tab !== 'coaches') return;
      this._request = null;
      this.setData({ selectedCoach, editingNote: false, reason: '', note: selectedCoach.note || '', error: '' });
    } catch (error) { this.showNotice('无法读取账号', error.message, true); }
  },
  closeCoach() { if (!this.data.saving) this.setData({ selectedCoach: null, error: '' }); },
  toggleNote() { this.setData({ editingNote: !this.data.editingNote, error: '' }); },
  onReason(event) { this.setData({ reason: event.detail.value, error: '' }); },
  onNote(event) { this.setData({ note: event.detail.value, error: '' }); },
  saveCoach() {
    const { selectedCoach: c, editingNote, reason, note, saving, statusConfirm } = this.data;
    if (!c || c.local || saving || statusConfirm) return;
    this.finishKeyboardEditing();
    if (editingNote) {
      if (note.length > 500) return this.setData({ error: '管理备注最多 500 字' });
      return this.submit('saveNote', { id: c.id, note: note.trim() }, 'selectedCoach');
    }
    if (!reason.trim() || reason.length > 500) return this.setData({ error: '请填写操作原因，最多 500 字' });
    const status = c.status === 'active' ? 'suspended' : 'active';
    this.setData({ error: '', statusConfirm: { id: c.id, name: c.name, reason: reason.trim(), expectedStatus: c.status, status } });
  },
  cancelStatus() { if (!this.data.saving) this.setData({ statusConfirm: null, error: '' }); },
  confirmStatus() {
    const { statusConfirm: row, selectedCoach, reason } = this.data;
    if (!row || !selectedCoach || selectedCoach.local || selectedCoach.id !== row.id ||
        selectedCoach.status !== row.expectedStatus || reason.trim() !== row.reason) {
      this.cancelStatus();
      this.setData({ error: '确认内容已变化，请重新核对。' });
      return;
    }
    const { name, ...payload } = row;
    return this.submit('updateCoach', payload, 'selectedCoach');
  },

  openTicket(event) {
    this.finishKeyboardEditing();
    if (!access.isDeveloper()) return this.refresh();
    const selectedTicket = this.data.tickets.find(t => t.id === event.currentTarget.dataset.id);
    if (!selectedTicket) return;
    this._request = null;
    this.setData({ selectedTicket, reply: selectedTicket.reply || '', error: '' });
  },
  closeTicket() { if (!this.data.saving) this.setData({ selectedTicket: null, error: '' }); },
  onReply(event) { this.setData({ reply: event.detail.value, error: '' }); },
  saveTicket(event) {
    const { selectedTicket, reply } = this.data;
    const status = event.currentTarget.dataset.status;
    if (!selectedTicket) return;
    this.finishKeyboardEditing();
    if (reply.length > 2000) return this.setData({ error: '处理回复最多 2,000 字' });
    if (status === 'closed' && !reply.trim()) return this.setData({ error: '标记为已解决前请填写处理结果' });
    return this.submit('updateTicket', { id: selectedTicket.id, status, reply: reply.trim() }, 'selectedTicket');
  },

  async submit(method, row, key) {
    if (this.data.saving) return false;
    const fingerprint = JSON.stringify([method, row]);
    if (!this._request || this._request.fingerprint !== fingerprint) {
      this._request = { fingerprint, id: store.uid('admin_request') };
    }
    this.setData({ saving: true, error: '' });
    try {
      await api[method]({ ...row, requestId: this._request.id });
    } catch (error) {
      const message = String(error && (error.message || error.errMsg) || '');
      const changed = message.includes('账号状态已变化');
      if (changed) {
        this.setData({ statusConfirm: null });
        try { this.setData({ selectedCoach: await api.detail({ id: row.id }) }); } catch (ignored) {}
      }
      const failure = /空间|quota|容量/i.test(message) ? '本机存储空间不足，输入已保留。' : '保存未完成，输入已保留，可重试。';
      this.setData({ saving: false, error: changed ? message : failure });
      return false;
    }
    this._request = null;
    this.setData({ saving: false, statusConfirm: null, [key]: null });
    await this.refresh();
    this.showNotice('本地演示已保存');
    return true;
  },

  showNotice(title, message = '', error = false) {
    this.setData({ notice: { title, message, error } });
    wx.showToast({ title, icon: 'none' });
  },

  async exportData() {
    const { tab, rows, exporting, loading, ready, authorized } = this.data;
    if (!authorized || !access.isDeveloper()) return this.refresh();
    if (exporting || loading || !ready || !columns[tab]) return;
    this.finishKeyboardEditing();
    const data = rows.map(row => ({ ...row, status: csvStatus[row.status] || row.status, dataSource: '本地演示，非真实平台统计' }));
    const fields = [...columns[tab], ['dataSource', '数据来源']].map(([key, label]) => ({ key, label }));
    const text = csv(data, fields);
    const fileName = '小圆记课_' + tabs.find(item => item.key === tab).label + '_' + store.dateOffset(0) + '.csv';
    this.setData({ exporting: true, notice: null });
    try {
      const result = await exportReport({ fileName, text });
      const outcomes = { cancelled: '已取消分享', shared: 'CSV 已分享', clipboard: 'CSV 已复制', 'download-requested': '已请求下载 CSV' };
      this.showNotice(outcomes[result.mode], result.mode === 'clipboard' ? '可粘贴并自行保存。' : '');
      return result;
    } catch (error) {
      this.showNotice('导出未完成', '筛选与列表位置已保留，可重试。', true);
    } finally { this.setData({ exporting: false }); }
  },
  holdExport() {},

  async clearExamples() {
    if (this.data.cleaningSamples || this._loadingCleanup) return;
    this._loadingCleanup = true;
    try {
      const p = await api.previewSamples();
      this._cleanupRequest = store.uid('cleanup_request');
      this.setData({ cleanupReview: p, cleanupError: '', cleanupStale: false, notice: null });
    } catch (error) { this.showNotice('无法读取管理示例', error.message, true); }
    finally { this._loadingCleanup = false; }
  },
  closeSampleCleanup() {
    if (this.data.cleaningSamples) return;
    this.setData({ cleanupReview: null, cleanupError: '', cleanupStale: false });
  },
  async submitSampleCleanup() {
    const { cleanupReview, cleanupStale, cleaningSamples } = this.data;
    if (cleaningSamples || cleanupStale || !cleanupReview || !cleanupReview.total || cleanupReview.blockedReason) return false;
    this.setData({ cleaningSamples: true, cleanupError: '' });
    try {
      const result = await api.clearSamples({ revision: cleanupReview.revision, requestId: this._cleanupRequest });
      this.setData({ cleaningSamples: false, cleanupReview: null });
      await this.refresh();
      this.showNotice('管理示例已清除', '示例教练 ' + result.coaches.length + ' 个 / 示例反馈 ' + result.tickets.length + ' 条。');
      return true;
    } catch (error) {
      const stale = error.code === 'CONFLICT' || error.code === 'VALIDATION';
      this.setData({ cleaningSamples: false, cleanupStale: stale,
        cleanupError: stale ? error.message : '管理示例未清除，原数据已保留，可重试。' });
      return false;
    }
  },
  backToCoach() {
    if (getCurrentPages().length <= 1) wx.redirectTo({ url: '/pages/mine/index' });
    else this.requestPageLeave();
  }
};

Page(require('../../utils/theme-page')(require('../../utils/back-navigation')('pages/experience-admin/index', config)));
