const store = require('../../utils/store');
const service = require('../../utils/local-service');
const account = require('../../utils/coach-account');
const docs = require('../../utils/legal-documents');

const DEFAULT_BRAND = '小圆记课';
const AGREEMENTS = ['privacy', 'service'];
const EMPTY = { name: '', phone: '', code: '', password: '' };
const profileLabels = {
  avatarUrl: '头像引用', bio: '个人简介', email: '旧邮箱', themeId: '主题偏好',
  legalConsents: '已有协议记录', registrationConsent: '已有协议记录',
  password: '旧演示密码记录', code: '旧演示验证码记录'
};
// These fields describe the stored record, rather than coach-entered profile content.
const recordFields = ['initial', 'createdAt', 'updatedAt', 'isRegistered'];

function hasContent(value) {
  if (value == null) return false;
  if (typeof value === 'string') return value.trim() !== '';
  if (typeof value === 'object') return Object.keys(value).length > 0;
  return true;
}

function affectedFields(profile, form) {
  if (profile.isRegistered) return [];
  const next = { name: form.name.trim(), phone: form.phone.trim(), brand: DEFAULT_BRAND };
  return Object.keys(profile).filter(key => !recordFields.includes(key) && hasContent(profile[key])).flatMap(key => {
    const value = profile[key];
    if (key === 'name' || key === 'phone' || key === 'brand') {
      if (String(value).trim() === next[key]) return [];
      if (key === 'brand') return ['个人品牌将恢复为「小圆记课」。'];
      return [key === 'name' ? '教练名称将使用本次填写的名称。' : '手机号将使用本次填写的号码。'];
    }
    if (key === 'themeId' && value === 'blue') return [];
    const label = Object.prototype.hasOwnProperty.call(profileLabels, key) ? profileLabels[key] : '档案字段「' + key + '」';
    return [label + (key === 'legalConsents' || key === 'registrationConsent' ? '将由本次登记记录替换。' : '将被清除。')];
  });
}

const config = {
  data: {
    mode: 'register', form: { ...EMPTY }, agreementsAccepted: false, codeSent: false, codePhone: '',
    impacts: [], errors: {}, operationError: null, registrationConfirmOpen: false, confirmImpacts: [],
    receipt: null, saving: false, scrollTop: 0, scrollToIssue: false
  },

  onShow() {
    const profile = store.get('coachProfile') || {};
    const form = this._profile ? this.data.form : { ...EMPTY, name: profile.name || '', phone: profile.phone || '' };
    this._profile = profile;
    this.setData({ form, impacts: affectedFields(profile, form) });
  },

  setMode(event) {
    const mode = event.currentTarget.dataset.mode;
    if (mode !== 'register' && mode !== 'login') return;
    this.setData({ mode, errors: {}, operationError: null, scrollToIssue: false, scrollTop: 1 - this.data.scrollTop });
  },

  onInput(event) {
    const key = event.currentTarget.dataset.key;
    if (!Object.prototype.hasOwnProperty.call(EMPTY, key)) return;
    const form = { ...this.data.form, [key]: event.detail.value };
    const patch = { form, impacts: affectedFields(this._profile || {}, form), errors: { ...this.data.errors, [key]: '' }, operationError: null };
    if (key === 'phone' && form.phone.trim() !== this.data.form.phone.trim()) {
      form.code = '';
      Object.assign(patch, { codeSent: false, codePhone: '' });
      patch.errors.code = '';
    }
    this.setData(patch);
  },

  showInputError(key, text) {
    this.setData({
      errors: { [key]: text }, operationError: null,
      scrollToIssue: key === 'agreements', scrollTop: 1 - this.data.scrollTop
    });
    return false;
  },

  sendCode() {
    const phone = this.data.form.phone.trim();
    if (!account.validPhone(phone)) return this.showInputError('phone', '请填写有效的 11 位手机号');
    this.setData({ codeSent: true, codePhone: phone, errors: {}, operationError: null });
  },

  onAgreementChange(event) {
    this.setData({
      agreementsAccepted: event.detail.value.includes('accept'),
      errors: { ...this.data.errors, agreements: '' }
    });
  },

  openLegal(event) {
    this.finishKeyboardEditing();
    wx.navigateTo({ url: '/pages/legal/index?kind=' + encodeURIComponent(event.currentTarget.dataset.kind) });
  },

  clear() {
    this.finishKeyboardEditing();
    const form = { ...EMPTY };
    this.setData({
      form, agreementsAccepted: false, codeSent: false, codePhone: '', errors: {},
      operationError: null, impacts: affectedFields(this._profile || {}, form), scrollToIssue: false
    });
  },

  submit() {
    if (this.data.saving || this.data.receipt || this.data.registrationConfirmOpen) return false;
    this.finishKeyboardEditing();
    return this.data.mode === 'register' ? this.register() : this.login();
  },

  registrationSnapshot(profile, consent) {
    const { form, codePhone, codeSent, agreementsAccepted } = this.data;
    return JSON.stringify({ profile, form, codePhone, codeSent, agreementsAccepted, versions: consent.versions });
  },

  register(approval) {
    if (this.data.saving || this.data.receipt || this.data.registrationConfirmOpen && !approval) return false;
    const { form, agreementsAccepted, codeSent, codePhone } = this.data;
    const profile = store.get('coachProfile') || {};
    const consent = docs.accept(AGREEMENTS);
    const snapshot = this.registrationSnapshot(profile, consent);
    if (approval && approval !== snapshot) {
      this.cancelRegistration();
      this.onShow();
      this.setData({ operationError: { message: '资料或提交内容已变化，请重新核对后登记。' }, scrollToIssue: true });
      return false;
    }
    if (!agreementsAccepted) return this.showInputError('agreements', '请阅读并确认两份测试草案');
    if (!form.name.trim()) return this.showInputError('name', '请填写教练名称');
    const phone = form.phone.trim();
    if (!account.validPhone(phone)) return this.showInputError('phone', '请填写有效的 11 位手机号');
    if (!codeSent || codePhone !== phone || form.code !== '123456') {
      return this.showInputError('code', '请获取并填写当前手机号的演示验证码');
    }
    if (form.password.length < 6) return this.showInputError('password', '演示密码至少 6 位');
    if (profile.isRegistered) return this.showInputError('phone', '已登记，请使用模拟登录或修改教练资料');

    const impacts = affectedFields(profile, form);
    if (impacts.length && !approval) {
      this._registrationApproval = snapshot;
      this.setData({ registrationConfirmOpen: true, confirmImpacts: impacts, errors: {}, operationError: null });
      return true;
    }

    this.setData({ saving: true, errors: {}, operationError: null });
    const result = service.execute(() => {
      const saved = store.registerDemoCoach({ name: form.name.trim(), phone, brand: DEFAULT_BRAND, registrationConsent: consent });
      store.setRole('coach');
      return saved;
    });
    this.setData({ saving: false });
    if (!result.ok) {
      this.setData({ operationError: { message: '登记未保存，输入已保留，请重试。' }, scrollToIssue: !approval });
      return false;
    }
    this._registrationApproval = null;
    this._profile = result.data;
    this.setData({
      registrationConfirmOpen: false, confirmImpacts: [], impacts: [], scrollToIssue: false,
      form: { ...form, code: '', password: '' }, codeSent: false, codePhone: '',
      receipt: {
        title: '本机登记完成',
        text: (impacts.length ? '已按确认的范围替换教练资料。会员、课程、课时包和训练等业务记录保留。' : '本机手机号已登记。') + '演示密码未保存。'
      }
    });
    return true;
  },

  confirmRegistration() {
    if (!this.data.saving && this.data.registrationConfirmOpen && this._registrationApproval) {
      return this.register(this._registrationApproval);
    }
    return false;
  },

  cancelRegistration() {
    if (this.data.saving) return;
    this._registrationApproval = null;
    this.setData({ registrationConfirmOpen: false, confirmImpacts: [], operationError: null });
  },

  login() {
    const phone = this.data.form.phone.trim();
    if (!account.validPhone(phone)) return this.showInputError('phone', '请填写有效的 11 位手机号');
    const profile = store.get('coachProfile') || {};
    if (!profile.isRegistered || phone !== profile.phone) {
      this.setData({ errors: { phone: '未找到匹配的演示账号' }, operationError: { message: '请填写已登记的本机手机号。' } });
      return false;
    }
    if (!this.data.form.password.trim()) return this.showInputError('password', '请输入演示密码');
    const result = service.execute(() => store.setRole('coach'));
    if (!result.ok) {
      this.setData({ operationError: { message: '暂未完成模拟登录，请重试。' } });
      return false;
    }
    this.setData({
      form: { ...this.data.form, password: '' }, errors: {}, operationError: null,
      receipt: { title: '模拟登录完成', text: '已匹配本机登记手机号。当前环境只演示登录流程。' }
    });
    return true;
  },

  closeReceipt() { this.setData({ receipt: null }); },
  returnSettings() { this.requestPageLeave({ waitForLayer: true }); },
  backAuth() {
    if (this.data.registrationConfirmOpen) this.cancelRegistration();
    else if (this.data.receipt) this.closeReceipt();
    else this.returnSettings();
  }
};

Page(require('../../utils/theme-page')(require('../../utils/back-navigation')('pages/auth/index', config)));
