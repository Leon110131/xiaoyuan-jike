const feedback = require('../../utils/page-feedback');
const store = require('../../utils/store');
const validate = require('../../utils/validation');
const service = require('../../utils/local-service');
const media = require('../../utils/local-media');

const positions = ['正面', '侧面', '背面', '其他'];
const titles = { add: '添加照片', preview: '照片预览', compare: '照片对比' };

const config = {
  data: {
    memberId: '', member: null, avatar: '', positions, position: '正面', photos: [],
    compareIds: [], comparePhotos: [], missing: {},
    photoScreen: '', detailTitle: '', detailPhotos: [], detailError: false,
    form: {}, sourceOpen: false, uploading: false, uploadError: '', removePhoto: null, removing: false, removeError: ''
  },
  onLoad(query = {}) { this.memberId = query.memberId || ''; },
  onShow() { this.refresh(); },
  refresh() {
    const member = store.byId('members', this.memberId);
    const rows = member ? store.list('photos').filter(row => row.memberId === member.id && row.position === this.data.position)
      .sort((a, b) => b.date.localeCompare(a.date)) : [];
    const comparePhotos = this.data.compareIds.map(id => rows.find(row => row.id === id)).filter(Boolean);
    const compareIds = comparePhotos.map(row => row.id);
    this.setData({
      memberId: this.memberId, member, avatar: member ? Array.from(member.name || '?')[0] : '',
      photos: rows.map(row => ({ ...row, comparing: compareIds.indexOf(row.id) + 1 })),
      comparePhotos, compareIds
    });
  },
  onPosition(event) {
    const position = event.currentTarget && event.currentTarget.dataset.position || positions[Number(event.detail && event.detail.value)];
    if (!positions.includes(position) || position === this.data.position) return;
    this.setData({ position, compareIds: [] });
    this.refresh();
  },
  toggleCompare(event) {
    const id = event.currentTarget.dataset.id;
    if (!this.data.photos.some(row => row.id === id)) return;
    const ids = this.data.compareIds;
    if (!ids.includes(id) && ids.length >= 2) {
      feedback.showToast({ title: '最多选择两张照片对比', icon: 'none' });
      return;
    }
    this.setData({ compareIds: ids.includes(id) ? ids.filter(item => item !== id) : ids.concat(id) });
    this.refresh();
  },
  clearCompare() { this.setData({ compareIds: [] }); this.refresh(); },
  thumbError(event) { this.setData({ missing: { ...this.data.missing, [event.currentTarget.dataset.id]: true } }); },
  preview(event) {
    const row = this.data.photos.find(item => item.id === event.currentTarget.dataset.id);
    if (row) this.openDetail('preview', [row]);
  },
  compare() {
    this.refresh();
    if (this.data.comparePhotos.length === 2) this.openDetail('compare', this.data.comparePhotos);
  },
  openDetail(screen, rows) {
    this.setData({ photoScreen: screen, detailTitle: titles[screen], detailPhotos: rows, detailError: rows.some(row => !row.path) });
  },
  photoReadError(event) {
    if (this.data.detailPhotos.some(row => row.id === event.currentTarget.dataset.id)) this.setData({ detailError: true });
  },
  openAdd() {
    if (!this.data.member || this.data.featureLocked) return;
    this.setData({
      photoScreen: 'add', detailTitle: titles.add, uploadError: '',
      form: { date: store.formatDate(new Date()), position: this.data.position, notes: '' }
    });
  },
  closePhotoScreen() {
    if (this.data.uploading || this.data.removing) return;
    this.finishKeyboardEditing();
    this.setData({ photoScreen: '', detailPhotos: [], detailError: false, sourceOpen: false, removePhoto: null });
  },
  backPhotos() {
    if (this.data.removePhoto) this.closeRemove();
    else if (this.data.sourceOpen) this.closeSources();
    else if (this.data.photoScreen) this.closePhotoScreen();
    else this.requestPageLeave();
  },
  onDate(event) { this.updateForm('date', event.detail.value); },
  onNotes(event) { this.updateForm('notes', event.detail.value); },
  onAddPosition(event) { this.updateForm('position', event.currentTarget.dataset.position); },
  updateForm(key, value) {
    if (!this.data.uploading) this.setData({ form: { ...this.data.form, [key]: value }, uploadError: '' });
  },
  openSources() {
    if (this.data.photoScreen !== 'add' || this.data.uploading) return;
    this.finishKeyboardEditing();
    this.setData({ sourceOpen: true });
  },
  closeSources() { this.setData({ sourceOpen: false }); },
  choosePhoto(event) {
    const source = event.currentTarget.dataset.source;
    if (!this.data.sourceOpen || this.data.uploading || !['album', 'camera'].includes(source)) return;
    const selection = { ...this.data.form, memberId: this.memberId };
    try {
      store.assertCoachWrite('photos');
      validate.assert(store.byId('members', selection.memberId), '会员已不存在。');
      validate.date(selection.date, '拍摄日期');
      validate.assert(positions.includes(selection.position), '照片角度无效。');
      validate.assert(typeof wx.chooseMedia === 'function', '当前微信版本不支持选择照片。');
    } catch (error) {
      this.setData({ sourceOpen: false, uploadError: error.message });
      return;
    }
    this.setData({ sourceOpen: false, uploading: true, uploadError: '' });
    try {
      wx.chooseMedia({
        count: 3, mediaType: ['image'], sourceType: [source], sizeType: ['compressed'],
        success: result => this.saveBatch(selection, result.tempFiles),
        fail: error => {
          const cancelled = /cancel/i.test(error && error.errMsg || '');
          this.setData({ uploading: false, uploadError: cancelled ? '' : '无法选择照片，请检查相册或相机权限后重试。' });
        }
      });
    } catch (error) {
      this.setData({ uploading: false, uploadError: '无法打开照片来源，请重试。' });
    }
  },
  async saveBatch(selection, files) {
    let saved;
    try {
      saved = await media.saveAll(files);
    } catch (error) {
      this.setData({ uploading: false, uploadError: '请检查本机空间和权限后重新选择照片。' });
      return false;
    }
    const outcome = service.execute(() => {
      store.assertCoachWrite('photos');
      validate.assert(store.byId('members', selection.memberId), '会员已不存在。');
      const rows = saved.map(file => ({
        id: store.uid('photo'), ...selection, path: file.path, size: file.size, localOnly: true, persistentLocal: true
      }));
      store.set('photos', rows.concat(store.list('photos')));
    });
    if (!outcome.ok) {
      await media.discard(saved.map(file => file.path));
      this.setData({ uploading: false, uploadError: outcome.error.message });
      return false;
    }
    this.setData({ uploading: false, missing: {} });
    if (selection.position !== this.data.position) this.setData({ position: selection.position, compareIds: [] });
    this.closePhotoScreen();
    this.refresh();
    feedback.showToast({ title: '照片已保存到本机', icon: 'success' });
    return true;
  },
  remove() {
    if (this.data.photoScreen !== 'preview' || this.data.featureLocked || this.data.detailError) return;
    const row = this.data.detailPhotos[0];
    if (row && row.memberId === this.memberId) this.setData({ removePhoto: row, removeError: '' });
  },
  closeRemove() {
    if (!this.data.removing) this.setData({ removePhoto: null, removeError: '' });
  },
  confirmRemove() {
    const target = this.data.removePhoto;
    if (!target || this.data.removing) return false;
    const memberId = this.memberId;
    this.setData({ removing: true, removeError: '' });
    const outcome = service.execute(() => {
      store.assertCoachWrite('photos');
      validate.assert(store.byId('members', memberId), '会员已不存在。');
      const rows = store.list('photos');
      const index = rows.findIndex(row => row.id === target.id && row.memberId === memberId &&
        row.date === target.date && row.position === target.position && row.path === target.path);
      validate.assert(index >= 0, '照片记录已变化，请返回照片列表。');
      rows.splice(index, 1);
      store.set('photos', rows);
    });
    this.setData({ removing: false });
    if (!outcome.ok) {
      this.setData({ removeError: outcome.error.message });
      return false;
    }
    this.closePhotoScreen();
    this.refresh();
    feedback.showToast({ title: '照片记录已移除', icon: 'none' });
    return true;
  }
};

Page(require('../../utils/theme-page')(require('../../utils/back-navigation')('pages/photos/index',
  require('../../utils/feature-page')('photos', config))));
