const store = require('../../utils/store');
const service = require('../../utils/local-service');

const thresholds = [2, 3, 5, 8];
const rules = [
  { key: 'early', label: '提前取消' },
  { key: 'late', label: '临时取消' },
  { key: 'noShow', label: '爽约' },
  { key: 'leave', label: '请假' }
];
const deductionOptions = [
  { value: 0, label: '默认不扣课' },
  { value: 1, label: '默认扣 1 节课' }
];

function view(reminders, cancellations) {
  return {
    threshold: Number(reminders.firstWarning || 5),
    cancelRules: rules.map(rule => ({ ...rule, deduct: !!(cancellations[rule.key] && cancellations[rule.key].deduct) }))
  };
}

const config = {
  data: { threshold: 5, cancelRules: [], rulePicker: null, saving: false, feedback: null },
  onShow() { this.setData(view(store.get('reminderRules') || {}, store.get('cancelRules') || {})); },
  setLowThreshold() {
    if (this.data.featureLocked || this.data.saving) return;
    this.setData({ rulePicker: {
      key: 'threshold', title: '课时预警阈值', current: this.data.threshold,
      options: thresholds.map(value => ({ value, label: '剩余 ' + value + ' 节' }))
    }, feedback: null });
  },
  editCancelRule(event) {
    if (this.data.featureLocked || this.data.saving) return;
    const rule = this.data.cancelRules.find(item => item.key === event.currentTarget.dataset.key);
    if (!rule) return;
    this.setData({ rulePicker: {
      key: rule.key, title: rule.label + '扣课', current: Number(rule.deduct), options: deductionOptions
    }, feedback: null });
  },
  closeRulePicker() {
    if (!this.data.saving) this.setData({ rulePicker: null });
  },
  backRules() {
    if (this.data.rulePicker) this.closeRulePicker();
    else this.requestPageLeave();
  },
  chooseRule(event) {
    const { rulePicker, saving, featureLocked } = this.data;
    const value = Number(event.currentTarget.dataset.value);
    if (!rulePicker || saving || featureLocked || !rulePicker.options.some(item => item.value === value)) return false;
    this.setData({ saving: true });
    const { key } = rulePicker;
    const result = service.execute(() => {
      store.assertCoachWrite('settings');
      const reminders = store.get('reminderRules') || {};
      const cancellations = store.get('cancelRules') || {};
      if (key === 'threshold') {
        reminders.firstWarning = value;
        store.set('reminderRules', reminders);
      } else {
        cancellations[key] = { ...cancellations[key], deduct: value === 1 };
        store.set('cancelRules', cancellations);
      }
      return view(reminders, cancellations);
    });
    const title = key === 'threshold' ? '课时预警阈值' : '取消规则';
    this.setData({
      saving: false, rulePicker: null,
      ...(result.ok ? result.data : {}),
      feedback: result.ok ? {
        ok: true, title: title + '已保存',
        message: key === 'threshold' ? '' : '下次处理该类课程时使用。'
      } : { ok: false, title: title + '未保存', message: result.error.message }
    });
    return result.ok;
  }
};

Page(require('../../utils/back-navigation')('pages/system-settings/index',
  require('../../utils/feature-page')('settings', config)));
