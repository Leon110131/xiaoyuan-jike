const store = require('../../utils/store');
const validate = require('../../utils/validation');
const service = require('../../utils/local-service');
const feedback = require('../../utils/page-feedback');
const memberChoice = require('../../utils/member-choice');

const fields = [
  { key: 'kcal', label: '每日热量', unit: 'kcal' },
  { key: 'carbs', label: '碳水', unit: 'g' },
  { key: 'protein', label: '蛋白质', unit: 'g' },
  { key: 'fat', label: '脂肪', unit: 'g' }
];
const calculators = [
  { key: 'tdee', label: 'TDEE 营养规划' },
  { key: 'cycle', label: '碳水循环' },
  { key: 'taper', label: '碳水渐降' }
];
const defaults = { kcal: 2000, carbs: 220, protein: 130, fat: 60, notes: '' };
const memberRows = () => memberChoice.describe(store.visibleMembers().filter(memberChoice.eligible));
const cleanEdit = { editingNutrition: false, form: {}, dirty: false, fieldErrors: {}, saveError: '' };
const closeSheets = { nutritionMemberOpen: false, nutritionDiscardOpen: false, pendingMember: null };

function thousands(value) {
  const parts = String(value).split('.');
  parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  return parts.join('.');
}

function goalForm(goal) {
  const form = { notes: goal.notes || '' };
  fields.forEach(({ key }) => { form[key] = goal[key] == null ? '' : String(goal[key]); });
  return form;
}

const config = {
  data: {
    memberId: '', member: null, readOnly: false, avatar: '', members: [], goal: null, defaultGoal: false,
    energyText: '', fields, macroFields: fields.slice(1), calculators, contentScrollTop: 0,
    saving: false, ...cleanEdit, ...closeSheets
  },
  onLoad(query = {}) {
    this.memberId = query.memberId || (memberRows()[0] || {}).id || '';
  },
  onShow() { this.refresh(); },
  refresh(extra = {}) {
    const members = memberRows();
    const current = store.byId('members', this.memberId);
    const readOnly = !!current && !memberChoice.eligible(current);
    const member = members.find(row => row.id === this.memberId) || current;
    const saved = member && store.list('nutritionGoals').find(row => row.memberId === member.id);
    const goal = member ? (saved || { memberId: member.id, ...defaults }) : null;
    this.setData({
      memberId: this.memberId, member, members, goal, readOnly, defaultGoal: !!member && !saved,
      avatar: member ? Array.from(member.name)[0] : '',
      energyText: goal && goal.kcal != null ? thousands(goal.kcal) : '—',
      ...extra,
      ...(!member ? closeSheets : readOnly ? { ...cleanEdit, ...closeSheets, nutritionMemberOpen: !!extra.nutritionMemberOpen } : {})
    });
  },
  resetScroll() { return this.data.contentScrollTop === 0 ? 1 : 0; },
  openEdit() {
    if (this.data.editingNutrition || this.data.featureLocked) return;
    this.refresh();
    if (!this.data.member || !this.data.goal || this.data.readOnly) return;
    this._initialForm = goalForm(this.data.goal);
    this.setData({ ...cleanEdit, editingNutrition: true, form: this._initialForm, contentScrollTop: this.resetScroll() });
  },
  editField(key, value) {
    if (!this.data.editingNutrition || this.data.saving) return;
    const form = { ...this.data.form, [key]: value };
    const dirty = Object.keys(form).some(field => form[field] !== this._initialForm[field]);
    this.setData({ form, dirty, fieldErrors: { ...this.data.fieldErrors, [key]: '' }, saveError: '' });
  },
  onGoalInput(event) {
    const key = event.currentTarget.dataset.key;
    if (fields.some(field => field.key === key)) this.editField(key, event.detail.value);
  },
  onGoalNotes(event) { this.editField('notes', event.detail.value); },
  openMembers() {
    if (this.data.saving || !this.data.member) return;
    this.finishKeyboardEditing();
    this.refresh({ nutritionMemberOpen: true });
  },
  closeMembers() { this.setData({ nutritionMemberOpen: false }); },
  pickMember(event) {
    const id = event.currentTarget.dataset.id;
    if (!this.data.nutritionMemberOpen || !this.data.members.some(row => row.id === id)) return;
    if (id === this.memberId) {
      this.closeMembers();
      return;
    }
    if (this.data.editingNutrition && this.data.dirty) {
      this.setData({ nutritionMemberOpen: false, nutritionDiscardOpen: true, pendingMember: id });
      return;
    }
    this.selectMember(id);
  },
  selectMember(id) {
    if (!memberChoice.eligible(store.byId('members', id))) {
      this.refresh(closeSheets);
      feedback.showToast({ title: '会员已失效，请重新选择', icon: 'none' });
      return;
    }
    this.memberId = id;
    this.showGoal();
  },
  continueEditing() { this.setData(closeSheets); },
  discardEdit() {
    if (!this.data.nutritionDiscardOpen) return;
    if (this.data.pendingMember) this.selectMember(this.data.pendingMember);
    else this.showGoal();
  },
  requestExitEdit() {
    if (this.data.saving) return;
    this.finishKeyboardEditing();
    if (this.data.dirty) this.setData({ nutritionDiscardOpen: true, pendingMember: null });
    else this.showGoal();
  },
  showGoal() {
    this.refresh({ ...cleanEdit, ...closeSheets, contentScrollTop: this.resetScroll() });
  },
  backNutrition() {
    if (this.data.saving) return;
    if (this.data.nutritionDiscardOpen) this.continueEditing();
    else if (this.data.nutritionMemberOpen) this.closeMembers();
    else if (this.data.member && this.data.editingNutrition) this.requestExitEdit();
    else this.returnToSource();
  },
  returnToSource() { this.requestPageLeave({ waitForLayer: true }); },
  saveGoal() {
    const { memberId, member, form, editingNutrition, saving, featureLocked } = this.data;
    if (!member || this.data.readOnly || !editingNutrition || saving || featureLocked) return false;
    this.finishKeyboardEditing();
    if (memberId !== this.memberId || !memberChoice.eligible(store.byId('members', memberId))) {
      this.refresh();
      return false;
    }
    const fieldErrors = {};
    const values = {};
    fields.forEach(({ key, label }) => {
      try {
        const raw = typeof form[key] === 'string' ? form[key].trim() : form[key];
        values[key] = validate.number(raw, 0, label);
      } catch (error) { fieldErrors[key] = error.message; }
    });
    this.setData({ fieldErrors, saveError: '' });
    if (Object.keys(fieldErrors).length) return false;

    this.setData({ saving: true });
    const outcome = service.execute(() => {
      store.assertCoachWrite('nutrition');
      if (memberId !== this.memberId || !memberChoice.eligible(store.byId('members', memberId))) return false;
      const current = store.list('nutritionGoals').find(row => row.memberId === memberId);
      return store.saveNutritionGoal({ ...current, ...values, memberId, notes: form.notes });
    });
    this.setData({ saving: false });
    if (!outcome.ok) {
      this.setData({ saveError: outcome.error.message });
      return false;
    }
    if (!outcome.data) {
      this.refresh();
      return false;
    }
    this.showGoal();
    feedback.showToast({ title: '营养目标已保存', icon: 'success' });
    return true;
  },
  openCalculator(event) {
    const kind = event.currentTarget.dataset.kind;
    if (!this.data.member || this.data.editingNutrition || !calculators.some(item => item.key === kind)) return;
    this.refresh();
    if (!this.data.member || this.data.readOnly) return;
    const query = 'memberId=' + encodeURIComponent(this.memberId);
    const url = kind === 'tdee' ? '/pages/tdee-plan/index?' + query :
      '/pages/nutrition-calculator/index?kind=' + kind + '&' + query;
    feedback.navigateTo({ url });
  }
};

Page(require('../../utils/theme-page')(require('../../utils/back-navigation')('pages/nutrition/index',
  require('../../utils/feature-page')('nutrition', config))));
