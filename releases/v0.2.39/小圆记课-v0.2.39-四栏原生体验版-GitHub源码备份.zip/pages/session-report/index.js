var defineThemePage=function(config){Page(require('../../utils/theme-page')(config));};
var s=require('../../utils/store'),report=require('../../utils/session-report'),exportFile=require('../../utils/report-export');
function renderRecords(records){
 return records.map(function(row){
  var actions=[];
  (row.muscleGroups||[]).forEach(function(group){
   group.exercises.forEach(function(action){actions.push(Object.assign({},action,{order:String(actions.length+1).padStart(2,'0')}));});
  });
  var plan=row.templateSnapshot;
  return {id:row.id,source:row.source,subjective:row.subjective,title:plan?(plan.name+(plan.dayName?' · '+plan.dayName:'')):'',actions:actions};
 });
}
function readCurrent(page){return page.workoutId?report.loadWorkout(s,page.workoutId):report.load(s,page.courseId);}
defineThemePage(require('../../utils/back-navigation')('pages/session-report/index',require('../../utils/feature-page')('reports',require('../../utils/page-guard')({data:{reportMode:true,report:null,error:'',exporting:false,canRecord:false,exportHint:''},onLoad:function(q){this.courseId=q.courseId||'';this.workoutId=q.workoutId||'';this.setData({reportMode:!this.workoutId||q.mode==='report'});},onShow:function(){try{var data=readCurrent(this);var rows=renderRecords(data.allRecords);
var initial=data.member.name.slice(0,1);
var volume=String(data.volume).replace(/\B(?=(\d{3})+(?!\d))/g,',');
this.setData({report:data,displayRecords:rows,memberInitial:initial,volumeLabel:volume,error:'',canRecord:!this.workoutId&&s.coachWriteAllowed()});}catch(error){this.setData({report:null,error:error.message});}},
 openReport:function(){if(this.workoutId)wx.navigateTo({url:'/pages/session-report/index?workoutId='+encodeURIComponent(this.workoutId)+'&mode=report'});},
 openRelatedCourse:function(){var data=this.data.report;if(data&&data.linkedCourse)wx.navigateTo({url:'/pages/course-detail/index?id='+encodeURIComponent(data.course.id)});},
 exportReport:function(){if(this.data.exporting||!this.data.report)return;var self=this,data=readCurrent(this);this.setData({exporting:true,exportHint:''});return require('../../utils/report-image-export')(this,data,s.get('coachProfile')).then(function(result){self.setData({exportHint:'已生成 '+result.count+' 张训练报告图片，可长按保存或分享。'});}).catch(function(error){wx.showModal({title:'图片导出未完成',content:error.message,showCancel:false});}).finally(function(){self.setData({exporting:false});});},copyReport:function(){if(!this.data.report)return;wx.setClipboardData({data:report.text(readCurrent(this),s.get('coachProfile')),success:function(){wx.showToast({title:'报告已复制',icon:'success'});},fail:function(){wx.showModal({title:'复制失败',content:'请重试文件导出。',showCancel:false});}});},editWorkout:function(e){var id=e.currentTarget.dataset.id;if(!this.data.report||!this.data.report.allRecords.some(function(w){return w.id===id;}))return;require('../../utils/workout-actions').edit(id);},deleteWorkout:function(e){var id=e.currentTarget.dataset.id;if(!this.data.report||!this.data.report.allRecords.some(function(w){return w.id===id;}))return;var self=this;require('../../utils/workout-actions').remove(id,function(){if(self.workoutId){self.setData({report:null,error:'这条训练记录已删除。'});if(!self.data.reportMode)self.requestPageLeave();}else self.onShow();});},recordWorkout:function(){if(!s.coachWriteAllowed()){wx.showToast({title:s.coachAccess().reason,icon:'none'});return;}wx.navigateTo({url:'/pages/workout/index?courseId='+encodeURIComponent(this.courseId)});}
}))));
