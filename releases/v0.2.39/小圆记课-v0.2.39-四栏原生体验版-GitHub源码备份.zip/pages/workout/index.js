function submissionSnapshot(data) {
  return JSON.stringify({memberId:data.memberId, courseId:data.courseId, date:data.date, time:data.time,
    duration:data.duration, exercises:data.exercises, notes:data.notes, subjective:data.subjective, workoutId:data.workoutId});
}
var defineThemePage=function(config){Page(require('../../utils/theme-page')(require('../../utils/experience-layout')('workout',config))); };
var RestClock=require('../../utils/rest-clock'),cue=require('../../utils/rest-cue');
var feedback=require('../../utils/page-feedback');
var setTimeout=require('../../utils/local-state').setTimeoutAfterCommit;
var s=require('../../utils/store');
var drafts=require('../../utils/workout-drafts');
var plans=require('../../utils/plan-templates');
var records=require('../../utils/workout-records');
function checkSupplementCourse(page,course){
  var source=page._supplementCourse;
  if(!course||course.archived||course.id!==source.id||course.status!=='completed'||course.deducted!==true||
    course.memberId!==source.memberId||course.packageId!==source.packageId||
    course.date!==source.date||course.time!==source.time||course.duration!==source.duration||
    page.data.memberId!==source.memberId||!s.byId('members',source.memberId)||
    records.linkedToCourse(course).length||s.byId('workouts',page.data.workoutId)){
    throw Error('课程、会员或训练记录已变化，请返回课程详情核对。');
  }
}
function makeExercises(names, library){var arr=[];(names||[]).forEach(function(name,idx){var ex=null;for(var i=0;i<library.length;i++)if(library[i].name===name){ex=library[i];break;}if(!ex)ex={id:'',name:name,group:'未分类',rest:120};var sets=[require('../../utils/recording-set').blank(ex.rest)];arr.push({id:s.uid('we'),exerciseId:ex.id,name:ex.name,group:ex.group,defaultReps:ex.defaultReps,defaultIntensity:ex.intensity,sets:sets,imagePath:ex.imagePath,expanded:true,defaultRest:Number(ex.rest)||0});});return arr;}
defineThemePage(require('../../utils/workout-view')(require('../../utils/back-navigation')('pages/workout/index',require('../../utils/feature-page')('training',require('../../utils/page-guard')(require('../../utils/workout-draft-page')({_localExerciseRemoval:true,data:{time:'09:00',launchedFromPlan:false,launchPlanId:'',templateSnapshot:null,planChoiceLabel:'不使用计划',planChooserOpen:false,planChooserStage:'plans',planChoices:[],planDayChoices:[],stagedPlanId:'',restPopupOpen:false,restViewportFloor:0,reorderOpen:false,reorderDraft:[],dragIndex:-1,dragY:0,sortScrollTop:0,timerRunning:false,timerPaused:false,timerLabel:'00:00',timerTitle:'',timerSetId:'',timerExerciseId:'',restNotice:'',editingExisting:false,editError:'',showQuickExercise:false,quickForm:{},quickGroups:require('../../utils/exercise-groups').muscleOrder,quickCategories:require('../../utils/exercise-types').types,quickGroupIndex:0,quickCategoryIndex:0,courseId:'',courseTitle:'',members:[],memberNames:[],memberIndex:0,plans:[],planNames:[],planIndex:0,memberId:'',planId:'',date:s.formatDate(new Date()),duration:60,subjective:'状态良好',notes:'',exercises:[],saved:false,savingLabel:'保存训练记录',modalExercises:false,modalAddedCount:0,exerciseLibrary:[],exerciseGroups:[],muscleOptions:[],selectedMuscle:'全部',equipmentFilter:'全部',equipmentCategories:['全部'].concat(require('../../utils/exercise-types').types),exerciseSearch:'',statusOptions:['状态良好','疲劳正常','疲劳偏高','状态一般','状态欠佳']},onLoad:function(q){if(!this.prepareTrainingEntry(q))return;if(q.workoutId){this.loadExistingWorkout(q.workoutId);return;}var course=q.courseId?s.byId('courses',q.courseId):null,ms=s.visibleMembers().filter(function(m){return m.status!=='已结课';}),memberId=course?course.memberId:(q.memberId||(ms[0]&&ms[0].id)||''),plan=q.planId&&q.planDraft!=='1'?plans.read(q.planId):null,day=plan?(q.planDay!==undefined?plan.days[Number(q.planDay)]:plan.days.length===1?plan.days[0]:null):null,now=new Date();if(q.courseId&&(!course||course.archived)&&!require('../../utils/workout-drafts').choose(q,q.memberId)){this.setData({editError:'课程已不存在，请返回核对。'});return;}if(q.planDraft!=='1'&&q.planDay!==undefined&&(!q.memberId||!ms.some(function(m){return m.id===q.memberId;})||!day)){this.setData({editError:'会员或训练日已变化，请返回计划重新选择。'});return;}this.setData({date:course?course.date:s.formatDate(now),time:course?course.time:('0'+now.getHours()).slice(-2)+':'+('0'+now.getMinutes()).slice(-2),duration:course?course.duration:60,courseId:course?course.id:'',courseTitle:course?course.date+' '+course.time+' · '+(course.title||'私教课程'):'',members:ms,memberNames:ms.map(function(m){return m.name;}),memberId:memberId,memberIndex:Math.max(0,ms.map(function(m){return m.id;}).indexOf(memberId)),plans:require('../../utils/plan-templates').available(),planNames:['不使用计划'].concat(require('../../utils/plan-templates').available().map(function(p){return p.name;})),planId:'',launchedFromPlan:!!plan,launchPlanId:plan?plan.id:'',planChoiceLabel:plan?plan.name+(day?' · '+day.name:' · 请选择训练日'):'不使用计划',templateSnapshot:day?require('../../utils/plan-templates').snapshot(plan,day):null,exercises:makeExercises(day?day.exerciseNames:[],s.list('exercises')),exerciseLibrary:s.list('exercises'),workoutId:s.uid('w')});},onMemberChange:function(e){if(this.data.editingExisting)return;var ix=Number(e.detail.value),m=this.data.members[ix];if(!m)return;this._workoutSnapshot=null;this.stopRest();this.setData({memberIndex:ix,memberId:m.id,workoutId:s.uid('w'),courseId:'',courseTitle:'',planId:'',exercises:makeExercises(this.data.templateSnapshot?this.data.templateSnapshot.exerciseNames:[],s.list('exercises')),saved:false});},onPlanChange:function(e){var i=Number(e.detail.value);this.openPlanChooser();if(i===0)this.useNoPlan();else if(this.data.planChoices[i-1])this.chooseTemplate({currentTarget:{dataset:{id:this.data.planChoices[i-1].id}}});},openPlanChooser:function(){this.finishKeyboardEditing();var choices=require('../../utils/plan-templates').available();this.setData({planChooserOpen:true,planChooserStage:'plans',planChoices:choices,stagedPlanId:'',planDayChoices:[]});},openLaunchDays:function(){var p=require('../../utils/plan-templates').read(this.data.launchPlanId);this.setData({planChooserOpen:true,planChooserStage:'days',stagedPlanId:p.id,planDayChoices:p.days.map(function(d,i){return {index:i,name:d.name,count:d.exerciseNames.length};})});},closePlanChooser:function(){this.setData({planChooserOpen:false,stagedPlanId:'',planDayChoices:[]});},useNoPlan:function(){this.setData({planId:'',templateSnapshot:null,planChoiceLabel:'不使用计划',planChooserOpen:false,saved:false});},chooseTemplate:function(e){var p=require('../../utils/plan-templates').read(e.currentTarget.dataset.id);if(p.days.length===1){this.confirmTemplateDay(p.id,0);return;}this.setData({planChooserStage:'days',stagedPlanId:p.id,planDayChoices:p.days.map(function(d,i){return {index:i,name:d.name,count:d.exerciseNames.length};})});},chooseTemplateDay:function(e){this.confirmTemplateDay(this.data.stagedPlanId,Number(e.currentTarget.dataset.index));},backToPlans:function(){this.setData({planChooserStage:'plans',stagedPlanId:'',planDayChoices:[]});},confirmTemplateDay:function(id,index){var r=require('../../utils/plan-templates'),p=r.read(id),day=p.days[index];if(!day)throw Error('训练日不存在。');var expected=JSON.stringify(p),self=this;this.closePlanChooser();feedback.showModal({title:'是否同步到今日训练',content:'将「'+p.name+' · '+day.name+'」同步到 '+this.data.date+' '+this.data.time+'。确认后替换当前动作与组数据，已保存的历史记录不会被修改。',confirmText:'是',cancelText:'否',success:function(result){if(!result.confirm)return;var current=r.read(id);if(JSON.stringify(current)!==expected)throw Error('计划已经更新，请重新选择。');var patch=self.templateDayPatch(current,index);self.stopRest();self.setData(patch);}});},onTime:function(e){this.setData({time:e.detail.value,saved:false});},onDuration:function(e){this.setData({duration:Number(e.detail.value)||60,saved:false});},onNotes:function(e){this.setData({notes:e.detail.value,saved:false});},onSubjective:function(e){this.setData({subjective:this.data.statusOptions[e.detail.value],saved:false});},updateSet:function(e){var ei=Number(e.currentTarget.dataset.ei),si=Number(e.currentTarget.dataset.si),key=e.currentTarget.dataset.key,arr=this.data.exercises;if(!arr[ei]||!arr[ei].sets[si]||['weight','reps','rest'].indexOf(key)<0)return;var old=String(arr[ei].sets[si][key]===undefined?'':arr[ei].sets[si][key]),val=String(e.detail.value).replace(/[。．,，]/g,'.');if(!(key==='weight'?/^\d*(?:\.\d*)?$/:/^\d*$/).test(val))return old;if(key==='rest'&&Number(val)>3600)return old;if(key==='rest'&&this._restClock&&this._restClock.active&&this.data.timerSetId===arr[ei].sets[si].id){this.adjustRestBy(Number(val)-Number(this.data.timerTarget||0));return val;}if(key==='rest'&&this._restClock&&this.data.timerSetId===arr[ei].sets[si].id)this.applyRestState(this._restClock.adjust(Number(val)-Number(old)));arr[ei].sets[si][key]=val;if(key==='rest'){arr[ei].sets[si].restCustomized=true;arr[ei].sets[si].restPlanned=Number(val);if(!this._restClock||!this._restClock.active||this.data.timerSetId!==arr[ei].sets[si].id){delete arr[ei].sets[si].restActual;delete arr[ei].sets[si].restCompleted;delete arr[ei].sets[si].restFinishReason;}}this.data.saved=false;return val;},insertDecimal:function(e){var ei=Number(e.currentTarget.dataset.ei),si=Number(e.currentTarget.dataset.si),a=this.data.exercises;if(!a[ei]||!a[ei].sets[si])return;var v=String(a[ei].sets[si].weight);if(v.indexOf('.')>=0)return;a[ei].sets[si].weight=(v||'0')+'.';this.setData({exercises:a,saved:false});},finishSetInput:function(){this.setData({exercises:this.data.exercises,saved:false});},toggleDone:function(e){var ei=Number(e.currentTarget.dataset.ei),si=Number(e.currentTarget.dataset.si),arr=this.data.exercises,ex=arr[ei],st=ex&&ex.sets[si];if(!st)return;var done=!!e.detail.value,wasDone=!!st.done;st.done=done;this.setData({exercises:arr,saved:false});if(done&&!wasDone){if(Number(st.restPlanned===undefined?st.rest:st.restPlanned)>0){this.openRestPopup(e);}else this.stopRest();}else if(!done&&this.data.timerSetId===st.id)this.stopRest();},cycleSetType:function(e){var ei=Number(e.currentTarget.dataset.ei),si=Number(e.currentTarget.dataset.si),ex=this.data.exercises[ei],st=ex&&ex.sets[si];if(!st)return;var id=st.id,self=this,choices=[['热身组','轻负荷，逐步进入训练'],['正式组','按本次目标完成训练'],['递减组','降低重量后继续完成'],['超级组','与另一动作连续进行']];feedback.showActionSheet({itemList:choices.map(function(x){return x[0]+'｜'+x[1];}),success:function(result){var c=choices[result.tapIndex];if(!c)return;var rows=self.data.exercises,found;rows.forEach(function(x){x.sets.forEach(function(s){if(s.id===id)found=s;});});if(!found)return;found.setType=c[0];self.setData({exercises:rows,saved:false});}});},collapseExercise:function(e){var ex=this.data.exercises[Number(e.currentTarget.dataset.ei)];if(ex){ex.expanded=false;this.setData({exercises:this.data.exercises});}},addSet:function(e){var ix=Number(e.currentTarget.dataset.ei),arr=this.data.exercises;if(!arr[ix])return;arr[ix].sets.push(require('../../utils/recording-set').blank(arr[ix].defaultRest));this.setData({exercises:arr,saved:false});},copyPreviousSet:function(e){var ix=Number(e.currentTarget.dataset.ei),arr=this.data.exercises;if(!arr[ix]||!arr[ix].sets.length)return;arr[ix].sets.push(require('../../utils/recording-set').copy(arr[ix].sets[arr[ix].sets.length-1]));this.setData({exercises:arr,saved:false});},removeSet:function(e){this.stopRest();var ei=Number(e.currentTarget.dataset.ei),si=Number(e.currentTarget.dataset.si),arr=this.data.exercises;if(arr[ei].sets.length<=1){feedback.showToast({title:'每个动作至少保留一组',icon:'none'});return;}arr[ei].sets.splice(si,1);this.setData({exercises:arr,saved:false});},openAddExercise:function(){this.finishKeyboardEditing();this.setData({modalExercises:true,modalAddedCount:this.data.exercises.length,exerciseSearch:'',selectedMuscle:'全部',equipmentFilter:'全部',muscleOptions:require('../../utils/exercise-groups').optionsFor(this.data.exerciseLibrary)});this.filterExercises();},filterExercises:function(){var groups=require('../../utils/exercise-groups'),kind=this.data.equipmentFilter,library=this.data.exerciseLibrary.filter(function(x){return kind==='全部'||require('../../utils/exercise-types').category(x)===kind;});this.setData({exerciseGroups:require('../../utils/exercise-selection').mark(groups.libraryGroups(library,this.data.selectedMuscle,this.data.exerciseSearch),this.data.exercises),modalAddedCount:this.data.exercises.length});},chooseEquipment:function(e){this.setData({equipmentFilter:e.currentTarget.dataset.value});this.filterExercises();},chooseMuscle:function(e){this.setData({selectedMuscle:e.currentTarget.dataset.group});this.filterExercises();},searchExercises:function(e){this.setData({exerciseSearch:e.detail.value});this.filterExercises();},closeAddExercise:function(){this.setData({modalExercises:false});},
requestLibrarySelection:function(e){
  var id=e.currentTarget.dataset.id,entry=this.data.exerciseLibrary.find(function(x){return x.id===id;});
  if(!entry)return;
  var selection=require('../../utils/exercise-selection');
  var affected=this.data.exercises.filter(function(x){return selection.matches(x,entry);});
  var self=this;
  this.confirmExerciseRemoval(affected,function(){self.chooseExercise(e);});
},
requestExerciseRemoval:function(e){
  var action=this.data.exercises[Number(e.currentTarget.dataset.ei)],self=this;
  if(action)this.confirmExerciseRemoval([action],function(){
    var index=self.data.exercises.findIndex(function(x){return x.id===action.id;});
    if(index>=0){self.closeWorkoutGroup();self.removeExercise({currentTarget:{dataset:{ei:index}}});}
  });
},
confirmExerciseRemoval:function(actions,apply){
  var sets=actions.reduce(function(count,x){return count+x.sets.length;},0);
  var recorded=actions.some(function(x){return x.sets.some(function(st){return st.done||String(st.weight||'')!==''||String(st.reps||'')!==''||st.weight===0||st.reps===0;});});
  if(!recorded){apply();return;}
  feedback.showModal({title:'移除训练动作',content:'将移除「'+actions[0].name+'」'+actions.length+' 个动作实例及其 '+sets+' 组当前记录。',confirmText:'确认移除',success:function(result){if(result.confirm)apply();}});
},
chooseExercise:function(e){var id=e.currentTarget.dataset.id,name=e.currentTarget.dataset.name,lib=this.data.exerciseLibrary,ex=lib.filter(function(x){return id?x.id===id:x.name===name;})[0];if(!ex)return;var selection=require('../../utils/exercise-selection'),arr=this.data.exercises,selected=arr.some(function(x){return selection.matches(x,ex);});if(selected){this.stopRest();arr=arr.filter(function(x){return !selection.matches(x,ex);});}else{var sets=[require('../../utils/recording-set').blank(ex.rest)];arr=arr.concat([{id:s.uid('we'),exerciseId:ex.id,name:ex.name,group:ex.group,defaultReps:ex.defaultReps,defaultIntensity:ex.intensity,sets:sets,imagePath:ex.imagePath,expanded:true,defaultRest:Number(ex.rest)||0}]);}this.setData({exercises:arr,saved:false});this.filterExercises();wx.showToast({title:selected?'已取消选择':'已选中此动作',icon:'none',duration:900});},removeExercise:function(e){this.stopRest();var ix=Number(e.currentTarget.dataset.ei),arr=this.data.exercises;if(!Number.isInteger(ix)||ix<0||ix>=arr.length)return;arr.splice(ix,1);this.setData({exercises:arr,saved:false});},saveDraft:function(){this.captureRestProgress(false);var ok=this.persistWorkoutDraft(true);if(ok)wx.showToast({title:'草稿已保存，尚未提交记录',icon:'none'});return ok;},save:function(){this.captureRestProgress(false);if(this.data.editError)return false;var previous=null;if(this._workoutSnapshot){previous=require('../../utils/workout-records').check(this.data.workoutId,this._workoutSnapshot);}if(!s.coachWriteAllowed()){feedback.showToast({title:'当前体验账号不可用，请重新打开',icon:'none',duration:2300});return false;}if(!this.data.memberId){feedback.showToast({title:'请选择会员',icon:'none'});return;}var sets=[];this.data.exercises.forEach(function(ex,exerciseOrder){ex.sets.forEach(function(st){sets.push(Object.assign({},st,{exerciseOrder:exerciseOrder,exerciseInstanceId:ex.id,id:st.id,exerciseName:ex.name,exerciseId:ex.exerciseId,exerciseGroup:ex.group,exerciseImage:ex.imagePath||'',setType:st.setType,weightBlank:st.weight==='',repsBlank:st.reps==='',rpe:st.rpe==null?0:Number(st.rpe),rir:st.rir==null?0:Number(st.rir),weight:st.weight===''?0:Number(st.weight),reps:st.reps===''?0:Number(st.reps),rest:st.rest===''?0:Number(st.rest),done:!!st.done}));});});var log=Object.assign({},previous||{},{id:this.data.workoutId,memberId:this.data.memberId,planId:this.data.planId||'',courseId:this.data.courseId||'',date:this.data.date,time:this.data.time,templateSnapshot:this.data.templateSnapshot||null,duration:Number(this.data.duration)||60,subjective:this.data.subjective,notes:this.data.notes,sets:sets});if(!s.byId('members',log.memberId))throw Error('会员已不存在，请返回重新选择。');
if(previous&&previous.memberId!==log.memberId)throw Error('训练所属会员已变化，请重新打开记录。');
if(previous&&previous.courseId&&previous.courseId!==log.courseId)throw Error('关联课程已变化，请重新打开训练记录。');
if(this._recordOnlySubmission&&!log.courseId&&!previous)log.standalone=true;
if(this._supplementCourse)checkSupplementCourse(this,s.byId('courses',log.courseId));
if(this._syncCalendarOnSave){var linked=log.courseId?s.byId('courses',log.courseId):null;if(log.courseId&&(!linked||linked.archived))throw Error('关联课程已不存在，请返回重新核对。');
if(previous&&linked&&linked.workoutId&&linked.workoutId!==log.id&&s.byId('workouts',linked.workoutId))throw Error('课程已关联另一条训练记录，请返回核对。');
if(this._completionExpectedCourse&&JSON.stringify(linked)!==this._completionExpectedCourse)throw Error('课程资料已变化，请重新确认。');if(!this._supplementCourse||linked.date!==log.date||linked.time!==log.time||Number(linked.duration)!==log.duration){log.courseId=require('../../utils/workout-schedule').sync(log);}if(this._completeAndDebit){var c=s.byId('courses',log.courseId);if(!c.deducted){var completed=s.completeCourse(c.id);if(!completed.ok)throw require('../../utils/operation-errors').create('VALIDATION',completed.msg+' 请先补充可用课时，再完成训练；草稿仍保留。');}s.patch('courses',c.id,{status:'completed',autoTimeStatus:false,workoutId:log.id});}}s.saveWorkout(log);if(this._syncCalendarOnSave||this._recordOnlySubmission)require('../../utils/workout-drafts').remove(this.data);if(this.data.courseId&&!this.data.editingExisting){s.patch('courses',this.data.courseId,{workoutId:log.id});}var self=this,submitted=!!(this._syncCalendarOnSave||this._recordOnlySubmission);require('../../utils/local-state').afterCommit(function(){if(submitted)self._draftSubmitted=true;self._workoutSnapshot=JSON.stringify(s.byId('workouts',log.id));self.setData({courseId:log.courseId||'',saved:true,savingLabel:'已保存 · 可继续修改后再次保存'});});feedback.showToast({title:'训练记录已保存',icon:'success'});return true;},focusWorkoutField:function(e){
 this.keepInputKeyboard();
 var ds=e.currentTarget.dataset;
 this.setData({focusedSetId:ds.id,focusedField:ds.key});
},
blurWorkoutField:function(e){
 var ds=e.currentTarget.dataset,patch={};
 if(this.data.focusedSetId===ds.id&&this.data.focusedField===ds.key)patch.focusedField='';
 if(this.data.requestedSetId===ds.id&&this.data.requestedField===ds.key){patch.requestedSetId='';patch.requestedField='';}
 this.setData(patch);this.finishSetInput();
},
nextWorkoutInput:function(e){
 this.setData({requestedSetId:e.currentTarget.dataset.id,requestedField:'reps'});
},
toggleWorkoutCheck:function(e){
 var ds=e.currentTarget.dataset,action=this.data.exercises[Number(ds.ei)],row=action&&action.sets[Number(ds.si)];
 if(!row)return;
 this.finishKeyboardEditing();
 this.setData({focusedSetId:row.id,focusedField:''});
 this.toggleDone({currentTarget:e.currentTarget,detail:{value:!row.done}});
},
pickWorkoutMuscle:function(e){
 var group=this.data.muscleOptions[Number(e.detail.value)];
 if(group)this.chooseMuscle({currentTarget:{dataset:{group:group}}});
},
pickWorkoutEquipment:function(e){
 var value=this.data.equipmentCategories[Number(e.detail.value)];
 if(value)this.chooseEquipment({currentTarget:{dataset:{value:value}}});
},
openWorkoutGroup:function(e){
 this.finishKeyboardEditing();
 var ds=e.currentTarget.dataset,action=this.data.exercises[Number(ds.ei)],row=action&&action.sets[Number(ds.si)];
 if(!row)return;
 this.setData({workoutGroup:{ei:Number(ds.ei),si:Number(ds.si),id:row.id,name:action.name,canRemove:action.sets.length>1},focusedSetId:row.id,focusedField:''});
},
closeWorkoutGroup:function(){this.finishKeyboardEditing();this.setData({workoutGroup:null});},
removeWorkoutGroup:function(e){this.removeSet(e);this.closeWorkoutGroup();},
presentTrainingSubmit:function(){
 this.finishKeyboardEditing();
 this._renderTrainingResult=true;
 this.openTrainingSubmit();
},
openTrainingSubmit:function(){
  if(this.data.saving||this._draftSubmitted||!this.data.memberId||this.data.editError)return;
  if(!this.data.editingExisting&&!this.data.exercises.length){feedback.showToast({title:'请先添加动作',icon:'none'});return;}
  if(this.data.editingExisting){
    if(this.data.courseId){if(this._renderTrainingResult)this.openTrainingConfirmation();else this.saveAndClose();}
    else this.saveRecordOnly();
    return;
  }
  if(this.data.courseId){if(this._renderTrainingResult)this.openTrainingConfirmation();else this.saveAndClose();return;}
  this.setData({trainingSubmitOpen:true});
},
closeTrainingSubmit:function(){if(!this.data.saving)this.setData({trainingSubmitOpen:false});},
prepareTrainingEntry:function(q){
  this._supplementCourse=null;
  this._planDraftChoice=null;
  this.setData({planDraftOpen:false,planDraftInvalid:false,planDraftError:''});
  if(q.supplementCourse==='1'){
    var course=s.byId('courses',q.courseId);
    if(!course||course.archived||course.status!=='completed'||course.deducted!==true||
      course.memberId!==q.memberId||!s.byId('members',q.memberId)||records.linkedToCourse(course).length||
      (q.draftId&&!drafts.resumable(q.memberId,q.courseId).some(function(row){return row.id===q.draftId;}))){
      this.setData({editError:'课程或训练记录已变化，请返回课程详情核对。'});
      return false;
    }
    this._supplementCourse=course;
  }
  if(q.planDraft!=='1')return true;
  var selected=drafts.resumable(q.memberId,'').find(function(row){return row.id===q.draftId;});
  var plan=s.byId('plans',q.planId),index=Number(q.planDay),day=plan&&plan.days&&plan.days[index];
  if(!selected||String(selected.updatedAt)!==q.draftUpdatedAt||!this.planLaunchMemberAvailable(q.memberId)||
    !plan||plan.deleted||plan.status!=='published'||!day){
    this.setData({editError:'计划、会员或草稿已变化，请返回计划重新选择。'});
    return false;
  }
  this._planDraftChoice={draftId:selected.id,memberId:q.memberId,workoutId:selected.workoutId,
    draftSignature:drafts.signature(selected),planId:plan.id,planSnapshot:JSON.stringify(plan),index:index};
  this.setData({planDraftOpen:true,planDraftLabel:plan.name+' · '+day.name});
  return true;
},
planLaunchMemberAvailable:function(id){
  return s.visibleMembers().some(function(member){return member.id===id&&member.status!=='已结课';});
},
currentPlanDraft:function(choice){
  var row=drafts.resumable(choice.memberId,'').find(function(draft){return draft.id===choice.draftId;});
  return row&&this.data.memberId===choice.memberId&&this.data.workoutId===choice.workoutId&&!this.data.courseId&&
    this.planLaunchMemberAvailable(choice.memberId)&&drafts.signature(row)===choice.draftSignature?row:null;
},
closePlanDraftChoice:function(){
  var choice=this._planDraftChoice;
  if(!choice)return;
  if(this.data.planDraftInvalid||!this.currentPlanDraft(choice)){
    this._draftReady=false;
    this.requestPageLeave();
    return;
  }
  this._planDraftChoice=null;
  this.setData({planDraftOpen:false,planDraftError:''});
},
templateDayPatch:function(plan,index){
  var day=plan.days[index];
  return {planId:'',templateSnapshot:plans.snapshot(plan,day),planChoiceLabel:plan.name+' · '+day.name,
    exercises:makeExercises(day.exerciseNames,s.list('exercises')),saved:false};
},
replacePlanDraft:function(){
  var choice=this._planDraftChoice;
  if(!choice||this.data.planDraftInvalid)return;
  var row=this.currentPlanDraft(choice),plan=s.byId('plans',choice.planId);
  if(!row||JSON.stringify(plan)!==choice.planSnapshot){
    this.setData({planDraftInvalid:true,planDraftError:'计划、会员或草稿已变化，请返回重新选择。'});
    return;
  }
  var patch=this.templateDayPatch(plan,choice.index);
  // Commit the replacement before stopping the active timer or updating the screen.
  try{
    if(!drafts.put({data:Object.assign({},this.data,patch)}))throw Error('草稿不可写入');
  }catch(error){
    this.setData({planDraftError:'替换未保存。请重试，或继续原草稿。'});
    return;
  }
  this.stopRest();
  this.setData(Object.assign(patch,{planDraftOpen:false,planDraftError:'',draftSaved:true}));
  this._draftSignature=drafts.signature(drafts.read(this));
  this._planDraftChoice=null;
},
openTrainingConfirmation:function(){
  this._trainingConfirmation=submissionSnapshot(this.data);
  var course=this.data.courseId?s.byId('courses',this.data.courseId):null;
  this._confirmedCourse=course?JSON.stringify(course):'';
  this.setData({trainingSubmitConfirm:true,confirmationBooked:!!this.data.courseId,confirmationAlreadyDebited:!!(course&&course.deducted)});
},
closeTrainingConfirmation:function(){if(!this.data.saving)this.setData({trainingSubmitConfirm:false});},
confirmUnbookedTraining:function(){
  if(!this.data.trainingSubmitConfirm||this.data.saving)return;
  if(this._trainingConfirmation!==submissionSnapshot(this.data)){
    this.closeTrainingConfirmation();
    throw Error('训练内容已变化，请重新确认。');
  }
  this.finishTrainingSubmission(true,this._confirmedCourse||'');
},
saveRecordOnly:function(){this.finishTrainingSubmission(false,'');},
finishTrainingSubmission:function(complete,expected){
  if(this.data.saving||this._draftSubmitted||!s.coachWriteAllowed())return false;
  if(this._supplementCourse)checkSupplementCourse(this,s.byId('courses',this.data.courseId));
  if(!this.data.editingExisting)this.persistWorkoutDraft(true);
  this._syncCalendarOnSave=complete;
  this._completeAndDebit=complete;
  this._completionExpectedCourse=expected;
  this._recordOnlySubmission=!complete;
  var ok;
  try{ok=this.save();}
  finally{
    this._syncCalendarOnSave=false;
    this._completeAndDebit=false;
    this._completionExpectedCourse='';
    this._recordOnlySubmission=false;
  }
  if(ok!==true){if(this._renderTrainingResult)this.setData({trainingSubmitConfirm:false,trainingSubmitOpen:false});return false;}
  var self=this;
  require('../../utils/local-state').afterCommit(function(){
    self.setData({trainingSubmitConfirm:false,trainingSubmitOpen:false});
    if(self._renderTrainingResult){
      var updated=complete&&self.data.confirmationAlreadyDebited;
      self.setData({trainingResult:{title:updated?'训练记录已更新':complete?'课程已完成':'训练记录已保存',detail:updated?'已更新训练记录，课时扣减保持原值。':complete?'训练记录已保存，已扣 1 节。':'已保存到会员档案，课程和课时保持原值。',returnLabel:self.data.confirmationBooked?'返回课程':'返回来源'}});
    }else setTimeout(function(){feedback.navigateBack({delta:1});},300);
  });
  return true;
},
saveAndClose:function(){
  if(this._completionPending||!s.coachWriteAllowed())return;
  this.captureRestProgress(false);
  this.persistWorkoutDraft(true);
  var self=this,c=this.data.courseId?s.byId('courses',this.data.courseId):null;
  var expected=c?JSON.stringify(c):'',signature=submissionSnapshot(this.data);
  this._completionPending=true;
  feedback.showModal({
    title:c&&c.deducted?'确认更新训练？':'是否确认扣课？',
    content:c&&c.deducted?'本课程已扣过1节课，本次仅更新训练记录，不重复扣课。':'确认后完成本节训练，从该会员可用课时包扣除1节，并同步训练记录和近期课程。课时不足时保留草稿，补充课时后再完成。',
    confirmText:c&&c.deducted?'确认保存':'确认扣课',
    fail:function(){self._completionPending=false;},
    success:function(result){
      self._completionPending=false;
      if(!result.confirm)return;
      if(signature!==submissionSnapshot(self.data))throw Error('训练内容已变化，请重新确认。');
      var ok=self.finishTrainingSubmission(true,expected);
      if(ok!==true)throw require('../../utils/operation-errors').create('VALIDATION',self.data.operationError?self.data.operationError.message:'未能完成训练，草稿仍保留。请检查可用课时后重试。');
    }
  });
},toggleExercise:function(e){var ix=Number(e.currentTarget.dataset.ei),arr=this.data.exercises;arr[ix].expanded=!arr[ix].expanded;this.setData({exercises:arr});},
changeRest:function(e){var ei=Number(e.currentTarget.dataset.ei),si=Number(e.currentTarget.dataset.si),arr=this.data.exercises,st=arr[ei].sets[si],next=Math.max(0,Math.min(3600,Number(st.rest||0)+Number(e.currentTarget.dataset.delta)));this.updateSet({currentTarget:{dataset:{ei:ei,si:si,key:'rest'}},detail:{value:String(next)}});},
openRestPopup:function(e){var ei=Number(e.currentTarget.dataset.ei),si=Number(e.currentTarget.dataset.si),ex=this.data.exercises[ei],st=ex&&ex.sets[si];if(!st)return;if(this._restClock&&this._restClock.active&&this.data.timerSetId===st.id){this.tickRest();}else this.startRest(e,true);if(this.data.timerRunning&&this.data.timerSetId===st.id)this.setData({restPopupOpen:true});},closeRestPopup:function(){this.setData({restPopupOpen:false});},finishRestAction:function(exerciseId,setId){var rows=this.data.exercises,ex=rows.filter(function(x){return x.id===exerciseId;})[0];if(!ex||!ex.sets.length||ex.sets[ex.sets.length-1].id!==setId)return;this.holdRestViewport();ex.expanded=false;var self=this;this.setData({exercises:rows},function(){self.centerRestAction(exerciseId);});},centerRestAction:function(exerciseId){if(this._restPageDisposed||typeof wx.createSelectorQuery!=='function'||typeof wx.pageScrollTo!=='function')return;var self=this,query=wx.createSelectorQuery();if(query.in)query=query.in(this);query.select('#rest-action-'+exerciseId).boundingClientRect();query.selectViewport().scrollOffset();query.exec(function(rows){if(self._restPageDisposed||self.data.timerRunning)return;var rect=rows&&rows[0],offset=rows&&rows[1],info=typeof wx.getWindowInfo==='function'?wx.getWindowInfo():null;if(!rect||!offset||!info)return;var target=Math.max(0,Number(offset.scrollTop)+rect.top+rect.height/2-info.windowHeight/2);self.setData({restViewportFloor:Math.max(self.data.restViewportFloor||0,Math.ceil(target+info.windowHeight))},function(){if(!self._restPageDisposed&&!self.data.timerRunning)wx.pageScrollTo({scrollTop:target,duration:220});});});},startRest:function(e,restart){var ei=Number(e.currentTarget.dataset.ei),si=Number(e.currentTarget.dataset.si),ex=this.data.exercises[ei],st=ex&&ex.sets[si];if(!st)return;if(!restart&&this._restClock&&this._restClock.active&&this.data.timerSetId===st.id){this.pauseRest();return;}if(!s.canUseFeature('training',true))return;var target=Number(st.restPlanned===undefined?st.rest:st.restPlanned);if(!Number.isInteger(target)||target<1||target>3600)return;this.captureRestProgress(true,'切换休息');ex=this.data.exercises[ei];st=ex.sets[si];this._restClock=new RestClock(this._restNow||Date.now);this._restTracker=new (require('../../utils/rest-tracking'))(this._restNow||Date.now);this._restTrackedSetId=st.id;st.restPlanned=target;st.rest=target;delete st.restActual;delete st.restCompleted;delete st.restFinishReason;st.restCustomized=true;var initialRestState=this._restClock.start(target);this._restTracker.startedAt=initialRestState.sampledAt;this._restTracker.segment=initialRestState.sampledAt;cue.arm();this.setData({exercises:this.data.exercises,timerExerciseId:ex.id,timerTitle:ex.name+' · 第'+(si+1)+'组',timerSetId:st.id,timerTarget:target,timerElapsed:0,restNotice:'',saved:false});this.startRestInterval();this.tickRest();},holdRestViewport:function(){var info=null;try{info=typeof wx.getWindowInfo==='function'?wx.getWindowInfo():(typeof wx.getSystemInfoSync==='function'?wx.getSystemInfoSync():null);}catch(error){return;}if(!info||!info.windowHeight)return;this._restWindowHeight=info.windowHeight;this.setData({restViewportFloor:Math.ceil(Math.max(0,this._workoutScrollTop||0)+info.windowHeight)});},onPageScroll:function(e){this._workoutScrollTop=Math.max(0,Number(e.scrollTop)||0);if(this.data.restViewportFloor&&this._restWindowHeight){var floor=this._workoutScrollTop?Math.ceil(this._workoutScrollTop+this._restWindowHeight):0;if(floor<this.data.restViewportFloor)this.setData({restViewportFloor:floor});}},captureRestProgress:function(complete,reason,at){if(!this._restTracker||!this._restClock||this._restTracker.finished)return;var found,rows=this.data.exercises,id=this._restTrackedSetId;rows.forEach(function(ex){ex.sets.forEach(function(st){if(st.id===id)found=st;});});if(!found)return;var actual=complete?this._restTracker.finish(this._restClock.deadline,at):this._restTracker.elapsed(this._restClock.deadline,at);found.restActual=actual;found.rest=actual;found.restCompleted=!!complete;if(complete)found.restFinishReason=reason||'计时结束';this.setData({exercises:rows,timerElapsed:actual,saved:false});},adjustActiveRest:function(e){var delta=Number(e.currentTarget.dataset.delta);if(delta!==10&&delta!==-10)return;this.adjustRestBy(delta);},adjustRestBy:function(delta){if(!this._restClock||!this._restClock.active)return;var now=this._restClock.now(),state=this._restClock.tick(now),remaining=state.remaining,next=Math.max(0,Math.min(3600,remaining+delta));if(!state.running){this.applyRestState(state);return;}var effective=next-remaining;if(!this._restClock.paused&&next===0)effective=-Math.max(0,(this._restClock.deadline-now)/1000);var rows=this.data.exercises,id=this.data.timerSetId;rows.forEach(function(ex){ex.sets.forEach(function(st){if(st.id===id){st.restPlanned=Math.max(0,Number(st.restPlanned||0)+next-remaining);}});});this.setData({exercises:rows,timerTarget:Math.max(0,Number(this.data.timerTarget||0)+next-remaining),saved:false});this.applyRestState(this._restClock.adjust(effective,now));},startRestInterval:function(){if(this._restInterval)clearInterval(this._restInterval);var self=this;this._restInterval=setInterval(function(){self.tickRest();},250);},
tickRest:function(){if(this._restClock)this.applyRestState(this._restClock.tick());},applyRestState:function(state){var exerciseId=this.data.timerExerciseId,setId=this.data.timerSetId;if(state.ended)this.captureRestProgress(true,'自然结束',state.sampledAt);var patch={timerRunning:state.running,timerPaused:state.paused,timerLabel:state.label};if(this._restTracker)patch.timerElapsed=this._restTracker.elapsed(this._restClock.deadline,state.sampledAt);if(!state.running)patch.restPopupOpen=false;this.setData(patch);if(state.ended){if(this._restInterval)clearInterval(this._restInterval);this._restInterval=null;cue.ring();this.setData({restNotice:'组间休息结束，可以开始下一组'});this.finishRestAction(exerciseId,setId);feedback.showToast({title:'组间休息结束',icon:'none'});}},
pauseRest:function(){if(!this._restClock)return;var at=this._restClock.now();if(this._restClock.paused){if(this._restTracker)this._restTracker.resume(at);this.applyRestState(this._restClock.resume(at));}else{if(this._restTracker)this._restTracker.pause(this._restClock.deadline,at);this.applyRestState(this._restClock.pause(at));}},finishRest:function(){if(!this.data.timerRunning)return;var exerciseId=this.data.timerExerciseId,setId=this.data.timerSetId;this.stopRest();this.finishRestAction(exerciseId,setId);this.setData({restNotice:'本组休息已提前完成，可以开始下一组'});feedback.showToast({title:'休息已完成',icon:'success'});},ignoreExerciseTap:function(){},stopRest:function(){this.captureRestProgress(true,'提前结束');if(this._restInterval)clearInterval(this._restInterval);this._restInterval=null;if(this._restClock)this._restClock.stop();this.setData({restPopupOpen:false,timerRunning:false,timerPaused:false,timerLabel:'00:00',timerSetId:'',timerExerciseId:'',restNotice:''});},
syncLibraryRest:function(){var library=s.list('exercises'),arr=this.data.exercises,changed=false,self=this;arr.forEach(function(ex){var current=library.filter(function(x){return x.id===ex.exerciseId;})[0];if(!current)return;var next=Number(current.rest)||0;if(ex.defaultRest!==next){ex.defaultRest=next;ex.sets.forEach(function(st){if(!st.restCustomized&&!st.done&&st.id!==self.data.timerSetId){st.rest=next;changed=true;}});}});this.setData({exerciseLibrary:library,exercises:arr,saved:changed?false:this.data.saved});},onShow:function(){if(this.data.editError)return;this.syncLibraryRest();if(this._restClock&&this._restClock.active){this.startRestInterval();this.tickRest();}},onHide:function(){if(this._restInterval)clearInterval(this._restInterval);this._restInterval=null;},onUnload:function(){this._restPageDisposed=true;if(this._restInterval)clearInterval(this._restInterval);this._restInterval=null;cue.close();},
loadExistingWorkout:function(id){var r=require('../../utils/workout-records'),row;try{row=r.read(id);if(!s.byId('members',row.memberId))throw Error('关联会员不存在，无法编辑。');}catch(error){this.setData({editError:error.message,editingExisting:true});return;}this._workoutSnapshot=JSON.stringify(row);var member=s.byId('members',row.memberId),plans=s.list('plans').filter(function(p){return p.memberId===row.memberId&&(p.status==='published'||p.id===row.planId);}),pi=plans.map(function(p){return p.id;}).indexOf(row.planId)+1,lib=s.list('exercises'),course=s.byId('courses',row.courseId);if(!course&&!row.courseId&&!row.standalone)course=s.list('courses').find(function(c){return c.memberId===row.memberId&&c.workoutId===row.id;});this.setData({editingExisting:true,workoutId:row.id,memberId:row.memberId,members:[member],memberNames:[member.name],memberIndex:0,plans:plans,planId:row.planId||'',planIndex:pi,planNames:['不使用计划（自行添加动作）'].concat(plans.map(function(p){return p.name+' v'+p.version;})),date:row.date,time:row.time||(course?course.time:'09:00'),templateSnapshot:row.templateSnapshot||null,planChoiceLabel:row.templateSnapshot?row.templateSnapshot.name+' · '+row.templateSnapshot.dayName:'不使用计划',duration:row.duration,subjective:row.subjective||'',notes:row.notes||'',courseId:row.courseId||(course?course.id:''),courseTitle:course?course.date+' '+course.time+' · '+(course.title||'私教课程'):'',exercises:r.draft(row,lib),exerciseLibrary:lib,saved:true});},
openQuickExercise:function(){this._imageEpoch=(this._imageEpoch||0)+1;var g=this.data.selectedMuscle==='全部'?'胸部':this.data.selectedMuscle,c=this.data.equipmentFilter==='全部'?'哑铃':this.data.equipmentFilter;this.setData({showQuickExercise:true,quickGroupIndex:this.data.quickGroups.indexOf(g),quickCategoryIndex:this.data.quickCategories.indexOf(c),quickForm:{name:'',group:g,equipmentCategory:c,defaultSets:1,defaultReps:'',rest:120,intensity:'',notes:''}});},
chooseQuickImage:function(){require('../../utils/exercise-image-upload').choose(this,'quickForm','showQuickExercise');},clearQuickImage:function(){var f=Object.assign({},this.data.quickForm,{imagePath:''});this.setData({quickForm:f});},closeQuickExercise:function(){this._imageEpoch=(this._imageEpoch||0)+1;this.setData({showQuickExercise:false});},
quickInput:function(e){var key=e.currentTarget.dataset.key;if(['name','defaultSets','defaultReps','rest','intensity','notes'].indexOf(key)<0)return;var f=Object.assign({},this.data.quickForm);f[key]=e.detail.value;this.setData({quickForm:f});},
quickGroup:function(e){var i=Number(e.detail.value);if(!this.data.quickGroups[i])return;var f=Object.assign({},this.data.quickForm,{group:this.data.quickGroups[i]});this.setData({quickForm:f,quickGroupIndex:i});},
quickCategory:function(e){var i=Number(e.detail.value);if(!this.data.quickCategories[i])return;var f=Object.assign({},this.data.quickForm,{equipmentCategory:this.data.quickCategories[i]});this.setData({quickForm:f,quickCategoryIndex:i});},
saveQuickExercise:function(){if(this.data.imageSaving)return false;var f=this.data.quickForm,v=require('../../utils/validation');v.assert(f.name&&f.name.trim(),'请填写动作名称。');v.assert(Number.isInteger(Number(f.defaultSets))&&Number(f.defaultSets)>=1&&Number(f.defaultSets)<=20,'默认组数应为1至20整数。');v.assert(f.rest!==''&&Number.isInteger(Number(f.rest))&&Number(f.rest)>=0&&Number(f.rest)<=3600,'休息秒数应为0至3600整数。');v.assert(this.data.quickGroups.indexOf(f.group)>=0&&this.data.quickCategories.indexOf(f.equipmentCategory)>=0,'请选择有效肌群与动作类别。');var row={id:s.uid('e'),name:f.name.trim(),group:f.group,equipment:f.equipmentCategory,equipmentCategory:f.equipmentCategory,categoryVersion:2,defaultSets:Number(f.defaultSets),defaultReps:f.defaultReps||'',rest:Number(f.rest),imagePath:f.imagePath||'',intensity:'',notes:f.notes||'',custom:true,defaultsEdited:true};s.upsert('exercises',row);var self=this;require('../../utils/local-state').afterCommit(function(){self.setData({showQuickExercise:false,exerciseLibrary:s.list('exercises'),exerciseSearch:'',selectedMuscle:row.group,equipmentFilter:row.equipmentCategory,muscleOptions:require('../../utils/exercise-groups').optionsFor(s.list('exercises'))});self.filterExercises();feedback.showToast({title:'动作已新增，请点击选择',icon:'none'});});},
toggleSetMore:function(e){var arr=this.data.exercises,ei=Number(e.currentTarget.dataset.ei),si=Number(e.currentTarget.dataset.si);arr[ei].sets[si].more=!arr[ei].sets[si].more;this.setData({exercises:arr});},
openReorder:function(){if(!this.data.exercises.length)return;this.setData({reorderOpen:true,reorderDraft:this.data.exercises.map(function(x){return {id:x.id,name:x.name,group:x.group};}),dragIndex:-1,dragY:0});},
onSortScroll:function(e){this._sortScroll=e.detail.scrollTop;},closeReorder:function(){this._dragStart=null;this.setData({reorderOpen:false,dragIndex:-1});},
startReorder:function(e){if(!this.data.reorderOpen){this.openReorder();return;}var ix=Number(e.currentTarget.dataset.index);if(!this.data.reorderDraft[ix])return;var t=(e.touches&&e.touches[0])||(e.changedTouches&&e.changedTouches[0]);if(!t)return;var info=wx.getWindowInfo?wx.getWindowInfo():(wx.getSystemInfoSync?wx.getSystemInfoSync():{windowWidth:375});this._sortRowPx=104*(info.windowWidth||375)/750;this._dragStart={y:t.clientY,index:ix,scroll:this._sortScroll||0};var self=this;if(wx.createSelectorQuery)wx.createSelectorQuery().in(this).select('#sort-list').boundingClientRect(function(r){self._sortBounds=r;}).exec();this.setData({dragIndex:ix,dragY:0});wx.vibrateShort&&wx.vibrateShort({type:'light'});},
moveReorder:function(e){if(!this._dragStart)return;var t=e.touches&&e.touches[0];if(!t)return;var scroll=this._sortScroll||0;if(this._sortBounds){var edge=t.clientY<this._sortBounds.top+35?-1:t.clientY>this._sortBounds.bottom-35?1:0;if(edge){scroll=Math.max(0,Math.min(this.data.reorderDraft.length*this._sortRowPx-this._sortBounds.height,scroll+edge*18));this._sortScroll=scroll;this.setData({sortScrollTop:scroll});}}var delta=t.clientY-this._dragStart.y+scroll-(this._dragStart.scroll||0),from=this.data.dragIndex,target=Math.max(0,Math.min(this.data.reorderDraft.length-1,Math.round(this._dragStart.index+delta/this._sortRowPx))),rows=this.data.reorderDraft.slice();if(target!==from){var row=rows.splice(from,1)[0];rows.splice(target,0,row);}this.setData({reorderDraft:rows,dragIndex:target,dragY:delta-(target-this._dragStart.index)*this._sortRowPx});},
endReorder:function(){this._dragStart=null;this.setData({dragIndex:-1,dragY:0});},
nudgeReorder:function(e){var from=Number(e.currentTarget.dataset.index),to=from+Number(e.currentTarget.dataset.delta),arr=this.data.reorderDraft.slice();if(to<0||to>=arr.length)return;var row=arr.splice(from,1)[0];arr.splice(to,0,row);this.setData({reorderDraft:arr});},
saveReorder:function(){var original=this.data.exercises,rows=this.data.reorderDraft;if(rows.length!==original.length||new Set(rows.map(function(x){return x.id;})).size!==original.length)return;var next=rows.map(function(x){return original.filter(function(e){return e.id===x.id;})[0];});if(next.some(function(x){return !x;}))return;this.setData({exercises:next,reorderOpen:false,dragIndex:-1,saved:false});this._dragStart=null;},
changeDate:function(e){this.setData({date:e.detail.value,saved:false});}}))))));
