const bmi = require('../../utils/bmi-calculator');
const input = require('../../utils/quick-calculation-form');
const source = 'https://www.nhc.gov.cn/xcs/c100122/202503/27b26d397f4941ff8ff3846ef40026ee.shtml';

Page(require('../../utils/theme-page')(require('../../utils/back-navigation')('pages/bmi/index', {
  data: {
    height: '', weight: '', result: null, fieldErrors: {},
    fields: [{ key: 'height', label: '身高（cm）', placeholder: '填写身高' },
      { key: 'weight', label: '体重（kg）', placeholder: '填写体重' }],
    ranges: [
      { range: '＜18.5', label: '体重偏低', tone: 'warning' },
      { range: '18.5 ≤ BMI ＜ 24', label: '正常范围', tone: 'success' },
      { range: '24 ≤ BMI ＜ 28', label: '超重', tone: 'warning' },
      { range: '≥28', label: '肥胖', tone: 'danger' }
    ]
  },
  onInput(event) {
    const key = event.currentTarget.dataset.key;
    if (key !== 'height' && key !== 'weight') return;
    const patch = { [key]: event.detail.value };
    const { height, weight } = Object.assign({}, this.data, patch);
    const fieldErrors = {
      height: input.message(height, bmi.limits.height),
      weight: input.message(weight, bmi.limits.weight)
    };
    const valid = !fieldErrors.height && !fieldErrors.weight && input.complete(height) && input.complete(weight);
    this.setData(Object.assign(patch, { fieldErrors, result: valid ? bmi.compute(height, weight) : null }));
  },
  copyResult() {
    const { height, weight, result } = this.data;
    if (!result) return;
    input.copy('【小圆记课 · BMI 参考】\n身高：'+height+' cm\n体重：'+weight+' kg\nBMI：'+result.value+
      '\n中国成人参考分类：'+result.label+'\n计算：体重kg ÷ 身高m²。仅作成人参考，不能区分肌肉与脂肪。', '计算结果已复制');
  },
  copySource() { input.copy(source, '参考来源已复制'); }
})));
