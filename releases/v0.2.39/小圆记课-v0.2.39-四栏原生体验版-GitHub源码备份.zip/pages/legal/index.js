const docs = require('../../utils/legal-documents');

Page(require('../../utils/back-navigation')('pages/legal/index', {
  data: { document: null },
  onLoad(query) {
    try {
      const document = docs.get(query.kind === undefined ? 'privacy' : query.kind);
      document.sections = document.sections.map(([title, body], id) => ({ id, title, body }));
      this.setData({ document });
    } catch (error) {
      this.setData({ document: null });
    }
  },
  backLegal() { this.requestPageLeave({ waitForLayer: true }); }
}));
