const store = require('../../utils/store');
const validate = require('../../utils/validation');
const service = require('../../utils/local-service');
const errors = require('../../utils/operation-errors');
const view = require('../../utils/statistics-view');

const types = ['线下私教', '线上指导', '专项训练', '其他'];
const memberChoice = require('../../utils/member-choice');
const eligible = memberChoice.eligible;
const identity = member => JSON.stringify([member.name, member.phone || '']);
const memberChanged = '会员资料已变化，请重新选择。';

Page(require('../../utils/theme-page')(require('../../utils/back-navigation')('pages/course-sale/index',
  require('../../utils/feature-page')('packages', {
    data: {
      renewal: false, pageTitle: '新单售课', types, typeIndex: 0,
      form: { memberId: '', name: '', total: '', saleAmount: '', startDate: '', endDate: '', notes: '' },
      members: [], memberMatches: [], memberQuery: '', saleMemberOpen: false, memberLabel: '', memberError: '',
      saleDate: '', fieldErrors: {}, operationError: null, saving: false, receipt: null
    },
    onLoad(q = {}) {
      const renewal = q.renewal === '1';
      const saleDate = store.formatDate(new Date());
      this.sourceMonth = q.month || saleDate.slice(0, 7);
      this.setData({ renewal, saleDate, pageTitle: renewal ? '续费售课' : '新单售课',
        form: { ...this.data.form, name: renewal ? '续费课时包' : '线下私教课时包',
          startDate: saleDate, endDate: store.dateOffset(365) } });
    },
    onShow() { if (!this.data.receipt) this.refresh(); },
    refresh() {
      const members = store.visibleMembers().filter(eligible);
      this.setData({ members, saleDate: store.formatDate(new Date()) });
      const id = this.data.form.memberId;
      if (id && !this.matchesSelection(members.find(member => member.id === id))) this.invalidateMember();
      this.filterSaleMembers(this.data.memberQuery);
    },
    matchesSelection(member) { return eligible(member) && identity(member) === this.selectedIdentity; },
    invalidateMember() {
      this.selectedIdentity = '';
      this.setData({ form: { ...this.data.form, memberId: '' }, memberLabel: '', memberError: memberChanged });
    },
    openSaleMembers() {
      if (this.data.saving || this.data.receipt) return;
      this.finishKeyboardEditing();
      this.refresh();
      this.filterSaleMembers('');
      this.setData({ saleMemberOpen: true });
    },
    closeSaleMembers() {
      this.finishKeyboardEditing();
      this.setData({ saleMemberOpen: false });
    },
    searchSaleMembers(e) { this.filterSaleMembers(e.detail.value); },
    filterSaleMembers(value) {
      const query = value.trim().toLowerCase();
      const members = this.data.members;
      const memberMatches = memberChoice.describe(members).filter((row, index) =>
        !query || row.name.toLowerCase().includes(query) || String(members[index].phone || '').includes(query));
      this.setData({ memberQuery: value, memberMatches });
    },
    pickSaleMember(e) {
      const id = e.currentTarget.dataset.id;
      const row = this.data.memberMatches.find(member => member.id === id);
      const listed = this.data.members.find(member => member.id === id);
      const current = row && store.byId('members', id);
      if (!eligible(current) || !listed || identity(current) !== identity(listed)) {
        this.invalidateMember();
        this.refresh();
        return;
      }
      this.selectedIdentity = identity(current);
      this.setData({ form: { ...this.data.form, memberId: id },
        memberLabel: memberChoice.display(row), memberError: '', operationError: null });
      this.closeSaleMembers();
    },
    updateForm(field, value) {
      this.setData({ form: { ...this.data.form, [field]: value }, fieldErrors: { ...this.data.fieldErrors, [field]: '' } });
    },
    onTypeChange(e) { this.setData({ typeIndex: Number(e.detail.value) }); },
    onInput(e) { this.updateForm(e.currentTarget.dataset.key, e.detail.value); },
    onStart(e) { this.updateForm('startDate', e.detail.value); },
    onEnd(e) { this.updateForm('endDate', e.detail.value); },
    save() {
      const { form, renewal, saving, receipt, featureLocked } = this.data;
      if (saving || receipt || featureLocked || !form.memberId) return;
      this.finishKeyboardEditing();
      if (!this.matchesSelection(store.byId('members', form.memberId))) {
        this.invalidateMember();
        this.refresh();
        return;
      }
      const name = form.name.trim();
      const amount = form.saleAmount.trim() || '0';
      const fieldErrors = {};
      const checks = {
        name: () => validate.assert(name, '请填写课时包名称。'),
        total: () => validate.number(form.total, 1, '总课时', true),
        saleAmount: () => {
          validate.packageAmount(amount);
          validate.assert(!/\.\d{3,}/.test(amount), '金额最多保留两位小数。');
        },
        startDate: () => validate.date(form.startDate, '开始日期'),
        endDate: () => {
          validate.date(form.endDate, '到期日期');
          validate.assert(form.endDate >= form.startDate, '到期日期不能早于开始日期。');
        }
      };
      for (const field of Object.keys(checks)) {
        try { checks[field](); } catch (error) { fieldErrors[field] = error.message; }
      }
      const saleDate = store.formatDate(new Date());
      this.setData({ fieldErrors, saleDate, operationError: null });
      if (Object.keys(fieldErrors).length) return;
      this.setData({ saving: true });
      const result = service.execute(() => {
        const member = store.byId('members', form.memberId);
        if (!this.matchesSelection(member)) throw errors.create('CONFLICT', memberChanged);
        const pack = store.addPackage({ memberId: member.id, name, type: types[this.data.typeIndex], total: Number(form.total),
          saleAmount: Number(amount), saleDate, renewal, startDate: form.startDate, endDate: form.endDate, notes: form.notes });
        return { pack, memberName: member.name };
      });
      if (!result.ok) {
        this.setData({ saving: false });
        if (result.error.code === 'CONFLICT') { this.invalidateMember(); this.refresh(); }
        else this.setData({ operationError: result.error });
        return;
      }
      const { pack, memberName } = result.data;
      const month = pack.saleDate.slice(0, 7);
      this.setData({ saving: false, receipt: { packageId: pack.id, memberId: pack.memberId, memberName,
        name: pack.name, total: pack.total, amount: view.yuan(pack.saleAmount), saleDate: pack.saleDate,
        monthNotice: month !== this.sourceMonth ? '已计入 ' + month.slice(0, 4) + ' 年 ' + Number(month.slice(5, 7)) + ' 月售课统计' : '' } });
    },
    viewSoldPackage() {
      const receipt = this.data.receipt;
      if (receipt) view.openPackage(store, receipt.packageId, receipt.memberId);
    },
    cancel() {
      if (this.data.saving) return;
      if (this.data.saleMemberOpen) this.closeSaleMembers();
      else this.requestPageLeave();
    }
  }))));
