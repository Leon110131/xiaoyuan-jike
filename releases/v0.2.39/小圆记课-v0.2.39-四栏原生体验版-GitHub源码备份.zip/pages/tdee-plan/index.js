const store = require('../../utils/store');
const engine = require('../../utils/tdee-plan');
const feedback = require('../../utils/page-feedback');
const service = require('../../utils/local-service');
const memberChoice = require('../../utils/member-choice');

const activities = [
  { name: '久坐', hint: '很少运动', value: '1.2' },
  { name: '轻度活动', hint: '每周训练 1–3 次', value: '1.375' },
  { name: '中度活动', hint: '每周训练 3–5 次', value: '1.55' },
  { name: '高度活动', hint: '每周训练 6–7 次', value: '1.725' },
  { name: '极高活动', hint: '高强度训练或体力工作', value: '1.9' }
];
const goals = [
  { key: 'loss', name: '减脂', presets: [10, 15, 20] },
  { key: 'maintain', name: '维持', presets: [] },
  { key: 'gain', name: '增肌', presets: [5, 10, 15] }
];
const bodyFields = [
  { key: 'age', label: '年龄（岁）', placeholder: '请输入年龄', type: 'number' },
  { key: 'height', label: '身高（cm）', placeholder: '请输入身高', type: 'digit' },
  { key: 'weight', label: '当前体重（kg）', placeholder: '请输入当前体重', type: 'digit' },
  { key: 'targetWeight', label: '目标体重（kg）', placeholder: '请输入目标体重', type: 'digit' }
];
const macroOptions = [{ key: 'carbs', name: '碳水' }, { key: 'protein', name: '蛋白质' }, { key: 'fat', name: '脂肪' }];
const source = 'Mifflin–St Jeor (1990): https://pubmed.ncbi.nlm.nih.gov/2305711/';
const blank = () => ({ sex: '', age: '', height: '', weight: '', targetWeight: '', activity: '1.55' });
const eligibleMembers = () => memberChoice.describe(store.visibleMembers().filter(memberChoice.eligible));
const memberInvalid = '会员已失效，请重新选择。规划结果已保留。';
const formatEnergy = value => String(value).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
const staleResult = '规划结果已变化，请返回检查后重新应用。';

const config = {
  data: {
    step: 0, steps: ['身体数据', '活动与锁定', '目标与营养'], contentScrollTop: 0,
    form: blank(), bodyFields, activities, activityName: '中度活动', customActivity: false, planActivityOpen: false,
    macroOptions, lockCards: [], locks: {}, lockCount: 0, lockModal: false, lockKey: '', lockName: '',
    lockMode: 'percent', lockValue: '', lockError: '', lockKeyboardHeight: 0, lockDialogMaxHeight: 600,
    goals, goal: '', adjustment: '', presets: [], result: null, error: '', lockConflict: false,
    planApplyOpen: false, saving: false, members: [], memberNames: [], memberId: '', memberIndex: -1,
    memberName: '', memberLabel: '', memberError: '', applyError: '', receipt: null, syncHint: ''
  },
  onLoad(q = {}) {
    this.sourceMemberId = q.memberId || '';
    const members = eligibleMembers();
    this.setData({ form: blank(), locks: {}, ...this.selection(members, this.sourceMemberId) });
    this.refreshLocks();
  },
  onBodyInput(e) {
    const key = e.currentTarget.dataset.key;
    if (!bodyFields.some(field => field.key === key) && key !== 'activity') return;
    this.updateForm(key, e.detail.value);
  },
  chooseSex(e) {
    const value = e.currentTarget.dataset.value;
    if (value === 'male' || value === 'female') this.updateForm('sex', value);
  },
  updateForm(key, value) {
    this.setData({ form: { ...this.data.form, [key]: value }, result: null, error: '', lockConflict: false, syncHint: '' });
  },
  openActivity() {
    this.finishKeyboardEditing();
    this.setData({ planActivityOpen: true });
  },
  closeActivity() { this.setData({ planActivityOpen: false }); },
  chooseActivity(e) {
    const activity = activities.find(item => item.value === e.currentTarget.dataset.value);
    if (!activity) return;
    this.updateForm('activity', activity.value);
    this.setData({ activityName: activity.name, customActivity: false, planActivityOpen: false });
  },
  toggleCustomActivity() { this.setData({ customActivity: true, planActivityOpen: false }); },
  goToStep(step) {
    this.finishKeyboardEditing();
    this.setData({ step, error: '', lockConflict: false, contentScrollTop: this.data.contentScrollTop === 0 ? 1 : 0 });
    if (step === 2) this.recalculate();
  },
  next() {
    try {
      engine.body(this.data.form);
      if (this.data.step === 1) engine.validateLocks(this.data.locks);
      this.goToStep(Math.min(2, this.data.step + 1));
    } catch (error) {
      this.setData({ error: error.message });
    }
  },
  previous() { this.goToStep(Math.max(0, this.data.step - 1)); },
  backPlan() {
    if (this.data.lockModal) this.closeLock();
    else if (this.data.planActivityOpen) this.closeActivity();
    else if (this.data.planApplyOpen) this.closePlanApply();
    else if (this.data.step > 0) this.previous();
    else this.requestPageLeave();
  },
  refreshLocks() {
    const locks = this.data.locks;
    this.setData({
      lockCount: Object.keys(locks).length,
      lockCards: macroOptions.map(({ key, name }) => {
        const lock = locks[key];
        return { key, name, locked: !!lock, label: lock ? lock.value + (lock.mode === 'percent' ? '%' : ' g') : '未锁定' };
      })
    });
  },
  lockViewportHeight() {
    if (this._lockViewportHeight) return this._lockViewportHeight;
    try {
      const info = typeof wx.getWindowInfo === 'function' ? wx.getWindowInfo() : wx.getSystemInfoSync();
      this._lockViewportHeight = Number(info.windowHeight) || 720;
      return this._lockViewportHeight;
    } catch (error) { return 720; }
  },
  chooseGoal(e) {
    const goal = goals.find(item => item.key === e.currentTarget.dataset.value);
    if (!goal || this.data.goal === goal.key) return;
    this.setData({ goal: goal.key, adjustment: goal.key === 'maintain' ? '0' : '', presets: goal.presets, syncHint: '' });
    this.recalculate();
  },
  chooseAdjustment(e) { this.setAdjustment(String(e.currentTarget.dataset.value)); },
  onAdjustment(e) { this.setAdjustment(e.detail.value); },
  setAdjustment(adjustment) {
    this.setData({ adjustment, syncHint: '' });
    this.recalculate();
  },
  calculate() {
    return engine.calculate(this.data.form, this.data.goal, this.data.adjustment, this.data.locks);
  },
  recalculate() {
    if (!this.data.goal || (this.data.goal !== 'maintain' && this.data.adjustment === '')) {
      this.setData({ result: null, error: '', lockConflict: false });
      return;
    }
    try {
      const result = this.calculate();
      const energy = { goal: formatEnergy(result.kcal), tdee: formatEnergy(result.tdee), bmr: formatEnergy(result.bmr) };
      this.setData({ result, energy, error: '', lockConflict: false });
    } catch (error) {
      this.setData({ result: null, error: error.message, lockConflict: error.code === 'LOCK_ENERGY' });
    }
  },
  selection(members, id) {
    const memberIndex = members.findIndex(member => member.id === id);
    const member = members[memberIndex];
    return {
      members, memberNames: ['选择会员'].concat(members.map(memberChoice.display)), memberIndex,
      memberId: member ? member.id : '', memberName: member ? member.name : '', memberLabel: member ? memberChoice.display(member) : ''
    };
  },
  openPlanApply() {
    if (!this.data.result || this.data.featureLocked || this.data.saving || this.data.planApplyOpen) return;
    this.finishKeyboardEditing();
    const selection = this.selection(eligibleMembers(), this.sourceMemberId);
    this.setData({
      ...selection, planApplyOpen: true, applyError: '', receipt: null,
      memberError: this.sourceMemberId && !selection.memberId ? memberInvalid : ''
    });
  },
  closePlanApply() {
    if (!this.data.saving) this.setData({ planApplyOpen: false });
  },
  onMemberChange(e) {
    if (this.data.saving || this.data.receipt) return;
    const memberIndex = Number(e.detail.value) - 1;
    const member = this.data.members[memberIndex];
    this.setData({
      memberIndex, memberId: member ? member.id : '', memberName: member ? member.name : '', memberLabel: member ? memberChoice.display(member) : '',
      memberError: '', applyError: ''
    });
  },
  confirmPlanApply() {
    if (this.data.planApplyOpen) return this.saveGoal();
  },
  saveGoal() {
    const { memberId, result, saving, receipt, featureLocked } = this.data;
    if (!memberId || !result || saving || receipt || featureLocked) return false;
    this.setData({ saving: true, applyError: '' });
    const outcome = service.execute(() => {
      store.assertCoachWrite('nutrition');
      const members = eligibleMembers();
      const member = members.find(item => item.id === memberId);
      if (!member) return { members };
      let latest;
      try { latest = this.calculate(); } catch (error) { return { stale: true }; }
      if (latest.text !== result.text) return { stale: true };
      const previous = store.list('nutritionGoals').find(item => item.memberId === memberId) || { memberId, notes: '' };
      const { kcal, carbs, protein, fat } = latest;
      store.saveNutritionGoal({ ...previous, kcal, carbs, protein, fat });
      return { receipt: { memberId, memberLabel: memberChoice.display(member), kcal, carbs, protein, fat } };
    });
    if (!outcome.ok) {
      this.setData({ saving: false, applyError: outcome.error.message });
      return false;
    }
    if (outcome.data.members) {
      this.setData({ ...this.selection(outcome.data.members, ''), saving: false, memberError: memberInvalid });
      return false;
    }
    if (outcome.data.stale) {
      this.recalculate();
      this.setData({ saving: false, planApplyOpen: false });
      feedback.showToast({ title: staleResult, icon: 'none' });
      return false;
    }
    this.setData({ saving: false, receipt: outcome.data.receipt, syncHint: '每日营养目标已同步' });
    return true;
  },
  openSavedGoal() {
    const receipt = this.data.receipt;
    if (!receipt || this._openingGoal) return;
    const pages = getCurrentPages();
    const previous = pages[pages.length - 2];
    const fail = () => { this._openingGoal = false; };
    this._openingGoal = true;
    if (previous && previous.route === 'pages/nutrition/index' && previous.data.memberId === receipt.memberId) {
      this.requestPageLeave({ fail, waitForLayer: true });
      return;
    }
    feedback.redirectTo({ url: '/pages/nutrition/index?memberId=' + encodeURIComponent(receipt.memberId), fail });
  },
  copyResult() {
    if (this.data.result) this.copyText(this.data.result.text, '已复制结果');
  },
  showBasis() {
    feedback.showModal({ title: '计算依据',
      content: '静息能量采用 Mifflin–St Jeor 公式。未锁定部分按碳水 50、蛋白质 30、脂肪 20 的相对权重分配剩余热量。',
      confirmText: '复制来源', cancelText: '关闭', success: result => { if (result.confirm) this.copySource(); } });
  },
  copySource() { this.copyText(source, '已复制参考来源'); },
  copyText(data, title) {
    wx.setClipboardData({ data, success: () => feedback.showToast({ title, icon: 'none' }),
      fail: () => feedback.showToast({ title: '复制失败，请重试', icon: 'none' }) });
  }
};

Page(require('../../utils/theme-page')(require('../../utils/macro-lock-editor')(
  require('../../utils/back-navigation')('pages/tdee-plan/index',
    require('../../utils/feature-page')('nutrition', config)))));
