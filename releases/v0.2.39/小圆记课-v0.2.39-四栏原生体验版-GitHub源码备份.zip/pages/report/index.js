const store = require('../../utils/store');
const service = require('../../utils/local-service');
const feedback = require('../../utils/page-feedback');
const validate = require('../../utils/validation');
const stage = require('../../utils/stage-report');
const memberChoice = require('../../utils/member-choice');

const available = () => store.visibleMembers();
const clearPreview = { report: null, preview: '', reportSaved: false, previewOpen: false, saveIssue: '' };
function rangeLabel(report) {
  if (!report.startDate || !report.endDate) return '未记录报告周期';
  const [sy, sm, sd] = report.startDate.split('-');
  const [ey, em, ed] = report.endDate.split('-');
  return sy + '年' + Number(sm) + '月' + Number(sd) + '日–' +
    (sy === ey ? '' : ey + '年') + Number(em) + '月' + Number(ed) + '日';
}

const config = {
  data: {
    memberId: '', member: null, avatar: '', members: [], reports: [], startDate: '', endDate: '', coachComment: '',
    dateIssue: '', issue: '', pickerOpen: false, historyOpen: false, previewOpen: false, detailMode: false,
    report: null, historyReport: null, displayReport: null, preview: '', reportSaved: false, saving: false,
    saveIssue: '', deleteTarget: null, deleteIssue: '', removing: false, copying: false, copyIssue: ''
  },
  onLoad(q = {}) {
    this.reportId = q.reportId || '';
    const found = this.reportId && stage.read(this.reportId, q.memberId);
    this.memberId = q.memberId || (found && found.memberId) || (this.reportId ? '' : (available()[0] || {}).id) || '';
    this.setData({ startDate: store.dateOffset(-28), endDate: store.formatDate(new Date()), detailMode: !!this.reportId });
  },
  onShow() {
    this.refresh();
    if (this.reportId) this.showDetail(stage.read(this.reportId, this.memberId));
  },
  refresh() {
    const members = memberChoice.describe(available());
    const member = members.find(item => item.id === this.memberId) || null;
    const reports = store.list('reports').filter(row => row.reportType !== 'summary' && row.memberId === this.memberId)
      .sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''))
      .map(row => ({ id: row.id, createdAt: row.createdAt, title: rangeLabel(row) }));
    this.setData({ memberId: this.memberId, members, member, avatar: member ? Array.from(member.name || '?')[0] : '', reports });
  },
  openPicker() { this.finishKeyboardEditing(); this.refresh(); this.setData({ pickerOpen: true }); },
  closePicker() { this.setData({ pickerOpen: false }); },
  onMemberChange(event) {
    const id = event.currentTarget.dataset.id;
    if (!this.data.members.some(item => item.id === id)) return;
    this.closePicker();
    if (id === this.memberId) return;
    this.memberId = id;
    this.setData({ ...clearPreview, dateIssue: '', issue: '' });
    this.refresh();
  },
  updateSettings(key, value) {
    if (this.data[key] !== value) this.setData({ [key]: value, ...clearPreview, dateIssue: '', issue: '' });
  },
  onStartDate(event) { this.updateSettings('startDate', event.detail.value); },
  onEndDate(event) { this.updateSettings('endDate', event.detail.value); },
  onCoachComment(event) { this.updateSettings('coachComment', event.detail.value); },
  generate() {
    if (this.data.featureLocked || this.data.saving) return false;
    this.finishKeyboardEditing();
    const { startDate, endDate, coachComment, report } = this.data;
    try {
      validate.date(startDate, '开始日期');
      validate.date(endDate, '结束日期');
      validate.assert(startDate <= endDate, '开始日期不能晚于结束日期。');
    } catch (error) {
      this.setData({ ...clearPreview, dateIssue: error.message });
      return false;
    }
    if (report && report.memberId === this.memberId && report.startDate === startDate && report.endDate === endDate &&
        this.generatedComment === coachComment && available().some(row => row.id === this.memberId)) {
      this.setData({ previewOpen: true, copyIssue: '' });
      return true;
    }
    const result = service.execute(() => stage.generate(this.memberId, startDate, endDate, coachComment));
    if (!result.ok) {
      this.setData({ ...clearPreview, issue: result.error.message });
      return false;
    }
    const snapshot = result.data;
    this.generatedComment = coachComment;
    this.setData({ ...clearPreview, previewOpen: true, report: snapshot, preview: snapshot.text, issue: '', dateIssue: '',
      displayReport: { ...snapshot, rangeLabel: rangeLabel(snapshot) }, copyIssue: '' });
    return true;
  },
  closePreview() { if (!this.data.saving) this.setData({ previewOpen: false }); },
  saveReport() {
    const { report, previewOpen, saving, reportSaved, featureLocked } = this.data;
    if (!report || !previewOpen || saving || reportSaved || featureLocked) return false;
    this.setData({ saving: true, saveIssue: '' });
    const result = service.execute(() => {
      store.assertCoachWrite('reports');
      const member = store.byId('members', this.memberId);
      validate.assert(member && !member.listRemoved && report.memberId === member.id, '会员关联已失效，请返回重新生成。');
      const existing = store.byId('reports', report.id);
      validate.assert(!existing || JSON.stringify(existing) === JSON.stringify(report), '报告已变化，请返回重新生成。');
      if (!existing) store.upsert('reports', { ...report });
    });
    this.setData({ saving: false, reportSaved: result.ok, saveIssue: result.ok ? '' : result.error.message + '已保留预览。' });
    if (result.ok) feedback.showToast({ title: '报告已保存', icon: 'success' });
    return result.ok;
  },
  openHistory() {
    this.finishKeyboardEditing();
    this.refresh();
    this.setData({ historyOpen: true });
  },
  closeHistory() { this.setData({ historyOpen: false }); },
  viewHistory(event) {
    const id = event.currentTarget.dataset.id;
    if (!this.memberId) return;
    const report = stage.read(id, this.memberId);
    if (this.data.historyOpen) this.showDetail(report);
    else if (report) feedback.navigateTo({ url: '/pages/report/index?reportId=' + encodeURIComponent(id) + '&memberId=' + encodeURIComponent(this.memberId) });
  },
  showDetail(report) {
    this.setData({ detailMode: true, historyReport: report, preview: report ? report.text : '',
      displayReport: report ? { ...report, rangeLabel: rangeLabel(report) } : null, copyIssue: '' });
  },
  closeDetail() {
    if (this.data.removing) return;
    if (this.reportId) this.requestPageLeave();
    else {
      const report = this.data.report;
      this.setData({ detailMode: false, historyReport: null, preview: report ? report.text : '',
        displayReport: report ? { ...report, rangeLabel: rangeLabel(report) } : null, copyIssue: '' });
    }
  },
  copyReport() {
    const { detailMode, historyReport, report, copying } = this.data;
    const snapshot = detailMode ? historyReport : report;
    if (!snapshot || !snapshot.text || copying) return;
    this.setData({ copying: true, copyIssue: '' });
    const fail = () => this.setData({ copying: false, copyIssue: '复制失败，请重试。' });
    try {
      wx.setClipboardData({ data: snapshot.text, fail, success: () => {
        this.setData({ copying: false });
        feedback.showToast({ title: '报告已复制', icon: 'success' });
      } });
    } catch (error) { fail(); }
  },
  openReportDelete() {
    const row = this.data.historyReport;
    if (row && !this.data.featureLocked) this.setData({ deleteTarget: row, deleteIssue: '' });
  },
  closeReportDelete() { if (!this.data.removing) this.setData({ deleteTarget: null, deleteIssue: '' }); },
  confirmReportDelete() { return this.confirmDeleteReport(this.data.deleteTarget); },
  deleteReport(event) {
    const row = stage.read(event.currentTarget.dataset.id, this.memberId);
    if (!row || !this.memberId) return;
    wx.showModal({ title: '删除这份阶段报告？', content: '仅删除所选报告快照，原记录保留。',
      confirmText: '删除报告', success: result => { if (result.confirm) this.confirmDeleteReport(row); } });
  },
  confirmDeleteReport(target) {
    if (!target || this.data.removing || this.data.featureLocked || target.memberId !== this.memberId) return false;
    this.setData({ removing: true, deleteIssue: '' });
    const result = service.execute(() => {
      store.assertCoachWrite('reports');
      const row = stage.read(target.id, this.memberId);
      validate.assert(row && JSON.stringify(row) === JSON.stringify(target), '报告已变化，请返回历史核对。');
      const reports = store.list('reports');
      const index = reports.findIndex(item => item.id === target.id && item.memberId === target.memberId && item.reportType !== 'summary');
      reports.splice(index, 1);
      store.set('reports', reports);
    });
    this.setData({ removing: false, deleteIssue: result.ok ? '' : result.error.message });
    if (!result.ok) return false;
    this.closeReportDelete();
    if (this.data.report && this.data.report.id === target.id) this.setData(clearPreview);
    if (this.data.detailMode) this.closeDetail();
    this.refresh();
    feedback.showToast({ title: '报告已删除', icon: 'none' });
    return true;
  },
  backStage() {
    if (this.data.deleteTarget) this.closeReportDelete();
    else if (this.data.pickerOpen) this.closePicker();
    else if (this.data.detailMode) this.closeDetail();
    else if (this.data.previewOpen) this.closePreview();
    else if (this.data.historyOpen) this.closeHistory();
    else this.requestPageLeave();
  }
};

Page(require('../../utils/theme-page')(require('../../utils/back-navigation')('pages/report/index',
  require('../../utils/feature-page')('reports', config))));
