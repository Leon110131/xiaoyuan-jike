const store = require('../../utils/store');
const service = require('../../utils/local-service');
const cleanup = require('../../utils/sample-cleanup');

const fields = [
  { key: 'members', label: '会员', unit: '位' },
  { key: 'courses', label: '课程', unit: '条' },
  { key: 'packages', label: '课时包', unit: '个' },
  { key: 'workouts', label: '训练记录', unit: '条' },
  { key: 'workoutDrafts', label: '训练草稿', unit: '份' },
  { key: 'measurements', label: '体测', unit: '条' },
  { key: 'financialEntries', label: '收支', unit: '条' }
];

function counts(data) {
  return Object.fromEntries(fields.map(({ key }) => [key, (data[key] || []).length]));
}

function formatTime(value) {
  if (typeof value !== 'string' || !value.trim()) return '旧备份未记录';
  const date = new Date(value);
  if (isNaN(date.getTime())) return value;
  const time = [date.getHours(), date.getMinutes()].map(part => String(part).padStart(2, '0')).join(':');
  return store.formatDate(date) + ' ' + time;
}

function comparison(backup, current) {
  const incoming = counts(backup);
  const existing = counts(current);
  const missingDrafts = !Object.prototype.hasOwnProperty.call(backup, 'workoutDrafts');
  const rows = fields.map(({ key, label, unit }) => ({
    key, label,
    current: existing[key] + ' ' + unit,
    backup: missingDrafts && key === 'workoutDrafts' ? '旧备份未包含' : incoming[key] + ' ' + unit
  }));
  let draftNote = '';
  if (!incoming.workoutDrafts) {
    draftNote = existing.workoutDrafts
      ? '恢复后，当前 ' + existing.workoutDrafts + ' 份训练草稿将被清空。'
      : '恢复后训练草稿为空。';
  }
  return { time: formatTime(backup.exportedAt), rows, draftNote };
}

function clipboardCompletion(callback, timeoutMessage) {
  let pending = true;
  const finish = (value, error) => {
    if (!pending) return;
    pending = false;
    callback(value, error);
  };
  setTimeout(() => finish(null, timeoutMessage), 5000);
  return finish;
}

const config = {
  data: {
    backupScreen: '', backupText: '', restoreText: '', counts: {},
    lastExport: '', backupVersion: null, exportCounts: null, feedback: null,
    copying: false, pasting: false, restoring: false, restoreReview: null, scrollToFeedback: false
  },

  onLoad(query) { if (query && query.cleanup === '1') this.setData({ cleanupMode: true }); },
  onShow() {
    if (this.data.cleanupMode) this.previewCleanup();
    else this.refresh();
  },

  refresh() { this.setData({ counts: counts(store.snapshot()) }); },

  showFeedback(title, message, tone = 'error') {
    this.setData({ feedback: { title, message, tone }, scrollToFeedback: tone === 'error' });
  },

  createBackup() {
    if (this.data.featureLocked || this.data.copying) return '';
    this.setData({ backupScreen: 'export', feedback: null, scrollToFeedback: false });
    try {
      const snapshot = store.snapshot();
      const { scope, backupVersion, demoOnly } = snapshot;
      const text = JSON.stringify({ scope, backupVersion, demoOnly, ...snapshot }, null, 2);
      store.validateBackup(text);
      this.setData({
        backupText: text, lastExport: formatTime(snapshot.exportedAt),
        backupVersion, exportCounts: counts(snapshot)
      });
      return text;
    } catch (error) {
      this.showFeedback('备份未生成', error.message);
      return '';
    }
  },

  copyBackup() {
    const text = this.createBackup();
    if (!text) return;
    this.setData({ copying: true });
    const finish = clipboardCompletion((verified, error) => {
      this.setData({ copying: false });
      if (error) {
        this.showFeedback('备份未完整复制', error + '原文仍在，可长按选取或重试。');
      } else {
        this.showFeedback('最新备份已复制', verified ? '请粘贴到安全位置另存。'
          : '当前环境无法回读校验，请粘贴并核对完整后另存。', 'success');
      }
    }, '暂时无法确认剪贴板内容。');
    try {
      wx.setClipboardData({
        data: text,
        success() {
          if (typeof wx.getClipboardData !== 'function') {
            finish(false);
            return;
          }
          const unavailable = () => finish(false, '无法读取剪贴板来校验。');
          try {
            wx.getClipboardData({
              success: result => {
                if (result.data === text) finish(true);
                else finish(false, '剪贴板内容与完整备份不一致。');
              },
              fail: unavailable
            });
          } catch (error) {
            unavailable();
          }
        },
        fail: () => finish(false, '无法写入剪贴板。')
      });
    } catch (error) {
      finish(false, '无法写入剪贴板。');
    }
  },

  openRestore() {
    if (!this.data.featureLocked) this.setData({ backupScreen: 'restore', feedback: null, scrollToFeedback: false });
  },

  onRestoreInput(event) {
    if (!this.data.restoreReview) {
      this.setData({ restoreText: event.detail.value, feedback: null, scrollToFeedback: false });
    }
  },

  pasteBackup() {
    if (this.data.pasting || this.data.restoreReview) return;
    this.finishKeyboardEditing();
    const original = this.data.restoreText;
    this.setData({ pasting: true, feedback: null, scrollToFeedback: false });
    const finish = clipboardCompletion((text, error) => {
      this.setData({ pasting: false });
      if (this.data.restoreText !== original) return;
      if (error) this.showFeedback(error, '请长按备份文本输入框手动粘贴。');
      else this.setData({ restoreText: text });
    }, '读取剪贴板超时');
    const fallback = () => finish(null, '读取剪贴板失败');
    if (typeof wx.getClipboardData !== 'function') {
      fallback();
      return;
    }
    try {
      wx.getClipboardData({
        success: result => {
          if (result.data) finish(result.data);
          else finish(null, '剪贴板中没有文本');
        },
        fail: fallback
      });
    } catch (error) {
      fallback();
    }
  },

  clearBackup() {
    if (this.data.restoreReview || this.data.pasting) return;
    this.setData({ restoreText: '', feedback: null, scrollToFeedback: false });
  },

  restore() {
    const { restoreText, restoring, restoreReview, pasting, featureLocked } = this.data;
    if (featureLocked || restoring || restoreReview || pasting || !restoreText.trim()) return false;
    this.finishKeyboardEditing();
    try {
      const backup = store.validateBackup(restoreText);
      const revision = store.revision();
      const current = store.snapshot();
      this._pendingRestore = { backup, revision };
      this.setData({ restoreReview: comparison(backup, current), feedback: null, scrollToFeedback: false });
      return true;
    } catch (error) {
      this.showFeedback('备份验证未通过', error.name === 'SyntaxError' ? '请输入完整的 JSON 备份文本。' : error.message);
      return false;
    }
  },

  cancelRestore() {
    if (this.data.restoring) return;
    this._pendingRestore = null;
    this.setData({ restoreReview: null });
  },

  confirmRestore() {
    const pending = this._pendingRestore;
    if (!pending || this.data.restoring) return false;
    this._pendingRestore = null;
    this.setData({ restoring: true });
    const result = service.execute(() => {
      store.assertCoachWrite('backup');
      return store.restoreSnapshot(pending.backup);
    }, { expectedRevision: pending.revision });
    this.setData({ restoring: false, restoreReview: null });
    if (!result.ok) {
      if (result.error.code === 'CONFLICT') {
        this.showFeedback('确认期间数据已变化', '请重新验证并核对覆盖范围。');
      } else {
        this.showFeedback('恢复未完成', result.error.message + '原数据和粘贴文本已保留，可重试。');
      }
      return false;
    }
    this.setData({
      backupScreen: '', backupText: '', restoreText: '', lastExport: '', backupVersion: null, exportCounts: null
    });
    this.refresh();
    this.showFeedback('数据恢复成功', '工作空间和教练资料已更新。', 'success');
    return true;
  },

  closeBackupScreen() {
    if (this.data.copying || this.data.pasting) return;
    this.finishKeyboardEditing();
    this.setData({ backupScreen: '', feedback: null, scrollToFeedback: false });
    this.refresh();
  },

  backBackup() {
    if (this.data.cleanupConfirm) this.cancelCleanup();
    else if (this.data.restoreReview) this.cancelRestore();
    else if (this.data.backupScreen) this.closeBackupScreen();
    else this.requestPageLeave();
  },

  reset() { wx.navigateTo({ url: '/pages/data-tools/index?cleanup=1' }); },

  previewCleanup(message = null) {
    if (this.data.cleaning || this.data.featureLocked) return;
    try {
      const preview = cleanup.preview('coach');
      const units = { members: '位', packages: '个', plans: '份', reports: '份' };
      const cleanupRows = preview.rows.filter(row => row.count).map(row => ({
        collection: row.collection, label: row.label, value: row.count + ' ' + (units[row.collection] || '条')
      }));
      this.setData({ cleanupPreview: preview, cleanupRows, cleanupStale: false, cleanupConfirm: false,
        cleanupMessage: message && message.title ? message : null });
    } catch (error) {
      this.setData({ cleanupStale: true, cleanupConfirm: false,
        cleanupMessage: { title: '暂时无法预览', text: error.message, error: true } });
    }
  },

  openCleanupConfirm() {
    const { cleanupPreview, cleanupStale } = this.data;
    if (cleanupPreview && !cleanupPreview.blockedReason && cleanupPreview.total && !cleanupStale) {
      this.setData({ cleanupConfirm: true, cleanupMessage: null });
    }
  },
  cancelCleanup() {
    if (!this.data.cleaning) this.setData({ cleanupConfirm: false, cleanupMessage: null });
  },

  submitCleanup() {
    const { cleanupConfirm, cleanupPreview, cleaning } = this.data;
    if (!cleanupConfirm || cleaning || !cleanupPreview || cleanupPreview.blockedReason) return false;
    this.setData({ cleaning: true });
    const result = service.execute(() => cleanup.clear('coach', cleanupPreview.revision));
    this.setData({ cleaning: false });
    if (!result.ok) {
      const stale = result.error.code === 'CONFLICT' || result.error.code === 'VALIDATION';
      this.setData({
        cleanupConfirm: !stale, cleanupStale: stale,
        cleanupMessage: { title: stale ? '需要重新预览' : '清理未完成',
          text: stale ? result.error.message : '工作空间原记录已保留，可重试。', error: true }
      });
      return false;
    }
    this.previewCleanup({ title: '示例已清除', text: '已清理 ' + result.data.total + ' 条经核验的示例记录。' });
    return true;
  }
};

Page(require('../../utils/theme-page')(require('../../utils/back-navigation')('pages/data-tools/index',
  require('../../utils/feature-page')('backup', config))));
