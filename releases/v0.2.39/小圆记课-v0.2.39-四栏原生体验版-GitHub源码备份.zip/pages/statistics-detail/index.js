const store = require('../../utils/store');
const details = require('../../utils/statistics-details');
const cashRecords = require('../../utils/cash-records');
const view = require('../../utils/statistics-view');
const feedback = require('../../utils/page-feedback');
const manual = require('../../utils/manual-finance');
const service = require('../../utils/local-service');

const cashTabs = [
  { key: 'cashBalance', label: '全部' }, { key: 'sales', label: '售课' },
  { key: 'cashIncome', label: '手工收入' }, { key: 'cashExpense', label: '支出' }
];
const lessonTabs = [
  { key: 'completed', label: '完成课程' }, { key: 'learners', label: '上课会员' },
  { key: 'income', label: '确认收入' }
];
const allTabs = cashTabs.concat(lessonTabs);

Page(require('../../utils/theme-page')(require('../../utils/back-navigation')('pages/statistics-detail/index',
  require('../../utils/feature-page')('statistics', {
    data: { detail: null, record: null, error: '', month: '', monthLabel: '', tabs: [], kind: '',
      member: null, readTitle: '', summaryValue: '', summaryLabel: '', summaryNote: '', emptyTitle: '',
      financeDelete: null, deleteError: null, deleting: false, entryChanged: false },
    onLoad(q = {}) {
      this.memberId = q.memberId || '';
      this.recordKey = q.record || '';
      this.recordMemberId = q.memberId || '';
      this.setData({ month: q.month || store.formatDate(new Date()).slice(0, 7), kind: q.kind || 'completed' });
      this.refresh();
    },
    onShow() { this.refresh(); },
    refresh() {
      try {
        const { month, kind } = this.data;
        const monthLabel = month.slice(0, 4) + '年' + Number(month.slice(5, 7)) + '月';
        if (this.recordKey) {
          const record = cashRecords.read(store, this.recordKey, month);
          if (record.source === 'manual') this.entrySnapshot = JSON.stringify(manual.read(record.id));
          const member = record.source === 'package' && record.memberId === this.recordMemberId &&
            store.byId('members', record.memberId);
          this.setData({ record, member: member || null, monthLabel, error: '', entryChanged: false,
            readTitle: record.source === 'package' ? '售课记录' : '记账详情',
            summaryValue: view.yuan(record.displayAmount), summaryLabel: record.source === 'package' ? '售课记录金额' :
              record.type === 'expense' ? '手工记账支出' : '手工记账收入' });
          return;
        }
        const member = this.memberId ? store.byId('members', this.memberId) : null;
        if (this.memberId && !member) throw Error('会员资料已不可用');
        const detail = details.load(store, kind, month, this.memberId);
        const cash = detail.cashOnly;
        const tabs = cash ? cashTabs : lessonTabs;
        const summaryValue = cash ? view.yuan(detail.totalText) : kind === 'income' ? view.yuan(detail.amountText) :
          kind === 'learners' ? detail.memberCount + ' 位' : detail.courseCount + ' 节';
        const summaryLabel = cash ? ({ cashBalance: '本月收支净额', sales: '售课记录金额', cashIncome: '手工记账收入',
          cashExpense: '本月支出' })[kind] : ({ completed: '完成课次', learners: '上课会员', income: '确认课时收入' })[kind];
        const summaryNote = cash ? (detail.historicalNegativeText ?
          '含历史负售课 ' + detail.historicalNegativeText + '，首页仅汇总正售课金额' :
          detail.includesSales ? '售课按课包登记金额，未核实收款' : '') : kind === 'income' ?
          '按关联课包单价折算，优先按完成日期归月' : '按课程日期归月，统计完成与扣课分别判断';
        this.setData({ detail, member, tabs, monthLabel, summaryValue, summaryLabel, summaryNote, error: '',
          readTitle: cash ? '收支明细' : member ? '会员月度课时' : '月度课时明细',
          emptyTitle: cash ? detail.hasMonthRecords ? '没有符合条件的记录' : '这个月份暂无收支' : '这个月份暂无记录' },
          () => this.restoreCashAnchor());
      } catch (error) {
        this.setData({ detail: null, record: null, error: error.message });
      }
    },
    pickMonth(e) {
      this.setData({ month: e.detail.value });
      this.refresh();
    },
    pickKind(e) {
      const kind = e.currentTarget.dataset.kind;
      if (!allTabs.some(tab => tab.key === kind) || !this.data.tabs.some(tab => tab.key === kind)) return;
      this.setData({ kind });
      this.refresh();
    },
    clearCashFilter() { this.pickKind({ currentTarget: { dataset: { kind: 'cashBalance' } } }); },
    openRecord(e) {
      const rows = this.data.detail.records;
      const row = rows.find(r => r.key === e.currentTarget.dataset.key);
      if (!row) return;
      this.cashAnchor = null;
      const open = () => feedback.navigateTo({ url: '/pages/statistics-detail/index?kind=' + this.data.kind +
        '&month=' + this.data.month + '&record=' + encodeURIComponent(row.key) +
        (row.memberId ? '&memberId=' + encodeURIComponent(row.memberId) : '') });
      if (row.source === 'manual' && typeof wx.createSelectorQuery === 'function') {
        const index = rows.indexOf(row);
        const neighbor = rows[index + 1] || rows[index - 1];
        if (neighbor) {
          this.measureCashRow(neighbor.key, rect => {
            if (rect) this.cashAnchor = { key: row.key, neighbor: neighbor.key, top: rect.top };
            open();
          });
          return;
        }
      }
      open();
    },
    measureCashRow(key, callback) {
      wx.createSelectorQuery().selectAll('.finance-row').boundingClientRect(rows =>
        callback((rows || []).find(row => row.id === 'record-' + key))).exec();
    },
    restoreCashAnchor() {
      const anchor = this.cashAnchor;
      this.cashAnchor = null;
      const rows = this.data.detail && this.data.detail.records;
      if (!anchor || !rows || rows.some(row => row.key === anchor.key)) return;
      this.measureCashRow(anchor.neighbor, rect => {
        if (!rect || Math.abs(rect.top - anchor.top) < 1) return;
        wx.createSelectorQuery().selectViewport().scrollOffset(scroll => {
          if (scroll) wx.pageScrollTo({ scrollTop: Math.max(0, scroll.scrollTop + rect.top - anchor.top), duration: 0 });
        }).exec();
      });
    },
    editManualEntry() {
      const record = this.data.record;
      if (!record || record.source !== 'manual' || this.data.entryChanged) return;
      feedback.navigateTo({ url: '/pages/finance-entry/index?id=' + encodeURIComponent(record.id) + '&month=' + this.data.month });
    },
    openFinanceDelete() {
      const record = this.data.record;
      if (!record || record.source !== 'manual' || this.data.entryChanged) return;
      this.setData({ financeDelete: { id: record.id, summary: record.date + ' / ' + record.title + ' / ' + view.yuan(record.displayAmount),
        impact: Number(record.date.slice(5, 7)) + ' 月' + (record.type === 'expense' ? '支出' : '收入') + '和收支净额将更新。' },
        deleteError: null });
    },
    closeFinanceDelete() {
      if (!this.data.deleting) this.setData({ financeDelete: null, deleteError: null });
    },
    leaveFinanceDetail() {
      if (this.data.financeDelete) this.closeFinanceDelete();
      else this.requestPageLeave();
    },
    confirmFinanceDelete() {
      const target = this.data.financeDelete;
      if (!target || this.data.deleting || this.data.entryChanged || this._financeDeleted) return;
      this.setData({ deleting: true, deleteError: null });
      const result = service.execute(() => manual.remove(target.id, this.entrySnapshot));
      if (!result.ok) {
        this.setData({ deleting: false, deleteError: result.error, entryChanged: result.error.code === 'CONFLICT' });
        return;
      }
      this._financeDeleted = true;
      this.setData({ deleting: false, financeDelete: null, record: null, error: '记录已删除' }, () => {
        // Give the native page-container time to leave before popping the page.
        setTimeout(() => {
          this.requestPageLeave();
          feedback.showToast({ title: '记录已删除', icon: 'none' });
        }, 320);
      });
    },
    openCourse(e) {
      const id = e.currentTarget.dataset.id;
      const row = this.data.detail && this.data.detail.courses.find(c => c.id === id);
      const course = row && store.byId('courses', id);
      if (!course || course.archived || course.memberId !== row.memberId) {
        wx.showToast({ title: '课程已不可用，请刷新明细', icon: 'none' });
        return;
      }
      feedback.navigateTo({ url: '/pages/course-detail/index?id=' + encodeURIComponent(id) });
    },
    openMemberCourses(e) {
      const id = e.currentTarget.dataset.id;
      if (!this.data.detail || !this.data.detail.members.some(row => row.id === id) || !store.byId('members', id)) {
        wx.showToast({ title: '会员资料已不可用', icon: 'none' });
        return;
      }
      feedback.navigateTo({ url: '/pages/statistics-detail/index?kind=completed&month=' + this.data.month +
        '&memberId=' + encodeURIComponent(id) });
    },
    openMember() {
      if (!this.recordKey) return view.openMember(store, this.memberId);
      const pack = this.data.record && store.byId('packages', this.data.record.id);
      if (!pack || pack.memberId !== this.recordMemberId) {
        wx.showToast({ title: '关联会员已不可用', icon: 'none' });
        return;
      }
      view.openMember(store, this.recordMemberId);
    },
    openPackage() {
      if (this.data.record && this.data.record.source === 'package') {
        view.openPackage(store, this.data.record.id, this.recordMemberId);
      }
    }
  }))));
