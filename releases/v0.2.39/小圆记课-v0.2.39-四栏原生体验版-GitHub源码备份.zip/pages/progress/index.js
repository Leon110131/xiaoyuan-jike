const store = require('../../utils/store');
const validate = require('../../utils/validation');
const service = require('../../utils/local-service');
const feedback = require('../../utils/page-feedback');

const fields = [
  { key: 'height', label: '身高', unit: 'cm' },
  { key: 'weight', label: '体重', unit: 'kg' },
  { key: 'bodyFat', label: '体脂率', unit: '%' },
  { key: 'muscle', label: '骨骼肌', unit: 'kg' },
  { key: 'waist', label: '腰围', unit: 'cm' },
  { key: 'chest', label: '胸围', unit: 'cm' },
  { key: 'hip', label: '臀围', unit: 'cm' },
  { key: 'arm', label: '臂围', unit: 'cm' },
  { key: 'thigh', label: '腿围', unit: 'cm' }
];
const metrics = fields.slice(1, 5);
const profileFields = ['height', 'weight', 'bodyFat', 'muscle'];
const titles = { trend: '体测', form: '录入体测', history: '体测历史', detail: '体测详情' };
const hasValue = value => value != null && String(value).trim() !== '';
const storedNumber = value => hasValue(value) && typeof value !== 'boolean' && Number.isFinite(Number(value));
const trendValue = value => storedNumber(value) && Number(value) > 0 ? Number(value) : null;
const unitText = unit => unit === '%' ? unit : ' ' + unit;

function formFor(latest) {
  const form = { date: store.formatDate(new Date()), notes: '' };
  fields.forEach(({ key }) => { form[key] = latest && latest[key] ? String(latest[key]) : ''; });
  return form;
}

function metricText(value, unit) {
  return value === null ? '—' : value.toFixed(1) + unitText(unit);
}

function chartFor(rows, metric) {
  const recent = rows.slice(0, 6).reverse();
  const values = recent.map(row => trendValue(row[metric.key]));
  const valid = values.filter(value => value !== null);
  const low = Math.min(...valid);
  const high = Math.max(...valid);
  const points = recent.map((row, index) => {
    const value = values[index];
    return {
      id: row.id, x: (index + 0.5) * 100 / recent.length,
      y: value === null || low === high ? 52 : 21 + (high - value) / (high - low) * 63,
      value: value === null ? '' : value.toFixed(1),
      date: row.date.slice(5).replace('-', '.'),
      summary: row.date + ' ' + (value === null ? '缺测' : metricText(value, metric.unit))
    };
  });
  const segments = points.slice(1).reduce((lines, end, index) => {
    const start = points[index];
    if (start.value && end.value) {
      const a = start.y + '%', b = end.y + '%';
      const shape = 'polygon(0 ' + a + ', 100% ' + b + ', 100% calc(' + b + ' + 2px), 0 calc(' + a + ' + 2px))';
      lines.push({ id: end.id, left: start.x, width: end.x - start.x, shape });
    }
    return lines;
  }, []);
  const latest = values[values.length - 1];
  const prior = values[values.length - 2];
  const change = latest != null && prior != null ? Number((latest - prior).toFixed(1)) : null;
  return {
    points, segments, latest: latest == null ? '' : latest.toFixed(1),
    change: change === null ? '' : (change > 0 ? '+' : '') + change.toFixed(1) +
      (metric.key === 'bodyFat' ? ' 个百分点' : unitText(metric.unit)),
    hasValues: valid.length > 0,
    description: points.map(point => point.summary).join('，')
  };
}

const config = {
  data: {
    screen: 'trend', title: titles.trend, member: null, memberId: '', avatar: '',
    fields, metrics, metric: 'weight', activeMetric: metrics[0],
    measurements: [], history: [], chart: { points: [] }, detail: null, progressDetailOpen: false,
    form: {}, fieldErrors: {}, formError: '', saveError: '', saving: false, saved: false
  },
  onLoad(query = {}) {
    this.memberId = query.memberId || '';
    this.recordId = query.recordId || '';
    const screen = Object.keys(titles).includes(query.screen) ? query.screen : 'trend';
    const metric = metrics.find(item => item.key === query.metric) || metrics[0];
    this.setData({ screen, title: titles[screen], memberId: this.memberId, metric: metric.key, activeMetric: metric });
  },
  onShow() { this.refresh(); },
  refresh() {
    const member = store.byId('members', this.memberId);
    const rows = member ? store.list('measurements').filter(row => row.memberId === this.memberId)
      .sort((a, b) => b.date.localeCompare(a.date)) : [];
    this.setData({ member, avatar: Array.from((member && member.name) || '?')[0], measurements: rows });
    const { screen, activeMetric } = this.data;
    if (screen === 'trend') this.setData({ chart: chartFor(rows, activeMetric) });
    if (screen === 'history') {
      this.setData({ history: rows.map(row => ({ id: row.id, date: row.date,
        value: metricText(trendValue(row[activeMetric.key]), activeMetric.unit) })) });
    }
    if (screen === 'detail') {
      const record = rows.find(row => row.id === this.recordId);
      this.setData({ detail: record ? this.describeRecord(record) : null });
    }
    if (screen === 'form' && !this._formInitialized) {
      this._formInitialized = true;
      this.setData({ form: formFor(rows[0]) });
    }
  },
  describeRecord(record) {
    const [year, month, day] = record.date.split('-');
    return {
      date: year + ' 年 ' + Number(month) + ' 月 ' + Number(day) + ' 日',
      fields: fields.map(({ key, label, unit }) => {
        const raw = record[key];
        const hasStoredValue = storedNumber(raw);
        return { key, label, value: hasStoredValue ? String(raw) + unitText(unit) : '—',
          storedZero: hasStoredValue && Number(raw) === 0 };
      }),
      notes: record.notes || ''
    };
  },
  chooseMetric(event) {
    const metric = metrics.find(item => item.key === event.currentTarget.dataset.metric);
    if (!metric) return;
    this.setData({ metric: metric.key, activeMetric: metric, chart: chartFor(this.data.measurements, metric) });
  },
  openScreen(screen) {
    const { member, memberId, metric } = this.data;
    if (!member) return;
    const url = '/pages/progress/index?memberId=' + encodeURIComponent(memberId) + '&screen=' + screen + '&metric=' + metric;
    feedback.navigateTo({ url });
  },
  openForm() { this.openScreen('form'); },
  openHistory() { this.openScreen('history'); },
  openDetail(event) {
    const id = event.currentTarget.dataset.id;
    if (this.data.progressDetailOpen || !this.data.history.some(row => row.id === id)) return;
    const record = store.list('measurements').find(row => row.id === id && row.memberId === this.memberId);
    this.setData({ detail: record ? this.describeRecord(record) : null, progressDetailOpen: true });
  },
  closeProgressDetail() {
    this.setData({ progressDetailOpen: false, detail: null });
  },
  backProgress() {
    if (this.data.saving) return;
    if (this.data.progressDetailOpen) return this.closeProgressDetail();
    this.finishKeyboardEditing();
    this.requestPageLeave();
  },
  goReport() {
    if (this.data.member) feedback.navigateTo({ url: '/pages/report/index?memberId=' + encodeURIComponent(this.memberId) });
  },
  onInput(event) {
    const key = event.currentTarget.dataset.key;
    if (key !== 'notes' && !fields.some(field => field.key === key)) return;
    this.setData({ form: { ...this.data.form, [key]: event.detail.value },
      fieldErrors: { ...this.data.fieldErrors, [key]: '' }, formError: '', saveError: '' });
  },
  onDate(event) {
    this.setData({ form: { ...this.data.form, date: event.detail.value },
      fieldErrors: { ...this.data.fieldErrors, date: '' }, saveError: '' });
  },
  save() {
    const { form, saving, saved, featureLocked } = this.data;
    if (this.data.screen !== 'form' || saving || saved || featureLocked) return false;
    this.finishKeyboardEditing();
    const fieldErrors = {};
    const values = {};
    try { validate.date(form.date, '体测日期'); } catch (error) { fieldErrors.date = error.message; }
    fields.forEach(({ key, label }) => {
      if (!hasValue(form[key])) return;
      try {
        const value = validate.number(form[key], 0, label);
        if (key === 'bodyFat') validate.assert(value <= 100, '体脂率不能超过 100%。');
        values[key] = value;
      } catch (error) { fieldErrors[key] = error.message; }
    });
    const formError = metrics.some(({ key }) => hasValue(form[key])) ? '' : '体重、体脂率、骨骼肌、腰围至少填一项。';
    this.setData({ fieldErrors, formError, saveError: '' });
    if (Object.keys(fieldErrors).length || formError) return false;

    this.setData({ saving: true });
    const outcome = service.execute(() => {
      store.assertCoachWrite('measurements');
      const member = store.byId('members', this.memberId);
      validate.assert(member, '会员不存在。');
      const record = { memberId: member.id, date: form.date, notes: form.notes || '' };
      fields.forEach(({ key }) => { record[key] = values[key] || 0; });
      if (!hasValue(form.height)) record.height = member.height || 0;
      const savedRecord = store.saveMeasurement(record);
      const profile = {};
      profileFields.forEach(key => {
        if (hasValue(form[key])) profile[key] = values[key];
      });
      if (Object.keys(profile).length) {
        profile.updatedAt = store.formatDate(new Date());
        store.patch('members', member.id, profile);
      }
      return savedRecord;
    });
    if (!outcome.ok) {
      this.setData({ saving: false, saveError: outcome.error.message });
      return false;
    }
    this.setData({ saving: false, saved: true });
    feedback.showToast({ title: '体测已保存', icon: 'success' });
    this.backProgress();
    return true;
  }
};

Page(require('../../utils/theme-page')(require('../../utils/back-navigation')('pages/progress/index',
  require('../../utils/feature-page')('measurements', config))));
