const withTab = require('../../utils/tab-page');
const feedback = require('../../utils/page-feedback');

Page(withTab(2, {
  data: {
    resources: [
      { title: '通用训练计划', icon: 'plan', path: '/pages/training/index?tab=plans' },
      { title: '动作库', icon: 'dumbbell', path: '/pages/exercise-library/index' },
      { title: '全部训练记录', icon: 'history', path: '/pages/training/index?tab=logs' }
    ],
    quickTools: [
      { title: 'BMI', subtitle: '体重指数', path: '/pages/bmi/index' },
      { title: '快速 TDEE', subtitle: '每日能量消耗估算', path: '/pages/nutrition-calculator/index?kind=tdee&tool=1' }
    ],
    healthTools: [
      { title: 'TDEE 营养规划', path: '/pages/tdee-plan/index' },
      { title: '碳循环计算', path: '/pages/nutrition-calculator/index?kind=cycle&tool=1' },
      { title: '渐降计算', path: '/pages/nutrition-calculator/index?kind=taper&tool=1' }
    ]
  },
  openTool(event) { feedback.navigateTo({ url: event.currentTarget.dataset.path }); }
}));
