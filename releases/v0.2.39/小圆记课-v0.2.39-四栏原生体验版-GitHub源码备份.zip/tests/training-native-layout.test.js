const assert = require('node:assert/strict');
const { test } = require('node:test');
const environment = require('./business-harness');

const tap = dataset => ({currentTarget:{dataset}});
const input = value => ({detail:{value}});

test('计划详情独立入栈，返回时按系列读取保存后的版本', () => {
  const e = environment();
  const list = e.page('training');
  list.viewPlan(tap({id:'pl_1'}));
  const link = e.events.find(item => item.key === 'navigateTo').options.url;
  assert.equal(link,'/pages/training/index?planId=pl_1');
  const detail = e.page('training',{planId:'pl_1'});
  assert.equal(detail.data.detailPage,true);
  assert.equal(detail.data.planDetailOpen,false);
  const plans = e.load('utils/plan-templates');
  const before = plans.read('pl_1');
  const next = plans.save({name:before.name},before.days,before.id,JSON.stringify(before));
  detail.onShow();
  assert.equal(detail.data.planDetail.id,next.id);
  assert.equal(detail.data.planDetail.version,Number(before.version)+1);
});

test('动作详情与编辑各有页面上下文，原动作写入继续按稳定 ID', () => {
  const e = environment();
  const detail = e.page('exercise-library',{exerciseId:'e_1'});
  assert.equal(detail.data.exercisePage,'detail');
  detail.viewExerciseForm(tap({id:'e_1'}));
  const link = e.events.find(item => item.key === 'navigateTo').options.url;
  assert.equal(link,'/pages/exercise-library/index?form=1&exerciseId=e_1');
  const form = e.page('exercise-library',{form:'1',exerciseId:'e_1'});
  assert.equal(form.data.exercisePage,'form');
  const before = e.s.byId('exercises','e_1');
  form.onInput({...tap({key:'rest'}),...input('90')});
  form.save();
  const saved = e.s.byId('exercises','e_1');
  assert.equal(saved.name,before.name);
  assert.equal(saved.rest,90);
  assert.equal(saved.intensity,before.intensity);
});

test('历史按结束日期归组，跨日显示完整时段且筛选仍按结束日', () => {
  const archive = environment().load('utils/training-archive');
  const crosses = archive.decorate({id:'cross',date:'2035-03-10',time:'23:45',duration:45,sets:[{exerciseOrder:0},{exerciseOrder:1}]},'会员');
  const same = archive.decorate({id:'same',date:'2035-03-11',time:'14:00',duration:60,sets:[]},'会员');
  const groups = archive.days([crosses,same].sort(archive.sort));
  assert.equal(groups.length,1);
  assert.equal(groups[0].date,'2035-03-11');
  assert.equal(groups[0].rows.find(x=>x.id==='cross').period,'2035-03-10 23:45–2035-03-11 00:30');
  assert.equal(groups[0].rows.find(x=>x.id==='cross').exerciseCount,2);
});

test('逐组状态使用原记录函数，独立提交成功停留结果页待主动返回', () => {
  const e = environment();
  const page = e.page('workout',{memberId:'m_1001',fresh:'1'});
  page.chooseExercise(tap({id:'e_1'}));
  page.updateSet({...tap({ei:0,si:0,key:'rest'}),...input('0')});
  const id=page.data.exercises[0].sets[0].id;
  page.focusWorkoutField(tap({id,key:'weight'}));
  assert.equal(page.data.focusedSetId,id);
  page.toggleWorkoutCheck(tap({ei:0,si:0}));
  assert.equal(page.data.exercises[0].sets[0].done,true);
  const courses=e.s.list('courses').length;
  page.presentTrainingSubmit();
  page.saveRecordOnly();
  assert.equal(page.data.trainingResult.title,'训练记录已保存');
  assert.equal(e.s.byId('workouts',page.data.workoutId).courseId,'');
  assert.equal(e.s.list('courses').length,courses);
  assert.equal(e.events.some(item=>item.key==='navigateBack'),false);
  page.requestPageLeave();
  assert.equal(e.events.some(item=>item.key==='navigateBack'),true);
});
