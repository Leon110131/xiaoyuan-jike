const { test } = require('node:test');
const assert = require('node:assert/strict');
const environment = require('./business-harness');
const input = value => ({ detail: { value } });
const option = type => ({ currentTarget: { dataset: { type } } });
const value = (e, key) => JSON.stringify(e.s.list(key));
const last = (e, key) => e.events.filter(row => row.key === key).at(-1).options;
const protectedKeys = ['courses', 'packages', 'ledger', 'reports'];

function existing(e) {
  const original = { id: 'receipt-1', type: 'income', date: '2026-11-10', amount: 220,
    category: '营养咨询', notes: '原备注', createdAt: '2026-11-12T02:00:00.000Z', sourceRef: { origin: '原字段' } };
  e.s.set('financialEntries', [original, { ...original, id: 'other' }]);
  return original;
}

test('新增默认值、输入中间态、金额边界、原日期归月与防重复保存', () => {
  const e = environment(), page = e.page('finance-entry', { type: 'income', month: '2026-11' });
  assert.equal(page.data.date, e.s.formatDate(new Date()));
  assert.equal(page.data.amount, '');
  assert.equal(page.data.category, '其他收入');
  page.onCategory(input('0'));
  assert.equal(page.data.category, '课时费用');
  page.chooseType(option('expense'));
  assert.equal(page.data.category, '场地费用');
  page.chooseType(option('income'));
  assert.equal(page.data.category, '其他收入');
  page.onAmount(input('12.'));
  assert.equal(page.data.amount, '12.');
  page.onDate(input('2026-10-10'));
  for (const invalid of ['', '0', '0.009', '12.345', '12.340', '100000000.01']) {
    page.onAmount(input(invalid));
    page.save();
    assert(page.data.fieldErrors.amount);
  }
  page.onAmount(input('0.01'));
  page.onDate(input('2026-11-31'));
  page.onCategory(input('99'));
  page.save();
  assert(page.data.fieldErrors.date);
  assert(page.data.fieldErrors.category);
  page.onDate(input('2026-10-10'));
  page.onCategory(input('1'));
  const before = e.s.list('financialEntries').length;
  page.save();
  page.save();
  assert.equal(e.s.list('financialEntries').length, before + 1);
  assert.equal(e.s.list('financialEntries')[0].amount, 0.01);
  assert.equal(page.data.receipt, '已记入 2026 年 10 月');
  assert.equal(last(e, 'navigateBack').delta, 1);
  const expense = e.page('finance-entry', { type: 'expense' });
  assert.equal(expense.data.category, '场地费用');
  expense.onAmount(input('100000000.00'));
  expense.save();
  assert.equal(e.s.list('financialEntries')[0].amount, 100000000);
  assert.equal(e.s.list('financialEntries')[0].type, 'expense');
});

test('编辑保持原 ID、创建时间和其他字段，写入失败保留输入，冲突无法覆盖', () => {
  const e = environment(), original = existing(e);
  const before = protectedKeys.map(key => value(e, key));
  const p = e.page('finance-entry', { id: original.id, month: '2026-11' });
  p.onAmount(input('230.00'));
  p.onNotes(input('保留输入'));
  e.fail(true);
  p.save();
  assert.equal(p.data.operationError.code, 'STORAGE_QUOTA');
  assert.equal(p.data.notes, '保留输入');
  assert.equal(e.s.byId('financialEntries', original.id).amount, 220);
  e.fail(false);
  p.save();
  assert.equal(e.s.byId('financialEntries', original.id).createdAt, original.createdAt);
  assert.equal(value(e, 'financialEntries').includes('原字段'), true);
  assert.equal(e.s.byId('financialEntries', original.id).amount, 230);
  const cross = e.page('finance-entry', { id: original.id, month: '2026-11' });
  cross.onDate(input('2026-10-15'));
  cross.save();
  assert.equal(cross.data.receipt, '已移至 2026 年 10 月');
  assert.equal(cross.returnToList, true);
  assert.equal(e.s.list('financialEntries').length, 2);
  assert.equal(e.s.byId('financialEntries', original.id).date, '2026-10-15');
  const stale = e.page('finance-entry', { id: original.id, month: '2026-10' });
  e.s.saveFinancialEntry({ ...original, amount: 250, date: '2026-10-15' });
  stale.save();
  assert.equal(stale.data.operationError.code, 'CONFLICT');
  assert.equal(stale.data.cannotEdit, true);
  assert.equal(e.s.byId('financialEntries', original.id).amount, 250);
  assert.deepEqual(protectedKeys.map(key => value(e, key)), before);
});

test('单条精准删除支持取消、写入失败重试和记录变化校验', () => {
  const e = environment(), original = existing(e);
  const p = e.page('statistics-detail', { record: 'entry_' + original.id, month: '2026-11', kind: 'cashIncome' });
  p.editManualEntry();
  assert.match(last(e, 'navigateTo').url, /finance-entry\/index\?id=receipt-1&month=2026-11$/);
  p.openFinanceDelete();
  assert.match(p.data.financeDelete.summary, /2026-11-10.*营养咨询.*220/);
  p.closeFinanceDelete();
  assert.equal(e.s.list('financialEntries').length, 2);
  p.openFinanceDelete();
  e.fail(true);
  p.confirmFinanceDelete();
  assert.equal(p.data.deleteError.code, 'STORAGE_QUOTA');
  assert.equal(e.s.list('financialEntries').length, 2);
  e.fail(false);
  p.confirmFinanceDelete();
  p.confirmFinanceDelete();
  assert.deepEqual(Array.from(e.s.list('financialEntries'), x => x.id), ['other']);
  e.timers.at(-1).fn();
  assert.equal(last(e, 'navigateBack').delta, 1);
  const q = e.page('statistics-detail', { record: 'entry_other', month: '2026-11', kind: 'cashIncome' });
  q.openFinanceDelete();
  e.s.saveFinancialEntry({ ...e.s.byId('financialEntries', 'other'), amount: 999 });
  q.confirmFinanceDelete();
  assert.equal(q.data.deleteError.code, 'CONFLICT');
  assert.equal(e.s.byId('financialEntries', 'other').amount, 999);
});
