const test = require('node:test');
const assert = require('node:assert/strict');
const environment = require('./business-harness');
const event = (key, value) => ({currentTarget:{dataset:{[key]:value}}});
const month = value => event('month',value);
const bars = p => Array.from(p.data.historyBars, row => row.month);
const months = ['2025-08','2025-09','2025-10','2025-11','2025-12','2026-01'];

test('独立选月及两种回源行为分别保留经营视图', () => {
  for (const mode of ['cash','accrual']) {
    const e = environment(), p = e.page('statistics');
    const original = JSON.stringify(e.storage);
    p.selectMonth(month('2026-11'));
    p.chooseFinanceMode(event('mode',mode));
    const liability = p.data.liability;
    p.openHistory();
    assert.equal(p.data.historyMonth,'2026-11');
    p.selectHistory(event('key','expenses'));
    p.openMonthPicker();
    p.applyMonthPicker(month('2026-10'));
    assert.equal(p.data.month,'2026-11');
    assert.equal(p.data.historyMonth,'2026-10');
    assert.equal(p.data.historyTab,'expenses');
    assert.equal(p.data.historyBars[0].month,'2026-05');
    p.onShow();
    assert.equal(p.data.historyBars.at(-1).month,'2026-10');
    p.openEntries();
    assert.equal(e.events.at(-1).options.url,'/pages/statistics-detail/index?kind=cashBalance&month=2026-10');
    p.closeHistory();
    assert.equal(p.data.month,'2026-11');
    assert.equal(p.data.financeMode,mode);
    p.openHistory();
    assert.equal(p.data.historyMonth,'2026-11');
    p.openHistoryMonth(month('2026-01'));
    assert.equal(p.data.showHistory,true);
    p.openHistoryMonth(month('2026-10'));
    assert.equal(p.data.showHistory,false);
    assert.equal(p.data.month,'2026-10');
    assert.equal(p.data.financeMode,mode);
    assert.equal(p.data.liability,liability);
    assert.equal(JSON.stringify(e.storage),original);
  }
});

test('返回先取消选月再退出趋势，跨年范围连续，保留五项原口径', () => {
  const e = environment(), s = e.s;
  s.set('packages', [
    {id:'neg',memberId:'m_1001',saleAmount:-150,saleDate:'2025-12-01',total:3,remaining:0,status:'closed'},
    {id:'positive',memberId:'m_1001',saleAmount:900,saleDate:'2026-01-07',total:6,remaining:4,status:'active'}
  ]);
  s.set('courses', [{id:'c',date:'2025-12-30',time:'08:00',duration:60,status:'completed',completedAt:'2026-01-01',packageId:'positive'}]);
  s.set('ledger',[]);
  s.set('financialEntries', [
    {date:'2026-01-01',amount:20,type:'income',category:'其他收入'},
    {date:'2026-01-01',amount:999,type:'income',category:'课时费用'},
    {date:'2026-01-01',amount:70,type:'expense'}
  ]);
  const p = e.page('statistics');
  p.selectMonth(month('2026-11'));
  p.openHistory();
  p.applyMonthPicker(month('2026-01'));
  assert.deepEqual(bars(p),months);
  assert.equal(p.data.historyBars[0].value,'0.00');
  assert.equal(p.data.historyBars[4].value,'-150.00');
  const values = {sales:'900.00',lessonFee:'150.00',completed:'0',expenses:'70.00',income:'170.00'};
  for (const [key,value] of Object.entries(values)) {
    p.selectHistory(event('key',key));
    assert.equal(p.data.historyBars.at(-1).value,value,key);
  }
  p.openMonthPicker();
  p.pickMonthYear({detail:{value:'2025-01-01'}});
  p.onBackLayerLeave();
  p.onBackLayerAfterLeave();
  assert.equal(p.data.showStatsMonth,false);
  assert.equal(p.data.showHistory,true);
  assert.equal(p.data.historyMonth,'2026-01');
  assert.deepEqual(bars(p),months);
  p.onBackLayerLeave();
  p.onBackLayerAfterLeave();
  assert.equal(p.data.showHistory,false);
  assert.equal(p.data.month,'2026-11');
  assert.equal(p.data.liability,600);
});
