const assert = require('node:assert/strict');
const { test } = require('node:test');
const environment = require('./business-harness');

const memberId = 'm_1001';
const event = dataset => ({ currentTarget: { dataset } });
const input = value => ({ detail: { value } });
const dataCopy = value => JSON.parse(JSON.stringify(value));
const collections = (e, keys) => dataCopy(keys.map(key => e.s.list(key)));
const financial = ['packages', 'ledger'];
const business = ['courses', ...financial, 'workouts'];

function lastRoute(e, pageName) {
  const route = e.events.filter(row => row.key === 'navigateTo').at(-1);
  assert(route, '应发生页面跳转');
  const url = new URL(route.options.url, 'https://simulated.local');
  assert.equal(url.pathname, '/pages/' + pageName + '/index');
  if (route.options.success) route.options.success({});
  // WeChat passes the raw percent-encoded draftId into onLoad.
  const query = Object.fromEntries(url.searchParams);
  const rawDraft = url.search.match(/[?&]draftId=([^&]*)/);
  if (rawDraft) query.draftId = rawDraft[1];
  return query;
}

function record(page, note) {
  page.chooseExercise(event({ id: 'e_1' }));
  page.updateSet({ ...event({ ei: 0, si: 0, key: 'weight' }), ...input('37.5') });
  page.updateSet({ ...event({ ei: 0, si: 0, key: 'reps' }), ...input('8') });
  page.onNotes(input(note));
}

function detailAction(page) {
  const { report, record, supplement, debit } = page.data.courseActions;
  return { report, record, supplement, debit, draft: page.data.detail.draft };
}

test('已扣课详情按精确关联补录、续录和查看报告，取消与重复提交不改课程财务', t => {
  const e = environment();
  const pack = e.s.addPackage({ memberId, name: 'P0 课包', total: 8,
    startDate: '2020-01-01', endDate: '2099-12-31', saleDate: '2020-01-01', saleAmount: 800 });
  const current = { id: 'p0_new_debit', memberId, date: '2035-03-10', time: '14:00',
    duration: 60, status: 'scheduled', deducted: false };
  e.s.upsert('courses', current);
  const detail = e.page('course-detail', { id: current.id });
  detail.openDebitChoices();
  detail.confirmReadDebit(event({ id: pack.id }));
  detail.acceptCourseConfirmation();
  detail.onShow();
  assert.deepEqual(detailAction(detail), { report: false, record: true, supplement: true, debit: false, draft: false });

  const debited = e.s.byId('courses', current.id);
  const before = collections(e, business);
  detail.openCourseTraining();
  const query = lastRoute(e, 'workout');
  assert.equal(query.courseId, current.id);
  assert.equal(query.fresh, '1');
  const first = e.page('workout', query);
  record(first, '补录后退出，再续录');
  first.presentTrainingSubmit();
  first.closeTrainingConfirmation();
  assert.deepEqual(collections(e, business), before);
  first.onHide();
  first.onUnload();

  detail.onShow();
  assert.equal(detailAction(detail).draft, true);
  detail.openCourseTraining();
  const resume = lastRoute(e, 'workout');
  const expectedDraftId = 'draft:' + first.data.workoutId;
  assert.equal(resume.draftId, encodeURIComponent(expectedDraftId));
  const resumed = e.page('workout', resume);
  assert.equal(resumed.data.workoutId, first.data.workoutId);
  assert.equal(resumed.data.notes, '补录后退出，再续录');
  resumed.presentTrainingSubmit();
  resumed.confirmUnbookedTraining();
  assert(resumed.data.trainingResult, JSON.stringify({ error: resumed.data.operationError,
    recentFeedback: e.events.slice(-3), confirmed: resumed.data.trainingSubmitConfirm }));
  const afterSave = collections(e, business);
  resumed.confirmUnbookedTraining();
  assert.deepEqual(collections(e, business), afterSave);
  const [courses, packages, ledger, workouts] = afterSave;
  const linked = courses.find(row => row.id === current.id);
  assert.equal(linked.memberId, debited.memberId);
  assert.equal(linked.packageId, debited.packageId);
  assert.equal(linked.deducted, true);
  assert.equal(courses.length, before[0].length);
  assert.deepEqual(packages, before[1]);
  assert.deepEqual(ledger, before[2]);
  assert.equal(workouts.length, before[3].length + 1);
  assert.equal(e.s.byId('workouts', resumed.data.workoutId).courseId, current.id);
  assert(!e.s.byId('workoutDrafts', expectedDraftId));
  resumed.requestPageLeave();
  assert.equal(e.events.at(-1).key, 'navigateBack');
  detail.onShow();
  assert.deepEqual(detailAction(detail), { report: true, record: false, supplement: true, debit: false, draft: false });
  detail.openCourseReport();
  assert.equal(lastRoute(e, 'session-report').courseId, current.id);

  const history = { ...dataCopy(debited), id: 'p0_historical_debit', workoutId: 'missing',
    date: '2025-01-02', time: '15:00', completedAt: '2025-01-02' };
  e.s.upsert('courses', history);
  const historic = e.page('course-detail', { id: history.id });
  assert.equal(historic.data.courseActions.record, true);
  assert.equal(historic.data.courseActions.report, false);
  historic.openCourseTraining();
  const oldDraftPage = e.page('workout', lastRoute(e, 'workout'));
  record(oldDraftPage, '历史补录');
  const oldDraft = e.s.byId('workoutDrafts', 'draft:' + oldDraftPage.data.workoutId);
  delete oldDraft.data.courseId;
  e.s.upsert('workoutDrafts', oldDraft);
  historic.onShow();
  assert.equal(historic.data.detail.draft, true);
  historic.openCourseTraining();
  const old = e.page('workout', lastRoute(e, 'workout'));
  assert.equal(old.data.courseId, history.id);
  assert.equal(old.data.workoutId, oldDraft.workoutId);
  const historicBalances = collections(e, financial);
  const conflict = { ...history, id: 'p0_historical_overlap' };
  e.s.upsert('courses', conflict);
  e.s.patch('courses', history.id, { time: '16:00' });
  old.presentTrainingSubmit();
  old.confirmUnbookedTraining();
  assert(!e.s.byId('workouts', old.data.workoutId), '外部改期后拒绝覆盖课程');
  assert.equal(e.s.byId('courses', history.id).time, '16:00');
  e.s.patch('courses', history.id, { time: history.time });
  old.closeTrainingConfirmation();
  old.presentTrainingSubmit();
  old.confirmUnbookedTraining();
  assert.equal(e.s.byId('workouts', old.data.workoutId).courseId, history.id);
  assert.deepEqual(collections(e, financial), historicBalances);
  e.s.patch('courses', history.id, { workoutId: '' });
  historic.onShow();
  assert.equal(historic.data.courseActions.report, true, '训练正向关联能恢复报告入口');
  e.s.patch('workouts', old.data.workoutId, { courseId: '' });
  e.s.patch('courses', history.id, { workoutId: old.data.workoutId });
  historic.onShow();
  assert.equal(historic.data.courseActions.report, true, '历史反向关联能恢复报告入口');
  e.s.patch('workouts', old.data.workoutId, { memberId: 'm_1002' });
  historic.onShow();
  assert.equal(historic.data.courseActions.report, false, '不能打开其他会员的记录');
  e.s.patch('courses', history.id, { status: 'no_show' });
  historic.onShow();
  assert.equal(historic.data.courseActions.record, false, '已扣课爽约不提供补录');
  for (const status of ['canceled', 'leave']) {
    e.s.patch('courses', history.id, { status });
    historic.onShow();
    assert.equal(historic.data.courseActions.record, false);
  }
  t.diagnostic(JSON.stringify({ courseId: linked.id, memberId: linked.memberId, packageId: linked.packageId,
    workoutId: resumed.data.workoutId, courseDelta: courses.length - before[0].length,
    balanceDelta: packages.find(row => row.id === pack.id).remaining - before[1].find(row => row.id === pack.id).remaining,
    ledgerDelta: ledger.length - before[2].length, workoutDelta: workouts.length - before[3].length,
    removedDraftId: expectedDraftId, historicCourseId: history.id }));
});

test('通用计划以精确草稿续接并确认替换，保护草稿计时、原记录和财务', t => {
  const e = environment();
  const plan = e.load('utils/plan-templates').save({ name: 'P0 双日计划' }, [
    { name: '训练日 A', exerciseNames: ['杠铃卧推'] },
    { name: '训练日 B', exerciseNames: ['高位下拉'] }
  ]);
  const page = e.page('training', { planId: plan.id });
  page.setPlanDay(event({ index: 1 }));
  const course = { id: 'p0_draft_booked', memberId, date: '2035-03-12', time: '11:00',
    duration: 60, status: 'scheduled', deducted: false };
  e.s.upsert('courses', course);
  function makeDraft(query, note) {
    const workout = e.page('workout', { memberId, fresh: '1', ...query });
    record(workout, note);
    return dataCopy(e.s.byId('workoutDrafts', 'draft:' + workout.data.workoutId));
  }
  const booked = makeDraft({ courseId: course.id }, '预约草稿');
  const expired = dataCopy(booked);
  expired.workoutId = expired.data.workoutId = 'expired';
  expired.id = 'draft:expired';
  expired.courseId = expired.data.courseId = '';
  expired.sourceCourseId = 'deleted_course';
  e.s.upsert('workoutDrafts', expired);
  const edited = dataCopy(expired);
  edited.workoutId = edited.data.workoutId = 'w_1';
  edited.id = 'draft:w_1';
  edited.sourceCourseId = '';
  edited.data.editingExisting = true;
  e.s.upsert('workoutDrafts', edited);
  const otherMember = makeDraft({ memberId: 'm_1002' }, '其他会员草稿');
  function launch() {
    page.goWorkoutForPlan(event({ id: plan.id }));
    page.selectLaunchMember(event({ id: memberId }));
    page.selectLaunchDay(event({ index: 1 }));
  }
  const before = collections(e, business);
  launch();
  const fresh = lastRoute(e, 'workout');
  assert.equal(fresh.fresh, '1');
  assert.equal(fresh.draftId, undefined);
  const empty = e.page('workout', fresh);
  assert.equal(empty.data.templateSnapshot.dayName, '训练日 B');

  const selected = makeDraft({}, '选中的草稿');
  const exercise = selected.data.exercises[0];
  const now = Date.now();
  selected.data.time = '10:15';
  selected.restState = { clock: { active: true, paused: true, remaining: 90, deadline: now + 90000 },
    tracker: { startedAt: now - 30000, segment: now, elapsedMs: 30000, paused: true, finished: false },
    ui: { timerSetId: exercise.sets[0].id, timerExerciseId: exercise.id, timerTitle: exercise.name, timerTarget: 120 } };
  e.s.upsert('workoutDrafts', selected);
  launch();
  const one = lastRoute(e, 'workout');
  assert.equal(one.draftId, encodeURIComponent(selected.id));
  const resumed = e.page('workout', one);
  assert.equal(resumed.data.planDraftLabel, 'P0 双日计划 · 训练日 B');
  assert.equal(resumed.data.workoutId, selected.workoutId);
  assert.equal(resumed.data.timerRunning, true);
  assert.equal(resumed.data.timerPaused, true);
  resumed.onBackLayerLeave();
  resumed.onBackLayerAfterLeave();
  assert.equal(resumed.data.planDraftOpen, false);
  assert.equal(resumed.data.timerRunning, true);
  assert.equal(resumed.data.exercises[0].sets[0].weight, '37.5');
  assert.deepEqual(dataCopy(e.s.byId('workoutDrafts', selected.id)), selected);

  const second = makeDraft({}, '另一份同会员草稿');
  launch();
  assert.equal(page.data.planLaunchStage, 'draft');
  assert.deepEqual(Array.from(page.data.planLaunchDrafts, row => row.id).sort(), [selected.id, second.id].sort());
  page.onBackLayerLeave();
  page.onBackLayerAfterLeave();
  assert.equal(page.data.planLaunchOpen, false);
  assert.equal(page.data.planDayIndex, 1);
  assert.equal(page.data.planDetail.id, plan.id);
  launch();
  page.selectLaunchDraft(event({ id: selected.id }));
  const chosen = lastRoute(e, 'workout');
  assert.equal(chosen.draftId, encodeURIComponent(selected.id));
  const replacement = e.page('workout', chosen);
  e.fail(true);
  replacement.replacePlanDraft();
  e.fail(false);
  assert.equal(replacement.data.timerRunning, true);
  assert.equal(replacement.data.planDraftOpen, true);
  assert.deepEqual(dataCopy(e.s.byId('workoutDrafts', selected.id)), selected);
  replacement.replacePlanDraft();
  replacement.replacePlanDraft();
  assert.equal(replacement.data.planDraftOpen, false);
  assert.equal(replacement.data.timerRunning, false);
  const stored = e.s.byId('workoutDrafts', selected.id);
  assert.equal(stored.workoutId, selected.workoutId);
  assert.equal(stored.data.memberId, memberId);
  assert.equal(stored.data.notes, selected.data.notes);
  assert.equal(stored.data.templateSnapshot.id, plan.id);
  assert.equal(stored.data.templateSnapshot.dayName, '训练日 B');
  assert.equal(stored.data.exercises[0].name, '高位下拉');
  assert.equal(stored.restState, null);
  for (const untouched of [second, booked, expired, edited, otherMember]) {
    assert.deepEqual(dataCopy(e.s.byId('workoutDrafts', untouched.id)), untouched);
  }
  assert.deepEqual(collections(e, business), before);

  launch();
  page.selectLaunchDraft(event({ id: second.id }));
  const stale = e.page('workout', lastRoute(e, 'workout'));
  e.s.patch('plans', plan.id, { status: 'archived' });
  stale.replacePlanDraft();
  assert.equal(stale.data.planDraftInvalid, true);
  assert.deepEqual(dataCopy(e.s.byId('workoutDrafts', second.id)), second);
  stale.closePlanDraftChoice();
  assert(e.events.some(row => row.key === 'navigateBack' || row.key === 'switchTab'));
  t.diagnostic(JSON.stringify({ memberId, planId: plan.id, day: stored.data.templateSnapshot.dayName,
    draftId: stored.id, workoutId: stored.workoutId, otherDraftIds: [second.id, booked.id, expired.id, edited.id, otherMember.id],
    restBefore: selected.restState.clock.paused, restAfter: stored.restState,
    courseDelta: 0, balanceDelta: 0, ledgerDelta: 0, formalWorkoutDelta: 0 }));
});

test('训练页精确接收原始草稿 ID，拒绝错误路由且不回退到新训练', () => {
  const e = environment();
  const source = e.page('workout', { memberId, fresh: '1' });
  record(source, '工作页草稿');
  const id = 'draft:' + source.data.workoutId;
  const direct = e.page('workout', { memberId, draftId: id });
  assert.equal(direct.data.workoutId, source.data.workoutId);
  const encoded = e.page('workout', { memberId, draftId: encodeURIComponent(id) });
  assert.equal(encoded.data.workoutId, source.data.workoutId);
  const local = e.load('utils/local-state');
  local.set('workoutDraftEpoch', 1);
  encoded.onShow();
  assert.equal(encoded.data.workoutId, source.data.workoutId);
  assert.equal(encoded.data.notes, '工作页草稿');

  const cases = [
    [{ draftId: 'draft%3A%ZZ', supplementCourse: '1' }, /课程详情核对/],
    [{ draftId: '%E0%A4%A', planDraft: '1' }, /返回计划重新选择/],
    [{ draftId: 'draft%3Aw_missing' }, /返回工作页/],
    [{ draftId: '' }, /返回工作页/],
    [{ draftId: encodeURIComponent(id), memberId: 'm_1002' }, /返回工作页/],
    [{ draftId: encodeURIComponent(id), courseId: 'wrong_course' }, /返回工作页/],
    [{ draftId: encodeURIComponent(encodeURIComponent(id)) }, /返回工作页/]
  ];
  for (const [query, message] of cases) {
    const before = dataCopy(e.storage);
    const writes = e.writes;
    const bad = e.page('workout', { memberId, ...query });
    assert.match(bad.data.editError, message);
    assert(!bad.data.workoutId);
    bad.onHide();
    bad.onUnload();
    assert.equal(e.writes, writes);
    assert.deepEqual(dataCopy(e.storage), before);
  }

  e.s.set('workoutDrafts', []);
  local.set('workoutDraftEpoch', 2);
  const before = dataCopy(e.storage);
  encoded.onShow();
  assert.match(encoded.data.editError, /返回工作页/);
  assert.deepEqual(dataCopy(e.storage), before);
  assert(e.page('workout', { memberId, fresh: '1' }).data.workoutId);
});
