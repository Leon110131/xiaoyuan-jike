const { test } = require('node:test');
const assert = require('node:assert/strict');
const env = require('./business-harness');
const selected = (key,value) => ({currentTarget:{dataset:{[key]:value}}});

test('周一与月初按本地日期，跨月周报保留负售课和启用课包口径', () => {
  const e = env(), r = e.load('utils/summary-reports');
  const now = new Date(2026, 10, 1, 12);
  assert.equal(JSON.stringify(r.rangeFor('week', now)), '{"start":"2026-10-26","end":"2026-11-01"}');
  assert.equal(r.rangeFor('month', now).start, '2026-11-01');
  e.s.set('packages', [
    {id:'p',status:'active',saleDate:'2026-10-30',saleAmount:500,remaining:3,endDate:'2026-10-01'},
    {id:'n',status:'closed',saleDate:'2026-11-01',saleAmount:-150,remaining:2},
    {id:'stop',status:'paused',saleDate:'2026-10-10',saleAmount:500,remaining:20},
    {id:'active',status:'active',saleDate:'2026-09-10',saleAmount:500,remaining:4}
  ]);
  e.s.set('financialEntries',[{date:'2026-10-30',type:'income',amount:80},{date:'2026-11-01',type:'expense',amount:20}]);
  const report = r.generate('week','business',now);
  assert.equal(report.metrics.sales,350);
  assert.match(report.text,/手工记账收入：¥80\.00/);
  assert.match(report.text,/本期收支净额：¥410\.00/);
  assert.match(report.text,/生成时启用课包剩余：7 节/);
  const month = r.generate('month','business',now);
  assert.match(month.text,/售课记录金额：−¥150\.00/);
  assert(r.presentation(report.text));
  assert.equal(r.presentation('存档\r\n 原文  '), null);
  for (const id of ['coach','member']) assert.equal(r.generate('week',id,now).templateId,id);
});

test('保存沿用生成结果，失败保留正文，重复提交只写一次，复制历史原文', () => {
  const e = env(), r = e.load('utils/summary-reports');
  const p = e.page('reports-center', {screen:'preview'});
  const snapshot = r.generate('month','business');
  p.showReport(snapshot);
  e.s.set('financialEntries',[{id:'new',date:snapshot.endDate,type:'income',amount:999}]);
  e.fail(true);
  p.save();
  assert.equal(p.data.report.text,snapshot.text);
  assert(!p.data.saved);
  e.fail(false);
  const writes = e.writes;
  p.save();
  p.save();
  assert.equal(e.writes,writes+1);
  assert(p.data.saved);
  assert.equal(e.s.byId('reports',snapshot.id).text,snapshot.text);
  const original = '历史快照\r\n  ¥07.00 \r\n';
  e.s.set('reports',[{id:'old',reportType:'summary',text:original}]);
  const old = e.page('reports-center',{screen:'detail',id:'old'});
  e.wx.setClipboardData = options => {
    assert.equal(options.data,original);
    options.fail();
  };
  old.copy();
  assert.match(old.data.issue,/复制失败/);
  e.wx.setClipboardData = options => {
    assert.equal(options.data,original);
    options.success();
  };
  old.copy();
  assert.equal(old.data.issue,'');
});

test('最近十份、删除取消与精准删除、失效及同 ID 变化重核对', () => {
  const e = env();
  const row = {id:'report-one',title:'同名',reportType:'summary',createdAt:'2026-11-10',text:'第一份'};
  const twin = {...row,id:'report-two',text:'第二份'};
  const member = {...row,id:'stage',reportType:'stage'};
  const more = Array.from({length:11},(_,i)=>({...row,id:'extra'+i,createdAt:'2026-10-'+String(i+1).padStart(2,'0')}));
  e.s.set('reports',[row,twin,member,...more]);
  const list = e.page('reports-center',{screen:'history'});
  assert.equal(list.data.history.length,10);
  assert.deepEqual(Array.from(list.data.history.slice(0,2),x=>x.id),[row.id,twin.id]);
  const p = e.page('reports-center',{screen:'detail',id:row.id});
  p.openReportDelete();
  p.closeReportDelete();
  assert(e.s.byId('reports',row.id));
  p.openReportDelete();
  e.s.upsert('reports',{...row,text:'同 ID 已更新'});
  p.confirmReportDelete();
  assert.match(p.data.issue,/已变化/);
  assert.equal(e.s.byId('reports',row.id).text,'同 ID 已更新');
  p.openReportDelete();
  p.confirmReportDelete();
  assert(!e.s.byId('reports',row.id));
  assert.equal(e.s.byId('reports',twin.id).text,twin.text);
  assert.equal(e.s.byId('reports',member.id).reportType,'stage');
  assert(e.page('reports-center',{screen:'detail',id:row.id}).data.missing);
  assert(e.page('reports-center',{screen:'detail',id:member.id}).data.missing);
  e.s.set('reports',[member]);
  list.onShow();
  assert.equal(list.data.history.length,0);
});

test('生成失败保留模板及周期，换选项后清空旧生成结果', () => {
  const e = env(), p = e.page('reports-center',{period:'month'});
  p.chooseTemplate(selected('id','business'));
  const r = e.load('utils/summary-reports'), generate = r.generate;
  r.generate = () => { throw Error('simulated failure'); };
  p.generate();
  assert.match(p.data.issue,/报告生成失败/);
  assert.equal(p.data.period,'month');
  assert.equal(p.data.selectedTemplate,'business');
  r.generate = generate;
  p.generate();
  assert.equal(p.generated.templateId,'business');
  e.events.at(-1).options.complete();
  p.choosePeriod(selected('period','week'));
  assert.equal(p.generated,null);
  p.chooseTemplate(selected('id','member'));
  p.generate();
  assert.equal(p.generated.templateId,'member');
  assert.equal(p.generated.period,'week');
});
