const assert=require('assert'),fs=require('fs'),path=require('path'),environment=require('./business-harness');let passed=0;const results=[];
function test(name,fn){try{fn();results.push({name,pass:true});passed++;}catch(e){results.push({name,pass:false,error:e.stack});console.error(name,e.stack);process.exitCode=1;}}
const clone=x=>JSON.parse(JSON.stringify(x));
function own(){const e=environment({},true);e.registration({name:'自录教练甲',brand:'自录工作室',phone:'13800138000'});e.s.set('members',[{id:'mine-a',name:'自行录入甲',status:'正常训练'},{id:'mine-b',name:'自行录入乙',status:'正常训练'}]);return e;}
function latest(e,key){return e.events.filter(x=>x.key===key).at(-1).options;}
function restore(e,p,text,confirm=true){p.openRestore();p.onRestoreInput({detail:{value:text}});assert.equal(p.restore(),true);return confirm?p.confirmRestore():p.cancelRestore();}
test('fresh production state has no fixture members',()=>{const e=environment({},true);assert.equal(e.s.list('members').length,0);assert.equal(e.s.list('workouts').length,0);});
test('snapshot reads own current records and coach profile',()=>{const e=own(),p=e.page('data-tools');p.createBackup();const b=JSON.parse(p.data.backupText);assert.deepEqual(b.members.map(m=>m.id),['mine-a','mine-b']);assert.equal(b.coachProfile.name,'自录教练甲');assert.equal(b.scope,'coach-experience');});
test('copy always regenerates after an earlier export',()=>{const e=own(),p=e.page('data-tools');p.createBackup();e.s.set('members',e.s.list('members').concat({id:'mine-c',name:'刚刚新增',status:'正常训练'}));p.copyBackup();assert.equal(JSON.parse(latest(e,'setClipboardData').data).members.length,3);assert.equal(p.data.exportCounts.members,3);});
test('clipboard readback and paste retain exact large backup',()=>{const e=own(),p=e.page('data-tools');let clipboard;e.wx.setClipboardData=o=>{clipboard=o.data;o.success();};e.wx.getClipboardData=o=>o.success({data:clipboard});e.s.set('members',e.s.list('members').map(m=>({...m,notes:'自录备注'.repeat(3000)})));const before=e.writes;p.copyBackup();assert(clipboard.length>30000);assert.equal(e.writes,before);assert.equal(p.data.copying,false);p.pasteBackup();assert.equal(p.data.restoreText,clipboard);});
test('clipboard mismatch never reports success',()=>{const e=own(),p=e.page('data-tools');e.wx.setClipboardData=o=>o.success();e.wx.getClipboardData=o=>o.success({data:'truncated'});p.copyBackup();assert.equal(p.data.feedback.title,'备份未完整复制');assert.equal(p.data.feedback.tone,'error');assert(p.data.backupText.length>100);});
test('clipboard setter failure preserves all records',()=>{const e=own(),p=e.page('data-tools'),before=JSON.stringify(e.storage);e.wx.setClipboardData=o=>o.fail();p.copyBackup();assert.equal(JSON.stringify(e.storage),before);assert.equal(p.data.copying,false);assert.equal(p.data.feedback.title,'备份未完整复制');});
test('validation is read only and accepts BOM with whitespace',()=>{const e=own(),before=e.writes;e.s.validateBackup('\ufeff '+JSON.stringify(e.s.snapshot())+'\n');assert.equal(e.writes,before);});
test('invalid text rejected before confirmation and writes',()=>{const e=own(),p=e.page('data-tools'),before=JSON.stringify(e.storage);p.onRestoreInput({detail:{value:'{broken'}});p.restore();assert.equal(p.data.feedback.title,'备份验证未通过');assert.equal(JSON.stringify(e.storage),before);});
test('foreign edition rejected',()=>{const e=own(),b=e.s.snapshot();b.edition='admin';assert.throws(()=>e.s.validateBackup(b));});
test('missing collection rejected',()=>{const e=own(),b=e.s.snapshot();delete b.members;assert.throws(()=>e.s.validateBackup(b));});
test('broken member reference rejected',()=>{const e=environment(),b=e.s.snapshot();b.workouts[0].memberId='missing';assert.throws(()=>e.s.validateBackup(b));});
test('unexpected collections rejected',()=>{const e=own(),b=e.s.snapshot();b.otherCoachAccounts=[];assert.throws(()=>e.s.validateBackup(b));});
test('unsupported versions, malformed v5 drafts and invalid references stop before review',()=>{
  const e=own(),p=e.page('data-tools'),backup=e.s.snapshot(),before=e.writes;
  p.openRestore();
  const invalid=[
    {...backup,backupVersion:6},{...backup,backupVersion:4.5},{...backup,backupVersion:'5'},
    {...backup,workoutDrafts:undefined},{...backup,workoutDrafts:{}},{...backup,workoutDrafts:[{}]},
    {...backup,photos:[{id:'bad',memberId:'toString'}]}
  ];
  for (const value of invalid) {
    const text=JSON.stringify(value);
    p.onRestoreInput({detail:{value:text}});
    assert.equal(p.restore(),false);
    assert.equal(p.data.restoreReview,null);
    assert.equal(p.data.restoreText,text);
  }
  assert.equal(e.writes,before);
});
test('legacy missing drafts and explicit empty drafts are distinct when the current count is zero',()=>{
  const e=own(),p=e.page('data-tools'),backup=e.s.snapshot();
  const legacy={...backup,backupVersion:4};
  delete legacy.workoutDrafts;
  for (const [value,label] of [[legacy,'旧备份未包含'],[backup,'0 份']]) {
    p.openRestore();
    p.onRestoreInput({detail:{value:JSON.stringify(value)}});
    assert.equal(p.restore(),true);
    const review=p.data.restoreReview, row=review.rows.find(item=>item.key==='workoutDrafts');
    assert.equal(row.current,'0 份');
    assert.equal(row.backup,label);
    assert.equal(review.draftNote,'恢复后训练草稿为空。');
    p.cancelRestore();
  }
});
test('cancel preserves data and permits retry',()=>{const e=own(),p=e.page('data-tools'),txt=JSON.stringify(e.s.snapshot()),before=JSON.stringify(e.storage);restore(e,p,txt,false);assert.equal(JSON.stringify(e.storage),before);assert.equal(p.data.restoring,false);});
test('copy paste validate restore replaces own members and profile exactly',()=>{const e=own(),p=e.page('data-tools');let clipboard;e.wx.setClipboardData=o=>{clipboard=o.data;o.success();};e.wx.getClipboardData=o=>o.success({data:clipboard});p.copyBackup();e.s.set('members',[{id:'temporary',name:'恢复前临时记录',status:'正常训练'}]);e.s.set('coachProfile',{name:'恢复前资料'});p.pasteBackup();p.restore();assert.equal(p.data.restoreReview.rows.find(row=>row.key==='members').backup,'2 位');assert.equal(p.confirmRestore(),true);assert.deepEqual(e.s.list('members').map(m=>m.id),['mine-a','mine-b']);assert.equal(e.s.get('coachProfile').name,'自录教练甲');assert.equal(p.data.counts.members,2);assert.equal(p.data.feedback.title,'数据恢复成功');});
test('all collections rules custom exercise decimals order survive roundtrip',()=>{const e=environment();const ex=e.s.list('exercises');ex.push({...ex[0],id:'custom-own',name:'我的自定义动作',custom:true});e.s.set('exercises',ex);const w=e.s.list('workouts');w[0].sets[0].weight=15.75;w[0].sets[0].exerciseOrder=2;w[0].sets[0].exerciseInstanceId='own-instance';e.s.set('workouts',w);const pks=e.s.list('packages');pks[0].archived=true;pks[0].status='closed';e.s.set('packages',pks);const b=e.s.snapshot();e.s.set('coachProfile',{name:'改动'});e.s.restoreSnapshot(JSON.stringify(b));const after=e.s.snapshot();for(const k of Object.keys(b))if(k!=='exportedAt')assert.deepEqual(clone(after[k]),clone(b[k]),k);});
test('stale confirmation cannot overwrite newer records',()=>{const e=own(),p=e.page('data-tools');p.onRestoreInput({detail:{value:JSON.stringify(e.s.snapshot())}});p.restore();e.s.set('members',e.s.list('members').concat({id:'newer',name:'确认期间新增',status:'正常训练'}));assert.equal(p.confirmRestore(),false);assert.equal(p.data.feedback.title,'确认期间数据已变化');assert.equal(e.s.list('members').length,3);assert.equal(p.data.feedback.tone,'error');});
test('storage failure rolls back entire restore with no success toast',()=>{const e=own(),p=e.page('data-tools'),b=e.s.snapshot();e.s.set('coachProfile',{name:'必须保留'});const before=JSON.stringify(e.storage);p.onRestoreInput({detail:{value:JSON.stringify(b)}});p.restore();e.fail(true);assert.equal(p.confirmRestore(),false);assert.equal(p.data.feedback.title,'恢复未完成');assert.equal(JSON.stringify(e.storage),before);assert.equal(p.data.restoring,false);assert(p.data.restoreText.length>100);assert.equal(p.data.feedback.tone,'error');});
test('older backups without optional metadata remain readable',()=>{const e=own(),b=e.s.snapshot();['sampleRegistry','sampleCatalogVersion','cleanupHistory','feedbacks','dataVersion'].forEach(k=>delete b[k]);assert(e.s.validateBackup(b));e.s.restoreSnapshot(b);assert.equal(e.s.list('members').length,2);});
test('repeated startup and a fresh runtime preserve members and the storage contract',()=>{const e=own(),before=JSON.stringify(e.s.list('members'));e.s.initDemoData();e.s.initDemoData();assert.equal(JSON.stringify(e.s.list('members')),before);assert.equal(e.storage.leonCoachExperienceStateV1.schemaVersion,2);assert(Number.isSafeInteger(e.storage.leonCoachExperienceStateV1.revision));const restored=environment(JSON.parse(JSON.stringify(e.storage)),true);assert.equal(JSON.stringify(restored.s.list('members')),before);});
test('clipboard read failure retains generated text and reports no success',()=>{const e=own(),p=e.page('data-tools');e.wx.setClipboardData=o=>o.success();e.wx.getClipboardData=o=>o.fail();p.copyBackup();assert.equal(p.data.feedback.title,'备份未完整复制');assert(p.data.backupText.length>100);assert.equal(p.data.copying,false);});
test('missing clipboard callbacks release copy and paste and ignore late results',()=>{
  const e=own(),p=e.page('data-tools');
  let copyRead,pasteRead;
  e.wx.setClipboardData=options=>options.success();
  e.wx.getClipboardData=options=>{copyRead=options;};
  p.copyBackup();
  const exported=p.data.backupText;
  assert.equal(p.data.copying,true);
  e.timers.at(-1).fn();
  assert.equal(p.data.copying,false);
  assert.equal(p.data.feedback.tone,'error');
  copyRead.success({data:exported});
  assert.equal(p.data.feedback.tone,'error');
  assert.equal(p.data.backupText,exported);
  p.openRestore();
  e.wx.getClipboardData=options=>{pasteRead=options;};
  p.pasteBackup();
  assert.equal(p.data.pasting,true);
  e.timers.at(-1).fn();
  assert.equal(p.data.pasting,false);
  assert.equal(p.data.feedback.title,'读取剪贴板超时');
  p.onRestoreInput({detail:{value:exported}});
  pasteRead.success({data:'late'});
  assert.equal(p.data.restoreText,exported);
  assert.equal(p.restore(),true);
});
test('full restore commits a single native storage write',()=>{const e=own(),b=e.s.snapshot();e.s.set('members',[]);e.s.set('coachProfile',{name:'待替换'});const before=e.writes;e.s.restoreSnapshot(b);assert.equal(e.writes,before+1);assert.equal(e.s.list('members').length,2);});
test('invalid existing state fails without blank replacement',()=>{const e=own(),key='leonCoachExperienceStateV1';e.storage[key].schemaVersion=999;const before=JSON.stringify(e.storage);assert.throws(()=>e.s.initDemoData());assert.equal(JSON.stringify(e.storage),before);});
const report={passed,failed:results.length-passed,results};fs.writeFileSync(path.join(__dirname,'../docs/备份恢复专项验证.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
