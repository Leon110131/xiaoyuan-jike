const assert = require('node:assert/strict');
const { beforeEach, test } = require('node:test');
const appConfig = require('../app.json');
const store = require('../utils/store');
const drafts = require('../utils/workout-drafts');
const local = require('../utils/local-state');
const cleanup = require('../utils/sample-cleanup');
const views = require('../utils/course-read-view');

const app = { globalData: {} };
let storage, routes, modals, config, stack, failWrites;
global.getApp = () => app;
global.getCurrentPages = () => stack;
global.Page = value => { config = value; };
global.wx = {
  getStorageSync: () => storage,
  setStorageSync(key, value) {
    assert.equal(key, 'leonCoachExperienceStateV1');
    if (failWrites) throw Error('模拟写入失败');
    storage = structuredClone(value);
  },
  navigateTo(options) {
    routes.push({ api: 'navigateTo', url: options.url });
    if (options.success) options.success({});
    if (options.complete) options.complete({});
  },
  switchTab(options) {
    routes.push({ api: 'switchTab', url: options.url });
    if (options.complete) options.complete({});
  },
  navigateBack() { routes.push({ api: 'navigateBack' }); },
  showModal(options) { modals.push(options); },
  showToast() {},
  hideKeyboard() {}
};

function page(name, query = {}) {
  const modulePath = require.resolve('../pages/' + name + '/index');
  delete require.cache[modulePath];
  require(modulePath);
  const entry = Object.assign({}, config, {
    route: 'pages/' + name + '/index', data: structuredClone(config.data),
    setData(data, done) { Object.assign(this.data, data); if (done) done(); }
  });
  if (entry.onLoad) entry.onLoad(query);
  return entry;
}

function member(id, name = id) {
  return { id, name, status: '正常训练', createdAt: '2026-11-01' };
}

function course(id, memberId, time, extras = {}) {
  return Object.assign({ id, memberId, date: '2026-11-11', time, duration: 60, status: 'scheduled', deducted: false }, extras);
}

function draft(id, memberId, extras = {}) {
  const data = Object.assign({
    workoutId: id, memberId, editingExisting: false, date: '2026-11-11', time: '17:00',
    duration: 60, courseId: '', courseTitle: '', planId: '', launchPlanId: '', planChoiceLabel: '不使用计划',
    notes: '', subjective: '', exercises: [], launchedFromPlan: false, templateSnapshot: null
  }, extras);
  return { id: 'draft:' + id, memberId, workoutId: id, courseId: data.courseId, sourceCourseId: '',
    data: Object.fromEntries(drafts.fields.filter(key => key in data).map(key => [key, data[key]])),
    baseWorkoutSnapshot: null, restState: null, updatedAt: 100 };
}

function filledAuth() {
  const auth = page('auth');
  auth.onShow();
  auth.setData({ form: { name: '演示教练', phone: '13800000000', code: '123456', password: 'example1' },
    codeSent: true, codePhone: '13800000000', agreementsAccepted: true });
  stack = [{ route: 'pages/mine/index' }, auth];
  return auth;
}

beforeEach(() => {
  storage = undefined; routes = []; modals = []; stack = []; failWrites = false; app.globalData = {};
  store.initDemoData();
});

test('four native tab routes match the shared bar, and settings and calendar are secondary routes', () => {
  const tabs = require('../utils/tab-page').tabs;
  assert.deepEqual(appConfig.tabBar.list.map(row => ['/' + row.pagePath, row.text]), tabs.map(row => [row.pagePath, row.text]));
  assert.deepEqual(tabs.map(row => row.text), ['工作', '会员', '工具', '经营']);
  assert.deepEqual(require('../utils/back-navigation').roots, ['dashboard', 'members', 'tools', 'statistics']);
  for (const route of ['pages/calendar/index', 'pages/mine/index']) {
    assert(appConfig.pages.includes(route));
    assert(!tabs.some(row => row.pagePath === '/' + route));
  }
  let component;
  global.Component = definition => { component = definition; };
  require('../custom-tab-bar/index');
  const bar = { data: { selected: 0 } };
  component.methods.switchTab.call(bar, { currentTarget: { dataset: { index: 2 } } });
  assert.deepEqual(routes.pop(), { api: 'switchTab', url: '/pages/tools/index' });
  require('../components/native-shell/index');
  component.methods.openSettings();
  assert.deepEqual(routes.pop(), { api: 'navigateTo', url: '/pages/mine/index' });
});

test('work calendar reopens the saved date, scope, filter and expansion; Today returns through the stack', () => {
  const today = page('dashboard');
  today.goReadCalendar();
  assert.deepEqual(routes.pop(), { api: 'navigateTo', url: '/pages/calendar/index' });
  const first = page('calendar');
  first.setData({ date: '2026-12-05', mode: 'month', statusIndex: 2, rangeIndex: 2, monthExpanded: true });
  first.onUnload();
  const reopened = page('calendar');
  assert.equal(reopened.data.date, '2026-12-05');
  assert.equal(reopened.data.mode, 'month');
  assert.equal(reopened.data.statusIndex, 2);
  assert(reopened.data.monthExpanded);
  stack = [today, reopened];
  reopened.goWorkToday();
  assert.deepEqual(routes.pop(), { api: 'navigateBack' });
});

test('course rows preserve actual debit separately and never offer gaps across hidden or overlapping courses', () => {
  store.set('members', [member('m')]);
  const now = new Date(2026, 10, 11, 17, 24).getTime();
  const a = course('past', 'm', '14:00');
  const b = course('next', 'm', '18:00');
  store.set('courses', [a, b]);
  const today = views.today(views.read(now), a.date);
  assert.equal(today.pending[0].label, '已过时待处理');
  assert.equal(today.pending[0].debitLabel, '未扣课');
  assert.equal(today.next.id, 'next');
  assert(views.schedule(views.read(now), a.date, 'day', 0, now).day[1].gap.canBook);
  assert(!views.schedule(views.read(now), a.date, 'day', 1, now).day.some(row => row.gap));
  store.set('courses', [a, course('overlap', 'm', '14:30'), b]);
  assert(!views.schedule(views.read(now), a.date, 'day', 0, now).day.some(row => row.gap));
  store.set('courses', [course('overnight', 'm', '23:00', { date: '2026-11-10', duration: 90 }), a, b]);
  assert(!views.schedule(views.read(now), a.date, 'day', 0, now).day.some(row => row.gap));
});

test('work draft launch resolves the exact ID; a new unbooked session only enters after choosing a member', () => {
  store.set('members', [member('m1', '同名会员'), member('m2', '同名会员')]);
  const a = draft('a', 'm1'), b = draft('b', 'm2');
  store.set('workoutDrafts', [a, b]);
  const before = store.revision();
  const work = page('dashboard');
  work.openWorkDraft({ currentTarget: { dataset: { id: b.id } } });
  assert.equal(routes.pop().url, '/pages/workout/index?draftId=draft%3Ab&memberId=m2');
  const resumed = page('workout', { draftId: b.id, memberId: b.memberId });
  assert.equal(resumed.data.workoutId, b.workoutId);
  assert.equal(resumed.data.memberId, b.memberId);
  const missing = page('workout', { draftId: 'draft:missing', memberId: b.memberId });
  assert.match(missing.data.editError, /草稿已不存在/);
  work.startUnscheduledWorkout();
  assert.equal(work.data.workoutMembers.length, 2);
  assert.equal(routes.length, 0);
  work.chooseWorkoutMember({ currentTarget: { dataset: { id: 'm1' } } });
  assert.equal(routes.pop().url, '/pages/workout/index?fresh=1&memberId=m1');
  assert.equal(drafts.choose({ fresh: '1', memberId: 'm1' }, 'm1'), undefined);
  assert.equal(store.revision(), before);
});

test('tool links open plans and all training records directly with no storage writes', () => {
  const tools = page('tools'), before = store.revision();
  for (const resource of tools.data.resources) tools.openTool({ currentTarget: { dataset: resource } });
  assert.deepEqual(routes.map(row => row.url), ['/pages/training/index?tab=plans', '/pages/exercise-library/index', '/pages/training/index?tab=logs']);
  assert.equal(page('training', { tab: 'logs' }).data.tab, 'logs');
  assert.equal(store.revision(), before);
});

test('selected-month income and current liability preserve their separate existing scopes', () => {
  store.set('members', [member('m')]);
  store.set('packages', [{ id: 'p', memberId: 'm', total: 10, used: 2, remaining: 8, status: 'paused',
    saleAmount: 1000, saleDate: '2026-10-10' }]);
  store.set('financialEntries', [{ id: 'i', type: 'income', amount: 80, date: '2026-10-11' },
    { id: 'e', type: 'expense', amount: 120, date: '2026-10-11' }]);
  const business = page('statistics'), before = store.revision();
  business.setData({ anchorDate: '2026-10-01' });
  business.onShow();
  assert.equal(business.data.cashBalance, 960);
  assert.equal(business.data.liability, 800);
  business.applyMonthPicker({ currentTarget: { dataset: { month: '2026-11' } } });
  assert.equal(business.data.cashBalance, 0);
  assert.equal(business.data.liability, 800);
  assert.equal(business.data.historyBars.length, 6);
  assert.equal(store.revision(), before);
});

test('old backup shows actual draft loss before confirmation; cancelling does not write', () => {
  store.set('members', [member('m')]);
  store.set('workoutDrafts', [draft('d', 'm')]);
  const backup = store.snapshot();
  backup.backupVersion = 4;
  delete backup.workoutDrafts;
  const tools = page('data-tools');
  tools.setData({ restoreText: JSON.stringify(backup) });
  const before = JSON.stringify(storage);
  tools.restore();
  const review = tools.data.restoreReview;
  const row = review.rows.find(item => item.key === 'workoutDrafts');
  assert.equal(row.current, '1 份');
  assert.equal(row.backup, '旧备份未包含');
  assert.match(review.draftNote, /当前 1 份训练草稿将被清空/);
  assert.equal(JSON.stringify(storage), before);
  tools.cancelRestore();
  assert.equal(JSON.stringify(storage), before);
  tools.restore();
  tools.confirmRestore();
  assert.equal(store.list('workoutDrafts').length, 0);
  assert.equal(store.list('members').length, 1);
});

test('explicit zero drafts are distinguished from an old backup, and changed data prevents restoring', () => {
  store.set('members', [member('m')]);
  const backup = store.snapshot();
  store.set('workoutDrafts', [draft('d', 'm')]);
  const tools = page('data-tools');
  tools.setData({ restoreText: JSON.stringify(backup) });
  tools.restore();
  const row = tools.data.restoreReview.rows.find(item => item.key === 'workoutDrafts');
  assert.equal(row.current, '1 份');
  assert.equal(row.backup, '0 份');
  store.set('members', [member('m', '最新资料')]);
  const before = JSON.stringify(storage);
  assert.equal(tools.confirmRestore(), false);
  assert.equal(tools.data.feedback.title, '确认期间数据已变化');
  assert.equal(JSON.stringify(storage), before);
});

test('sample cleanup protects draft member, source course, plan and chained package references', () => {
  const m = member('m'), spare = member('spare');
  const c = course('course', 'm', '17:00', { packageId: 'pack' });
  const pack = { id: 'pack', memberId: 'm' };
  const plan = { id: 'plan' };
  const sample = { members: [m, spare], courses: [c], packages: [pack], plans: [plan] };
  for (const [name, data] of Object.entries(sample)) store.set(name, data);
  cleanup.register('coach', sample);
  const d = draft('draft', 'm', { templateSnapshot: { id: 'plan' } });
  d.sourceCourseId = 'course';
  store.set('workoutDrafts', [d]);
  const preview = cleanup.preview('coach');
  assert.deepEqual(preview.rows.find(row => row.collection === 'members').ids, ['spare']);
  assert.equal(preview.total, 1);
  cleanup.clear('coach', preview.revision);
  assert.deepEqual(store.list('members'), [m]);
  assert.deepEqual(store.list('courses'), [c]);
  assert.deepEqual(store.list('packages'), [pack]);
  assert.deepEqual(store.list('plans'), [plan]);
  assert.deepEqual(store.list('workoutDrafts'), [d]);
});

test('unreadable draft links disable sample cleanup before a write', () => {
  store.set('workoutDrafts', [{ id: 'unreadable' }]);
  const before = JSON.stringify(storage);
  cleanup.confirm('coach', {});
  assert.equal(modals.pop().showCancel, false);
  assert.equal(JSON.stringify(storage), before);
});

test('registration without existing profile content keeps the direct path and never stores the password', () => {
  const auth = filledAuth();
  auth.submit();
  assert(!auth.data.registrationConfirmOpen);
  const saved = store.get('coachProfile');
  assert(saved.isRegistered);
  assert.equal(saved.password, undefined);
  assert.equal(saved.code, undefined);
  assert(saved.legalConsents[0].versions.privacy);
});

test('profile replacement requires a second confirmation, cancellation and stale confirmation preserve data', () => {
  store.set('coachProfile', { name: '旧教练', brand: '自定义', avatarUrl: 'local-avatar', bio: '旧简介' });
  store.set('members', [member('m')]);
  const auth = filledAuth();
  const before = JSON.stringify(storage);
  auth.submit();
  assert(auth.data.registrationConfirmOpen);
  assert.equal(JSON.stringify(storage), before);
  auth.cancelRegistration();
  assert(!auth.data.registrationConfirmOpen);
  assert.equal(auth.data.form.phone, '13800000000');
  assert.equal(JSON.stringify(storage), before);
  auth.submit();
  store.set('coachProfile', Object.assign({}, store.get('coachProfile'), { bio: '已更新' }));
  const latest = JSON.stringify(storage);
  auth.confirmRegistration();
  assert.equal(JSON.stringify(storage), latest);
  assert(!auth.data.registrationConfirmOpen);
  auth.submit();
  auth.confirmRegistration();
  const saved = store.get('coachProfile');
  assert(saved.isRegistered);
  assert.equal(saved.brand, '小圆记课');
  assert.equal(saved.avatarUrl, undefined);
  assert.equal(saved.bio, undefined);
  assert.equal(store.list('members')[0].id, 'm');
});

test('registration replacement rolls back fully if the transaction cannot write', () => {
  store.set('coachProfile', { name: '旧教练', brand: '个人品牌' });
  const auth = filledAuth();
  auth.submit();
  const before = JSON.stringify(storage);
  failWrites = true;
  auth.confirmRegistration();
  assert.equal(JSON.stringify(storage), before);
  assert(auth.data.registrationConfirmOpen);
  assert(auth.data.operationError);
});

test('course detail from each calendar range returns to the original context and reads updated data', () => {
  const calendar = page('calendar');
  store.set('members', [member('m')]);
  store.set('courses', [course('c', 'm', '16:00')]);
  for (const mode of ['day', 'week', 'month']) {
    const context = { date: '2026-11-11', mode, statusIndex: 2, rangeIndex: 1, timelineAnchor: 'time-960' };
    calendar.setData(context);
    calendar.openCoursePage({ currentTarget: { dataset: { id: 'c' } } });
    assert.deepEqual(routes.pop(), { api: 'navigateTo', url: '/pages/course-detail/index?id=c' });
    const detail = page('course-detail', { id: 'c' });
    stack = [calendar, detail];
    detail.onShow();
    assert.equal(detail.data.detail.debitLabel, '未扣课');
    store.patch('courses', 'c', { title: '调整后的课程' });
    detail.onShow();
    assert.equal(detail.data.detail.title, '调整后的课程');
    detail.closeCourseDetail();
    assert.deepEqual(routes.pop(), { api: 'navigateBack' });
    calendar.loadCourses(false);
    for (const key of Object.keys(context)) assert.equal(calendar.data[key], context[key]);
  }
});

test('detail debit confirmation cancels without writing and refreshes only after a successful debit', () => {
  store.set('members', [member('m')]);
  store.set('courses', [course('c', 'm', '16:00')]);
  store.set('packages', [{ id: 'p', memberId: 'm', name: '训练课包', total: 8, remaining: 8, used: 0, status: 'active' }]);
  const detail = page('course-detail', { id: 'c' });
  stack = [{ route: 'pages/calendar/index' }, detail];
  detail.onShow();
  detail.openDebitChoices();
  assert.equal(detail.data.selectedPackageId, 'p');
  detail.confirmSelectedPackage();
  assert.match(detail.data.courseConfirmation.content, /扣 1 节后剩余 7 节/);
  const before = structuredClone(storage);
  detail.cancelCourseConfirmation();
  assert.deepEqual(storage, before);
  assert.equal(detail.data.panel, 'packages');
  detail.confirmSelectedPackage();
  failWrites = true;
  detail.acceptCourseConfirmation();
  assert.deepEqual(storage, before);
  assert(detail.data.writeError);
  failWrites = false;
  detail.confirmSelectedPackage();
  detail.acceptCourseConfirmation();
  assert.equal(detail.data.detail.debitLabel, '已扣课');
  assert.equal(store.byId('packages', 'p').remaining, 7);
  assert.equal(store.list('ledger').length, 1);
  detail.openDebitChoices();
  assert.equal(detail.data.panel, 'detail');
  assert.equal(store.byId('packages', 'p').remaining, 7);
});

test('booking starts as a single course and refuses an invalid repeat count without clearing entries', () => {
  store.set('members', [member('m', '许宁')]);
  const form = page('course-form', { memberId: 'm', date: '2026-11-11', time: '16:00', duration: 45 });
  assert.equal(form.data.saveLabel, '保存 1 节预约');
  assert.equal(form.data.endLabel, '16:45');
  form.toggleRepeat({ detail: { value: true } });
  assert.equal(form.data.repeatSummary, '每周三 16:00，至 12月2日');
  form.onRepeatWeeks({ detail: { value: '0' } });
  form.onInput({ currentTarget: { dataset: { key: 'notes' } }, detail: { value: '训练备注' } });
  assert.equal(form.save(), false);
  assert.match(form.data.fieldError, /1–52/);
  assert.equal(form.data.form.notes, '训练备注');
  assert.equal(form.data.form.memberId, 'm');
  assert.equal(form.data.hasUnsavedChanges, true);
  assert.equal(store.list('courses').length, 0);
});

test('completed-course deletion waits for the detail layer to close before navigating back', async () => {
  store.set('members', [member('m')]);
  store.set('courses', [course('c', 'm', '16:00')]);
  store.set('packages', [{ id: 'p', memberId: 'm', name: '训练课包', total: 8, remaining: 8, used: 0, status: 'active' }]);
  assert.equal(store.completeCourse('c', 'p').ok, true);
  const detail = page('course-detail', { id: 'c' });
  stack = [{ route: 'pages/calendar/index' }, detail];
  detail.onShow();
  detail.openCourseTransactions();
  detail.confirmReadRemoval();
  let afterRender;
  const setData = detail.setData;
  detail.setData = function (patch, callback) {
    setData.call(this, patch);
    if (callback) afterRender = callback;
  };
  detail.acceptCourseConfirmation();
  assert.equal(store.byId('packages', 'p').remaining, 8);
  assert.equal(detail.data.detail, null);
  assert.equal(detail.data.backGuardVisible, false);
  assert.deepEqual(routes, []);
  assert.equal(typeof afterRender, 'function');
  afterRender();
  assert.deepEqual(routes, []);
  await new Promise(resolve => setTimeout(resolve, 320));
  assert.deepEqual(routes, [{ api: 'navigateBack' }]);
});

test('member history filters by source month and workout end date, then opens the shared detail routes', () => {
  store.set('members', [member('m', '林悦'), member('other', '林悦')]);
  store.set('courses', [course('c', 'm', '18:00'), course('old', 'm', '12:00', { date: '2026-10-11' }), course('other-c', 'other', '19:00')]);
  store.set('workouts', [
    { id: 'w', memberId: 'm', date: '2026-11-10', time: '23:30', duration: 60, sets: [] },
    { id: 'other-w', memberId: 'other', date: '2026-11-11', time: '18:00', sets: [] }
  ]);
  const history = page('member-courses', { memberId: 'm', all: '1', month: '2026-11' });
  history.onShow();
  assert.deepEqual(history.data.courses.map(c => c.id), ['c']);
  history.openCourse({ currentTarget: { dataset: { id: 'c' } } });
  assert.deepEqual(routes.pop(), { api: 'navigateTo', url: '/pages/course-detail/index?id=c' });
  history.openCourse({ currentTarget: { dataset: { id: 'other-c' } } });
  assert.deepEqual(routes, []);
  const training = page('member-courses', { memberId: 'm', mode: 'training' });
  training.pickEnd({ detail: { value: '2026-11-11' } });
  assert.deepEqual(training.data.workouts.map(w => w.id), ['w']);
  training.openWorkout({ currentTarget: { dataset: { id: 'w' } } });
  assert.deepEqual(routes.pop(), { api: 'navigateTo', url: '/pages/session-report/index?workoutId=w' });
});

test('package edit stops on stale data and reloads the same ID, preserving only non-conflicting input', () => {
  store.set('members', [member('m')]);
  const initial = { id: 'p', memberId: 'm', name: '原课包', type: '线下私教', total: 10, used: 4, remaining: 6,
    saleAmount: 600, status: 'active', startDate: '2026-11-01' };
  store.set('packages', [initial]);
  const packages = page('packages', { memberId: 'm' });
  packages.onShow();
  packages.openPackageDetail({ currentTarget: { dataset: { id: 'p' } } });
  packages.editPackage({ currentTarget: { dataset: { id: 'p' } } });
  packages.onInput({ currentTarget: { dataset: { key: 'name' } }, detail: { value: '教练备注名' } });
  packages.onInput({ currentTarget: { dataset: { key: 'total' } }, detail: { value: '12' } });
  store.patch('packages', 'p', { total: 11, remaining: 7, status: 'paused' });
  const before = structuredClone(storage);
  assert.equal(packages.savePackage(), false);
  assert.deepEqual(storage, before);
  assert.equal(packages.data.reviewState, 'stale');
  packages.reloadPackage();
  assert.equal(packages.data.reviewState, 'loaded');
  assert.equal(packages.data.form.name, '教练备注名');
  assert.equal(packages.data.form.total, '11');
  assert.deepEqual(packages.data.conflicts, ['总课时']);
  assert.equal(packages.data.reviewedPackage.statusLabel, '已暂停');
  assert.equal(packages.savePackage(), false);
  packages.reloadPackage();
  assert.equal(packages.savePackage(), true);
  assert.equal(store.byId('packages', 'p').name, '教练备注名');
  assert.equal(store.byId('packages', 'p').remaining, 7);
  assert.equal(store.list('packages').length, 1);
});

test('package task confirmation rechecks the snapshot and keeps the original ledger scope', () => {
  store.set('members', [member('m')]);
  const pack = { id: 'p', memberId: 'm', name: '原课包', type: '线下私教', total: 10, used: 4, remaining: 6, status: 'active' };
  store.set('packages', [pack, Object.assign({}, pack, { id: 'other' })]);
  const packages = page('packages', { memberId: 'm' });
  packages.onShow();
  packages.openPackageDetail({ currentTarget: { dataset: { id: 'p' } } });
  packages.openPackageTasks();
  const action = (name, days) => packages.previewPackageAction({ currentTarget: { dataset: { action: name, days } } });
  action('return');
  assert.match(packages.data.packageConfirm.content, /不撤销课程记录，不产生现金退款/);
  store.patch('packages', 'p', { used: 5, remaining: 5 });
  const changed = structuredClone(storage);
  packages.commitPackageAction();
  assert.deepEqual(storage, changed);
  assert.match(packages.data.packageTaskError, /变化/);
  for (const [name, days] of [['return'], ['gift'], ['extend', 7], ['pause'], ['pause']]) {
    packages.openPackageTasks();
    action(name, days);
    packages.commitPackageAction();
  }
  assert.equal(store.byId('packages', 'p').remaining, 7);
  assert.equal(store.byId('packages', 'p').used, 4);
  assert.equal(store.byId('packages', 'p').status, 'active');
  assert(store.byId('packages', 'p').endDate);
  assert.equal(store.byId('packages', 'other').remaining, 6);
  packages.openLedger({ currentTarget: { dataset: { id: 'p' } } });
  const entry = packages.data.ledgerView.find(row => row.type === '退回课时');
  packages.openLedgerDetail({ currentTarget: { dataset: { id: entry.id } } });
  assert.equal(packages.data.ledgerDetail.packageId, 'p');
  packages.hideLedger({ currentTarget: { dataset: { id: entry.id } } });
  modals.pop().success({ confirm: true });
  assert.equal(packages.data.ledgerPackageId, 'p');
  assert.equal(packages.data.ledgerView.length, 4);
  assert.equal(store.byId('ledger', entry.id).historyHidden, true);
  assert.equal(store.byId('packages', 'p').remaining, 7);
});

test('same-name member removal identifies the original member and rejects a changed confirmation', () => {
  store.set('members', [Object.assign(member('m', '林悦'), { phone: '13800001234' }), member('other', '林悦')]);
  const form = page('member-form', { id: 'm' });
  form.deleteMember();
  const stale = modals.pop();
  assert.match(stale.content, /电话尾号 1234 · 会员 ID m/);
  assert.match(stale.content, /手机相册原图保留/);
  store.patch('members', 'm', { notes: '刚刚更新' });
  const before = structuredClone(storage);
  stale.success({ confirm: true });
  assert.deepEqual(storage, before);
  modals.pop();
  form.reloadMember();
  form.deleteMember();
  modals.pop().success({ confirm: true });
  assert.equal(store.byId('members', 'm'), null);
  assert.equal(store.byId('members', 'other').name, '林悦');
});
