const assert = require('node:assert/strict');
const { test } = require('node:test');
const env = require('./business-harness');

const event = (key, value) => ({ currentTarget: { dataset: { [key]: value } } });
const snap = e => JSON.stringify(e.storage);
const route = e => e.events.filter(x => x.key === 'navigateTo').at(-1)?.options.url;

function fixture() {
  const e = env(), s = e.s;
  s.set('packages', [
    { id: 'oct', memberId: 'm_1001', name: '十月正额', saleDate: '2026-10-02', saleAmount: 1200, total: 12, used: 6, remaining: 6, status: 'active' },
    { id: 'paused', memberId: 'm_1002', name: '暂停', saleDate: '2026-10-05', saleAmount: 1000, total: 10, used: 6, remaining: 4, status: 'paused' },
    { id: 'nov', memberId: 'm_1001', name: '十一月正额', saleDate: '2026-11-02', saleAmount: 900, total: 6, used: 3, remaining: 3, status: 'active' },
    { id: 'neg', memberId: 'm_1001', name: '历史负额', saleDate: '2026-11-06', saleAmount: -150, total: 3, used: 3, remaining: 0, status: 'closed' },
    { id: 'zero', memberId: 'm_1002', name: '零元课包', saleDate: '2026-11-04', saleAmount: 0, total: 2, used: 1, remaining: 1, status: 'active' }
  ]);
  s.set('financialEntries', [
    { id: 'i', type: 'income', date: '2026-11-05', amount: 220, category: '其他收入', notes: '原始备注' },
    { id: 'e', type: 'expense', date: '2026-11-06', amount: 95, category: '场地费用' }
  ]);
  s.set('courses', [
    { id: 'cross', memberId: 'm_1001', status: 'completed', date: '2026-10-31', time: '18:00', duration: 60,
      completedAt: '2026-11-01', deducted: true, packageId: 'oct' },
    { id: 'elapsed', memberId: 'm_1002', status: 'scheduled', date: '2000-11-02', time: '15:00',
      duration: 60, autoTimeStatus: true, deducted: false },
    { id: 'missingDebit', memberId: 'm_1002', status: 'completed', date: '2026-11-02', time: '15:00', duration: 60 },
    { id: 'novCourse', memberId: 'm_1001', status: 'completed', date: '2026-11-03', time: '13:00',
      duration: 60, completedAt: '2026-11-03', deducted: true, packageId: 'nov' }
  ]);
  s.set('ledger', []);
  return e;
}

test('现金明细分栏保留月份，负售课只带一个符号，明细关联按源 ID 与会员', () => {
  const e = fixture(), before = snap(e);
  const p = e.page('statistics-detail', { kind: 'cashBalance', month: '2026-11' });
  assert.equal(p.data.summaryValue, '¥875.00');
  assert.equal(p.data.summaryNote, '含历史负售课 −¥150.00，首页仅汇总正售课金额');
  assert.equal(p.data.detail.records.find(row => row.id === 'neg').signedAmount, '−¥150.00');
  p.pickKind(event('kind', 'sales'));
  assert.equal(p.data.summaryValue, '¥750.00');
  p.openRecord(event('key', 'package_neg'));
  assert.match(route(e), /record=package_neg&memberId=m_1001$/);
  const sale = e.page('statistics-detail', { kind: 'sales', month: '2026-11', record: 'package_neg', memberId: 'm_1001' });
  sale.openPackage();
  assert.equal(route(e), '/pages/packages/index?memberId=m_1001&packageId=neg');
  assert.equal(e.page('packages', { memberId: 'm_1001', packageId: 'neg' }).data.selectedPackage.id, 'neg');
  assert.equal(e.page('packages', { memberId: 'm_1002', packageId: 'neg' }).data.linkedPackageMissing, true);
  const stale = e.page('statistics-detail', { kind: 'sales', month: '2026-11', record: 'package_neg', memberId: 'm_1002' });
  const count = e.events.filter(x => x.key === 'navigateTo').length;
  stale.openPackage();
  assert.equal(e.events.filter(x => x.key === 'navigateTo').length, count);
  p.pickKind(event('kind', 'cashIncome'));
  assert.equal(p.data.summaryValue, '¥220.00');
  assert.equal(p.data.summaryNote, '');
  p.openRecord(event('key', 'entry_i'));
  assert.equal(e.page('statistics-detail', { month: '2026-11', record: 'entry_i' }).data.record.notes, '原始备注');
  assert.match(e.page('statistics-detail', { month: '2026-11', record: 'entry_missing' }).data.error, /不可用/);
  p.pickMonth({ detail: { value: '2026-10' } });
  assert(p.data.detail.hasMonthRecords);
  assert.equal(p.data.emptyTitle, '没有符合条件的记录');
  p.clearCashFilter();
  assert.equal(p.data.summaryValue, '¥2,200.00');
  assert(!p.data.summaryNote.includes('历史负售课'));
  p.pickMonth({ detail: { value: '2026-07' } });
  assert.equal(p.data.emptyTitle, '这个月份暂无收支');
  assert.equal(snap(e), before);
});

test('课时明细区分真实扣课及跨月完成，按会员和课程 ID 下钻', () => {
  const e = fixture(), before = snap(e);
  const p = e.page('statistics-detail', { kind: 'income', month: '2026-11' });
  assert.equal(p.data.summaryValue, '¥250.00');
  assert.equal(p.data.detail.courses.find(c => c.id === 'cross').recognitionDate, '2026-11-01');
  p.openCourse(event('id', 'cross'));
  assert.equal(route(e), '/pages/course-detail/index?id=cross');
  p.pickKind(event('kind', 'learners'));
  assert.equal(p.data.summaryValue, '2 位');
  p.openMemberCourses(event('id', 'm_1002'));
  assert.equal(route(e), '/pages/statistics-detail/index?kind=completed&month=2026-11&memberId=m_1002');
  const member = e.page('statistics-detail', { kind: 'completed', month: '2026-11', memberId: 'm_1002' });
  assert.equal(member.data.detail.courses[0].debitLabel, '扣课待核对');
  member.openMember();
  assert.equal(route(e), '/pages/member-detail/index?id=m_1002');
  p.pickMonth({ detail: { value: '2000-11' } });
  p.pickKind(event('kind', 'completed'));
  assert.equal(p.data.summaryValue, '1 节');
  assert.equal(p.data.detail.courses[0].debitLabel, '到期 · 未扣课');
  assert.equal(snap(e), before);
});

test('跨月累计与未履约保持各自范围，零金额暂停包和长金额可读', () => {
  const e = fixture(), before = snap(e), stats = e.page('statistics');
  stats.openAccrualDetail();
  assert.match(route(e), /mode=cumulative$/);
  stats.openMembersForLiability();
  assert.match(route(e), /mode=liability$/);
  const cumulative = e.page('accrual-detail', { mode: 'cumulative' });
  const liability = e.page('accrual-detail', { mode: 'liability' });
  assert.equal(cumulative.data.summaryValue, '¥1,650.00');
  assert.equal(liability.data.summaryValue, '¥1,450.00');
  assert.equal(liability.data.remainingLessons, 14);
  liability.openMemberEstimate(event('id', 'm_1002'));
  const member = e.page('accrual-detail', { mode: 'liability', memberId: 'm_1002' });
  assert.equal(member.data.rows.find(p => p.id === 'paused').statusLabel, '已暂停');
  assert.equal(member.data.rows.find(p => p.id === 'zero').amountDisplay, '¥0.00');
  member.openPackage(event('id', 'zero'));
  assert.equal(route(e), '/pages/packages/index?memberId=m_1002&packageId=zero');
  assert(e.page('accrual-detail', { mode: 'liability', memberId: 'missing' }).data.error);
  assert.equal(e.load('utils/statistics-view').yuan(-12345678.9), '−¥12,345,678.90');
  assert.equal(snap(e), before);
  e.s.set('packages', []);
  assert.deepEqual(e.page('accrual-detail', { mode: 'liability' }).data.rows, []);
  assert.deepEqual(e.page('accrual-detail', { mode: 'cumulative' }).data.rows, []);
  e.s.set('packages', [{ id: 'long', memberId: 'm_1001', saleAmount: 12345678.9, total: 1, used: 0, remaining: 1 }]);
  assert.equal(e.page('accrual-detail', { mode: 'liability' }).data.summaryValue, '¥12,345,678.90');
});
