const assert=require('assert'),fs=require('fs'),path=require('path'),environment=require('./business-harness');
const results=[],event={currentTarget:{dataset:{ei:0,si:0}}};
function test(name,fn){try{fn();results.push({name,pass:true});}catch(error){results.push({name,pass:false,error:error.stack});console.error(name,error.stack);process.exitCode=1;}}
function setup(){const e=environment(),p=e.page('workout',{memberId:'m_1001'});p.chooseExercise({currentTarget:{dataset:{id:'e_1'}}});let now=0;p._restNow=()=>now;p.startRest(event);return {e,p,time:n=>now=n};}
function remaining(p){const [m,s]=p.data.timerLabel.split(':').map(Number);return m*60+s;}
function balanced(p){assert.equal(remaining(p)+p.data.timerElapsed,p.data.timerTarget);}
test('screenshot case: 14.5s gives 01:46 remaining and 14 elapsed, never 15',()=>{
  const {p,time}=setup();time(14500);p.tickRest();assert.equal(p.data.timerLabel,'01:46');assert.equal(p.data.timerElapsed,14);balanced(p);
  time(15000);p.tickRest();assert.equal(p.data.timerLabel,'01:45');assert.equal(p.data.timerElapsed,15);balanced(p);
});
test('all fractional-second boundaries remain complementary',()=>{
  const {p,time}=setup();for(const ms of [1,499,500,999,1000,1001,14499,14500,14999,15000,119001,119500,119999]){time(ms);p.tickRest();balanced(p);}
});
test('countdown and elapsed are set together in one page update',()=>{
  const {p,time}=setup(),patches=[],base=p.setData;p.setData=function(patch){patches.push({...patch});return base.call(this,patch);};
  time(14500);p.tickRest();const ticks=patches.filter(x=>'timerLabel' in x||'timerElapsed' in x);assert.equal(ticks.length,1);assert('timerElapsed' in ticks[0]&&'timerLabel' in ticks[0]);
});
test('sampling the elapsed display never reads a later wall-clock instant',()=>{
  const {p,time}=setup();time(14999);let reads=0;p._restClock.now=()=>{reads++;return 14999;};p._restTracker.now=()=>{throw Error('must reuse the clock sample');};
  p.tickRest();assert.equal(reads,1);assert.equal(p.data.timerElapsed,14);assert.equal(p.data.timerLabel,'01:46');balanced(p);
});
test('pause/resume keeps the half-second remainder and excludes paused time',()=>{
  const {p,time}=setup();time(14500);p.pauseRest();assert.equal(p._restClock.remaining,105.5);balanced(p);
  time(100000);p.pauseRest();balanced(p);time(100500);p.tickRest();assert.equal(p.data.timerLabel,'01:45');assert.equal(p.data.timerElapsed,15);balanced(p);
});
test('adding/subtracting time while running or paused preserves display arithmetic',()=>{
  const {p,time}=setup();time(14500);p.tickRest();p.adjustActiveRest({currentTarget:{dataset:{delta:10}}});assert.equal(p.data.timerTarget,130);balanced(p);
  p.adjustActiveRest({currentTarget:{dataset:{delta:-10}}});balanced(p);p.pauseRest();time(90000);p.adjustActiveRest({currentTarget:{dataset:{delta:10}}});balanced(p);p.pauseRest();time(90500);p.tickRest();balanced(p);
});
test('closing and reopening the popup retains one synchronized clock',()=>{
  const {p,time}=setup();p.openRestPopup(event);time(14500);p.closeRestPopup();time(15500);p.openRestPopup(event);assert(p.data.restPopupOpen);assert.equal(p.data.timerElapsed,15);assert.equal(p.data.timerLabel,'01:45');balanced(p);
});
test('early completion records whole elapsed seconds without rounding up',()=>{
  const {p,time}=setup();time(14500);p.finishRest();assert.equal(p.data.exercises[0].sets[0].restActual,14);assert.equal(p.data.exercises[0].sets[0].restPlanned,120);
});
test('paused drafts retain fractional remainder and normalize older rounded remainders',()=>{
  for(const legacy of [false,true]){const {e,p,time}=setup();time(14500);p.pauseRest();p.persistWorkoutDraft(true);const row=e.s.list('workoutDrafts')[0];assert.equal(row.restState.clock.remaining,105.5);
    if(legacy){row.restState.clock.remaining=106;e.s.upsert('workoutDrafts',row);}
    const restored=e.page('workout',{memberId:'m_1001'});assert.equal(restored._restClock.remaining,105.5);assert(restored.data.timerPaused);balanced(restored);e.s.validateBackup(e.s.snapshot());}
});
fs.writeFileSync(path.join(__dirname,'../docs/计时显示同步专项验证.json'),JSON.stringify({passed:results.filter(x=>x.pass).length,failed:results.filter(x=>!x.pass).length,results},null,2));
console.log(JSON.stringify({passed:results.filter(x=>x.pass).length,failed:results.filter(x=>!x.pass).length}));
