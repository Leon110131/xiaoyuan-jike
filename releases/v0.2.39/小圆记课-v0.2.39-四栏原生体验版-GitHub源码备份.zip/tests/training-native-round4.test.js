const assert = require('node:assert/strict');
const { test } = require('node:test');
const environment = require('./business-harness');
const event = dataset => ({currentTarget:{dataset}});
const input = value => ({detail:{value}});
const state = (s, keys) => JSON.stringify(keys.map(key => s.list(key)));
const business = ['courses','packages','ledger','workouts'];

function training(query = {}) {
  const e = environment();
  e.s.addPackage({
    memberId:'m_1001', name:'原生验收包', total:8,
    startDate:'2020-01-01', endDate:'2099-12-31', saleAmount:800, saleDate:'2020-01-01'
  });
  const p = e.page('workout', {memberId:'m_1001', fresh:'1', ...query});
  p.changeDate(input('2035-03-10'));
  p.onTime(input('14:00'));
  p.chooseExercise(event({id:'e_1'}));
  p.updateSet({...event({ei:0,si:0,key:'weight'}),...input('32.5')});
  return {e,p};
}

function confirmCompletion(p) {
  p.openTrainingSubmit();
  p.openTrainingConfirmation();
  p.confirmUnbookedTraining();
}

test('草稿恢复同一训练，保存草稿不写正式记录、不建课、不扣课', () => {
  const {e,p} = training();
  const before = state(e.s,business);
  assert.equal(p.saveDraft(),true);
  const restored = e.page('workout',{draftId:'draft:'+p.data.workoutId});
  assert.equal(restored.data.exercises[0].sets[0].weight,'32.5');
  assert.equal(state(e.s,business),before);
});

test('仅保存独立记录、清理该草稿且不误关联同日唯一课程', () => {
  const {e,p} = training();
  const existing = {id:'same_day',memberId:'m_1001',date:p.data.date,time:'16:00',duration:60,status:'scheduled',deducted:false};
  e.s.upsert('courses',existing);
  const untouched = state(e.s,['courses','packages','ledger']);
  p.openTrainingSubmit();
  p.saveRecordOnly();
  p.saveRecordOnly();
  const record = e.s.byId('workouts',p.data.workoutId);
  assert.equal(record.memberId,'m_1001');
  assert.equal(record.courseId,'');
  assert.equal(e.s.list('workouts').filter(w=>w.id===record.id).length,1);
  assert.equal(e.s.list('workoutDrafts').some(row=>row.workoutId===record.id),false);
  assert.equal(state(e.s,['courses','packages','ledger']),untouched);
  const reports = e.load('utils/session-report');
  assert.equal(reports.load(e.s,existing.id).allRecords.some(w=>w.id===record.id),false);
  assert.equal(reports.loadWorkout(e.s,record.id).statusLabel,'训练记录已保存');
  e.s.validateBackup(e.s.snapshot());
});

test('独立历史编辑更新原 ID，遇到已变化记录时保留页面输入并拒绝覆盖', () => {
  const {e,p} = training();
  p.openTrainingSubmit();
  p.saveRecordOnly();
  const id=p.data.workoutId;
  const untouched = state(e.s,['courses','packages','ledger']);
  const edit = e.page('workout',{workoutId:id});
  edit.onNotes(input('调整记录'));
  edit.openTrainingSubmit();
  assert.equal(e.s.byId('workouts',id).notes,'调整记录');
  assert.equal(e.s.byId('workouts',id).memberId,'m_1001');
  assert.equal(state(e.s,['courses','packages','ledger']),untouched);
  const stale = e.page('workout',{workoutId:id});
  stale.onNotes(input('当前页输入'));
  e.s.patch('workouts',id,{notes:'较新的修改'});
  stale.openTrainingSubmit();
  assert.equal(e.s.byId('workouts',id).notes,'较新的修改');
  assert.equal(stale.data.notes,'当前页输入');
});

test('确认扣课只建一节课程和一条正式记录，实际扣 1 节并清理草稿', () => {
  const {e,p} = training();
  const credit = e.s.list('packages').reduce((n,pkg)=>n+pkg.remaining,0);
  const count = e.s.list('courses').length;
  confirmCompletion(p);
  p.confirmUnbookedTraining();
  const course = e.s.byId('courses',p.data.courseId);
  assert.equal(course.deducted,true);
  assert.equal(course.workoutId,p.data.workoutId);
  assert.equal(e.s.byId('workouts',p.data.workoutId).courseId,course.id);
  assert.equal(e.s.list('courses').length,count+1);
  assert.equal(e.s.list('packages').reduce((n,pkg)=>n+pkg.remaining,0),credit-1);
  assert.equal(e.s.list('workoutDrafts').some(row=>row.workoutId===p.data.workoutId),false);
});

test('取消、课时不足、写入失败均保留草稿，不留下部分写入', () => {
  const {e,p} = training();
  p.saveDraft();
  p.openTrainingSubmit();
  p.openTrainingConfirmation();
  const baseline = state(e.s,business);
  p.closeTrainingConfirmation();
  p.confirmUnbookedTraining();
  assert.equal(state(e.s,business),baseline);
  p.openTrainingConfirmation();
  e.fail(true);
  p.confirmUnbookedTraining();
  e.fail(false);
  assert.equal(state(e.s,business),baseline);
  assert(e.s.list('workoutDrafts').some(row=>row.workoutId===p.data.workoutId));
  e.s.list('packages').filter(pkg=>pkg.memberId===p.data.memberId).forEach(pkg=>e.s.patch('packages',pkg.id,{used:pkg.total,remaining:0}));
  const depleted = state(e.s,business);
  p.openTrainingConfirmation();
  p.confirmUnbookedTraining();
  assert.equal(state(e.s,business),depleted);
  assert(e.s.list('workoutDrafts').some(row=>row.workoutId===p.data.workoutId));
});

test('工具计划按选中的训练日与明确会员启动，取消不改变原计划', () => {
  const e=environment(), plan=e.load('utils/plan-templates').save({name:'双日验收'},[
    {name:'训练日 A',exerciseNames:['杠铃卧推']},{name:'训练日 B',exerciseNames:['高位下拉']}
  ]);
  const p=e.page('training');
  p.openPlanDetail(event({id:plan.id}));
  p.setPlanDay(event({index:1}));
  p.goWorkoutForPlan(event({id:plan.id}));
  assert.equal(p.data.planLaunchMemberId,'');
  p.confirmPlanLaunch();
  assert(!e.events.some(x=>x.key==='navigateTo'));
  p.closePlanLaunch();
  assert.equal(p.data.planDetail.id,plan.id);
  p.goWorkoutForPlan(event({id:plan.id}));
  p.pickPlanMember(event({id:'m_1002'}));
  p.confirmPlanLaunch();
  const url=new URL('https://localhost'+e.events.find(x=>x.key==='navigateTo').options.url);
  const w=e.page('workout',Object.fromEntries(url.searchParams));
  assert.equal(w.data.memberId,'m_1002');
  assert.equal(w.data.courseId,'');
  assert.equal(w.data.templateSnapshot.dayName,'训练日 B');
  assert.equal(w.data.exercises[0].name,'高位下拉');
});

test('计划缺失训练日动作时定位对应日期并保留其他输入', () => {
  const e=environment(),p=e.page('plan-form');
  p.onInput({...event({key:'name'}),...input('')});
  p.toggleExercise(event({name:'杠铃卧推'}));
  p.addDay();
  p.addDay();
  assert.equal(p.save(),false);
  assert.equal(p.data.activeDayIndex,1);
  assert(p.data.planNameError);
  assert(p.data.planDayError);
  assert.equal(p.data.days[0].exerciseNames[0],'杠铃卧推');
});

test('历史时段显示午夜跨日，缺失时长时不推算结束时间', () => {
  const archive=environment().load('utils/training-archive');
  assert.equal(archive.decorate({date:'2035-03-10',time:'23:45',duration:45},'会员').periodLabel,'2035-03-10 23:45–2035-03-11 00:30');
  assert.equal(archive.decorate({date:'2035-03-10',time:'14:00'},'会员').periodLabel,'2035-03-10 · 未记录完整时段');
});
