const test = require('node:test');
const assert = require('node:assert/strict');
const env = require('./business-harness');

const input = (key, value) => ({ currentTarget: { dataset: { key } }, detail: { value } });
const pick = (p, id) => {
  p.openSaleMembers();
  p.pickSaleMember({ currentTarget: { dataset: { id } } });
};
const collection = (e, key) => JSON.stringify(e.s.list(key));

for (const renewal of ['0', '1']) {
  test('经营售课 ' + renewal + ' 空、0、正金额均精确建包并保留原业务', () => {
    const e = env();
    const protectedKeys = ['packages', 'financialEntries', 'courses', 'ledger', 'reports'];
    const original = Object.fromEntries(protectedKeys.map(k => [k, collection(e, k)]));
    const today = e.s.formatDate(new Date()), ids = [];
    const home = e.page('statistics');
    home.setData({month:'2025-12',financeMode:'accrual'});
    home[renewal === '1' ? 'renewalSale' : 'addSale']();
    assert.equal(e.events.at(-1).options.url, '/pages/course-sale/index?renewal=' + renewal + '&month=2025-12');
    for (const amount of ['', '0', '128.50']) {
      const p = e.page('course-sale', { renewal, month: '2025-12' });
      assert.equal(p.data.form.memberId, '');
      assert.equal(p.data.form.total, '');
      assert.equal(p.data.form.startDate, today);
      assert.equal(p.data.form.endDate, e.s.dateOffset(365));
      p.save();
      pick(p, 'm_1002');
      p.onInput(input('total', '6'));
      p.onInput(input('saleAmount', amount));
      p.onStart({ detail: { value: '2026-10-15' } });
      p.save();
      p.save();
      const receipt = p.data.receipt;
      assert(receipt && !ids.includes(receipt.packageId));
      ids.push(receipt.packageId);
      const pack = e.s.byId('packages', receipt.packageId);
      assert.equal(pack.memberId, 'm_1002');
      assert.equal(pack.total, 6);
      assert.equal(pack.used, 0);
      assert.equal(pack.remaining, 6);
      assert.equal(pack.renewal, renewal === '1');
      assert.equal(pack.saleDate, today);
      assert.equal(pack.startDate, '2026-10-15');
      assert.equal(pack.saleAmount, Number(amount));
      assert.equal(receipt.amount, amount === '128.50' ? '¥128.50' : '¥0.00');
      assert(receipt.monthNotice);
      p.viewSoldPackage();
      assert.equal(e.events.at(-1).options.url, '/pages/packages/index?memberId=m_1002&packageId=' + pack.id);
      p.cancel();
      assert.equal(e.events.at(-1).options.delta, 1);
    }
    const after = e.s.list('packages');
    assert.equal(JSON.stringify(after.filter(row => !ids.includes(row.id))), original.packages);
    assert.equal(after.length, JSON.parse(original.packages).length + 3);
    for (const key of protectedKeys.slice(1)) assert.equal(collection(e, key), original[key]);
    const records = e.load('utils/cash-records').load(e.s, 'sales', today.slice(0, 7)).records;
    assert.equal(records.filter(row => ids.includes(row.id)).reduce((n, row) => n + row.amount, 0), 128.5);
  });
}

test('重名显示可区分资料，失效会员需重选，取消不丢数据', () => {
  const e = env(), existing = e.s.list('members');
  const members = existing.slice(0, 3).map((m, i) => ({ ...m, name: '验收同名', phone: i < 2 ? '13800001301' : '' }));
  e.s.set('members', members);
  const p = e.page('course-sale');
  p.openSaleMembers();
  assert(p.data.memberMatches.every(m => m.label.includes('会员 ID')));
  p.searchSaleMembers({ detail: { value: '1301' } });
  assert.equal(p.data.memberMatches.length, 2);
  p.searchSaleMembers({ detail: { value: '无匹配' } });
  assert.equal(p.data.memberMatches.length, 0);
  p.closeSaleMembers();
  assert.equal(p.data.form.memberId, '');
  pick(p, 'm_1002');
  p.onInput(input('total','8'));
  p.onInput(input('saleAmount','12.'));
  p.onInput(input('notes','原输入'));
  const before = collection(e, 'packages');
  e.s.set('members', members.map(m => m.id === 'm_1002' ? { ...m, status:'已结课' } : m));
  p.save();
  assert.equal(collection(e, 'packages'), before);
  assert.equal(p.data.form.memberId, '');
  assert.equal(p.data.form.total, '8');
  assert.equal(p.data.form.saleAmount, '12.');
  assert.equal(p.data.form.notes, '原输入');
  assert(p.data.memberError);
  pick(p,'m_1001');
  assert.equal(p.data.memberError, '');
  assert.equal(p.data.form.memberId, 'm_1001');
  e.s.set('members', members.map(m => ({...m, listRemoved: true})));
  p.onShow();
  p.openSaleMembers();
  assert.equal(p.data.members.length, 0);
  assert.equal(p.data.form.memberId, '');
});

test('售课字段校验和写入失败保留输入，可安全重试', () => {
  const e = env(), p = e.page('course-sale', { renewal:'1' });
  pick(p,'m_1001');
  p.onInput(input('name',' '));
  p.onInput(input('total','2.5'));
  p.onInput(input('saleAmount','100000000.01'));
  p.onEnd({detail:{value:'2000-01-01'}});
  p.save();
  for (const field of ['name','total','saleAmount','endDate']) assert(p.data.fieldErrors[field]);
  p.onInput(input('name','验收续费'));
  p.onInput(input('total','2'));
  p.onInput(input('saleAmount','12.340'));
  p.onEnd({detail:{value:p.data.form.startDate}});
  p.save();
  assert(p.data.fieldErrors.saleAmount);
  p.onInput(input('saleAmount','100000000.00'));
  e.fail(true);
  const before = collection(e, 'packages');
  p.save();
  assert.equal(collection(e, 'packages'), before);
  assert.equal(p.data.operationError.code, 'STORAGE_QUOTA');
  assert.equal(p.data.form.saleAmount, '100000000.00');
  e.fail(false);
  p.save();
  assert.equal(p.data.receipt.amount, '¥100,000,000.00');
});
