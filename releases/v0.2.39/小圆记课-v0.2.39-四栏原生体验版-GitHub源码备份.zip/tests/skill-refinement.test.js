const assert = require('assert');
const fs = require('fs');
const path = require('path');
const environment = require('./business-harness');
const results = [];
function test(name, fn) {
  try { fn(); results.push({name,pass:true}); }
  catch (error) { results.push({name,pass:false,error:error.stack}); console.error(name,error.stack); process.exitCode=1; }
}
const input=(key,value)=>({currentTarget:{dataset:{key}},detail:{value}});
const committed=e=>JSON.stringify(e.storage.leonCoachExperienceStateV1);

test('local service has a stable success envelope and commits multiple collections once',()=>{
  const e=environment(), api=e.load('utils/local-service'), before=e.writes, rev=e.s.revision();
  const response=api.execute(()=>{e.s.patch('members','m_1001',{name:'接口测试会员'});e.s.saveNutritionGoal({memberId:'m_1001',kcal:2000,protein:100,carbs:200,fat:50});return 'saved';});
  assert(response.ok);assert.equal(response.data,'saved');assert.equal(response.error,null);assert(response.changed);
  assert.equal(response.revision,rev+1);assert.equal(e.writes,before+1);assert.equal(api.mode,'local');
});
test('quota failure rolls back all collections and does not run success effects',()=>{
  const e=environment(), api=e.load('utils/local-service'), before=committed(e);let notified=false;e.fail(true);
  const response=api.execute(()=>{e.s.patch('members','m_1001',{name:'未提交'});e.s.set('nutritionGoals',[]);e.load('utils/local-state').afterCommit(()=>{notified=true;});});
  assert(!response.ok);assert.equal(response.error.code,'STORAGE_QUOTA');assert.equal(response.data,null);
  assert.equal(committed(e),before);assert(!notified);assert(response.error.hint.includes('请勿清除'));
});
test('failed member save keeps selections, releases lock, and can retry immediately',()=>{
  const e=environment(), p=e.page('member-form',{id:'m_1001'});p.onInput(input('name','失败后重试'));
  const before=committed(e);e.fail(true);assert.equal(p.save(),false);assert.equal(committed(e),before);
  assert.equal(p.data.form.name,'失败后重试');assert.equal(p.data.operationError.code,'STORAGE_QUOTA');assert(!p.data.saving);assert(!p._writeBusy);
  e.fail(false);p.save();assert.equal(e.s.byId('members','m_1001').name,'失败后重试');assert.equal(p.data.operationError,null);
});
test('repeated new member save after cooldown updates the same member instead of creating duplicates',()=>{
  const e=environment({},true),p=e.page('member-form');p.onInput(input('name','同一会员'));p.save();const id=p.data.id;
  assert(id);p._writeUntil=0;p.onInput(input('notes','返回失败后补充备注'));p.save();
  assert.equal(e.s.list('members').length,1);assert.equal(e.s.byId('members',id).notes,'返回失败后补充备注');
});
test('consecutive rapid taps persist one member and one write',()=>{
  const e=environment({},true),p=e.page('member-form');p.onInput(input('name','重复点击'));const writes=e.writes;
  p.save();p.save();assert.equal(e.s.list('members').length,1);assert.equal(e.writes,writes+1);
});
test('stale member form cannot overwrite a newer edit',()=>{
  const e=environment(),p=e.page('member-form',{id:'m_1001'});e.s.patch('members','m_1001',{notes:'另一处刚保存'});
  const before=committed(e);p.onInput(input('name','旧页面覆盖'));assert.equal(p.save(),false);
  assert.equal(committed(e),before);assert.equal(p.data.operationError.code,'CONFLICT');assert.equal(p.data.form.name,'旧页面覆盖');
});
test('removed or unknown member cannot be resurrected through an old editor',()=>{
  for(const id of ['m_1001','missing']){const e=environment(),p=e.page('member-form',{id});if(id==='m_1001')e.s.removeMember(id);
    const before=committed(e);p.onInput(input('name','禁止复活'));assert.equal(p.save(),false);assert.equal(committed(e),before);assert.equal(p.data.operationError.code,'CONFLICT');}
});
test('invalid picker events do not erase gender or member status',()=>{
  const e=environment(),p=e.page('member-form',{id:'m_1001'}),gender=p.data.form.gender,status=p.data.form.status;
  p.onPickGender({detail:{value:999}});p.onPickStatus({detail:{value:-1}});p.save();
  assert.equal(e.s.byId('members','m_1001').gender,gender);assert.equal(e.s.byId('members','m_1001').status,status);
});
test('expected local revision conflicts return structured errors without mutation',()=>{
  const e=environment(),api=e.load('utils/local-service'),before=committed(e);let called=false;
  const result=api.execute(()=>{called=true;},{expectedRevision:e.s.revision()-1});
  assert(!result.ok);assert.equal(result.error.code,'CONFLICT');assert(!called);assert.equal(committed(e),before);
});
test('unknown failures never expose internal exception content',()=>{
  const e=environment(),api=e.load('utils/local-service'),r=api.execute(()=>{throw Error('secret_token=private-value /internal/system.js');});
  assert.equal(r.error.code,'INTERNAL_ERROR');assert(!JSON.stringify(r).includes('private-value'));assert(!JSON.stringify(r).includes('/internal'));
});
test('validation retains useful business messages including conflicting dates',()=>{
  const e=environment(),api=e.load('utils/local-service');const r=api.execute(()=>{e.load('utils/validation').assert(false,'2027-01-08 课程冲突');});
  assert.equal(r.error.code,'VALIDATION');assert(r.error.message.includes('2027-01-08'));
});
test('corrupted local state fails closed without blank replacement',()=>{
  const e=environment();e.storage.leonCoachExperienceStateV1.revision='invalid';const before=committed(e);
  const result=e.load('utils/local-service').execute(()=>e.s.set('members',[]));assert(!result.ok);
  assert.equal(result.error.code,'INVALID_STATE');assert.equal(committed(e),before);
});
test('read failure inside page guard produces safe feedback and releases the lock',()=>{
  const e=environment(),p=e.page('member-form',{id:'m_1001'});const get=e.wx.getStorageSync;e.wx.getStorageSync=()=>{throw Error('native storage unavailable');};
  assert.equal(p.save(),false);assert.equal(p.data.operationError.code,'STORAGE_UNAVAILABLE');assert(!p._writeBusy);assert(!p.data.saving);
  e.wx.getStorageSync=get;p.save();assert.equal(p.data.operationError,null);
});
test('post-commit UI failure cannot report a saved mutation as a storage failure',()=>{
  const e=environment(),api=e.load('utils/local-service'),local=e.load('utils/local-state');
  const result=api.execute(()=>{e.s.patch('members','m_1001',{notes:'确实已保存'});local.afterCommit(()=>{throw Error('toast unavailable');});return true;});
  assert(result.ok);assert.equal(e.s.byId('members','m_1001').notes,'确实已保存');
});
test('post-commit read failure also preserves a successful result',()=>{
  const e=environment(),api=e.load('utils/local-service'),local=e.load('utils/local-state'),get=e.wx.getStorageSync;
  const result=api.execute(()=>{e.s.patch('members','m_1001',{notes:'已提交'});local.afterCommit(()=>{e.wx.getStorageSync=()=>{throw Error('read unavailable');};});});
  e.wx.getStorageSync=get;assert(result.ok);assert.equal(result.revision,null);assert(result.changed);assert.equal(e.s.byId('members','m_1001').notes,'已提交');
});
test('async local transaction is rejected before its body runs',()=>{
  const e=environment(),api=e.load('utils/local-service');let ran=false;const before=committed(e);
  const result=api.execute(async()=>{ran=true;e.s.set('members',[]);});
  assert(!result.ok);assert.equal(result.error.code,'ASYNC_TRANSACTION');assert(!ran);assert.equal(committed(e),before);
});
test('modal configuration is not mutated and failed confirmation rolls back',()=>{
  const e=environment(),feedback=e.load('utils/page-feedback'),callback=()=>{e.s.patch('members','m_1001',{notes:'失败不落库'});};
  const options={title:'确认',success:callback};feedback.showModal(options);feedback.showModal(options);assert.strictEqual(options.success,callback);
  const before=committed(e);e.fail(true);e.events.filter(x=>x.key==='showModal')[0].options.success({confirm:true});assert.equal(committed(e),before);
  assert(e.events.at(-1).options.content.includes('空间'));
});
test('navigation failure informs the user without modifying saved data',()=>{
  const e=environment(),feedback=e.load('utils/page-feedback'),before=committed(e);let failed=false;
  feedback.navigateBack({delta:1,fail:()=>{failed=true;}});e.events.at(-1).options.fail({errMsg:'fail'});
  assert(failed);assert.equal(committed(e),before);assert(e.events.at(-1).options.title.includes('页面跳转'));
});
fs.writeFileSync(path.join(__dirname,'../docs/Skill优化专项验证.json'),JSON.stringify({passed:results.filter(x=>x.pass).length,failed:results.filter(x=>!x.pass).length,results},null,2));
console.log(JSON.stringify({passed:results.filter(x=>x.pass).length,failed:results.filter(x=>!x.pass).length}));
