const tabs = require('../utils/tab-page').tabs;

Component({
  properties: { workContext: { type: Boolean, value: false } },
  data: { selected: -1, hidden: false, list: tabs },
  lifetimes: { attached() { this.syncSelected(); } },
  pageLifetimes: { show() { this.syncSelected(); } },
  methods: {
    syncSelected() {
      const pages = getCurrentPages();
      const route = pages.length ? '/' + pages[pages.length - 1].route : '';
      this.setData({ selected: this.properties.workContext ? 0 : tabs.findIndex(tab => tab.pagePath === route) });
    },
    switchTab(event) {
      const index = Number(event.currentTarget.dataset.index);
      const tab = tabs[index];
      if (!tab || index === this.data.selected || this._switching) return;
      this._switching = true;
      wx.switchTab({
        url: tab.pagePath,
        fail: () => wx.showToast({ title: '页面切换失败，请重试', icon: 'none' }),
        complete: () => { this._switching = false; }
      });
    }
  }
});
