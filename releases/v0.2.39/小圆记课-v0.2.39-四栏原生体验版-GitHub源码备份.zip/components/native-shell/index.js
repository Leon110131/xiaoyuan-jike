var ui = require('../../utils/native-ui');

Component({
  options: { multipleSlots: true },
  properties: {
    title: { type: String, value: '小圆记课' },
    backVisible: { type: Boolean, value: false },
    settingsVisible: { type: Boolean, value: false },
    scrollToBottom: { type: Boolean, value: false },
    contentScrollTop: { type: Number, value: 0 },
    scrollMode: { type: String, value: 'scroll' },
    bottomInset: { type: Number, value: -1 }
  },
  data: {
    layout: { valid: false, statusBarHeight: 0, navHeight: 44, menuRight: 16, windowHeight: 0 },
    shellStyle: '', footerStyle: '', pageMode: false, chromeOnly: false
  },
  observers: {
    'scrollMode,bottomInset': function () { this.refreshMetrics(); }
  },
  lifetimes: {
    attached: function () {
      var self = this;
      this._resize = function () { self.refreshMetrics(); };
      if (typeof wx.onWindowResize === 'function') wx.onWindowResize(this._resize);
      this.refreshMetrics();
    },
    ready: function () {
      this._ready = true;
      this.refreshMetrics();
    },
    detached: function () {
      this._ready = false;
      if (this._resize && typeof wx.offWindowResize === 'function') wx.offWindowResize(this._resize);
      this._resize = null;
    }
  },
  pageLifetimes: { show: function () { this.refreshMetrics(); } },
  methods: {
    refreshMetrics: function () {
      var metrics = ui.readMetrics(wx);
      var chromeOnly = this.properties.scrollMode === 'chrome';
      var pageMode = chromeOnly || this.properties.scrollMode === 'page';
      var inset = this.properties.bottomInset;
      var explicit = typeof inset === 'number' && isFinite(inset) && inset >= 0;
      var footerStyle = explicit || metrics.valid ? 'padding-bottom:' + (explicit ? inset : metrics.safeBottom) + 'px;' : '';
      var shellStyle = chromeOnly ? '' : metrics.valid ? (pageMode ? 'min-height:' : 'height:') + metrics.windowHeight + 'px;' : '';
      var patch = { layout: metrics, pageMode: pageMode, footerStyle: footerStyle, shellStyle: shellStyle, chromeOnly: chromeOnly };
      var signature = JSON.stringify(patch);
      if (signature !== this._metricsSignature) {
        this._metricsSignature = signature;
        this.setData(patch);
      }
      if (this._ready && signature !== this._publishedMetricsSignature) {
        this._publishedMetricsSignature = signature;
        this.triggerEvent('metrics', metrics);
      }
    },
    onBack: function () { this.triggerEvent('back', {}); },
    openSettings: function () {
      require('../../utils/page-feedback').navigateTo({ url: '/pages/mine/index' });
    }
  }
});
