Component({
  properties: {
    label: { type: String, value: '确认' },
    variant: { type: String, value: 'primary' },
    disabled: { type: Boolean, value: false },
    loading: { type: Boolean, value: false },
    compact: { type: Boolean, value: false }
  },
  data: { displayLabel: '确认', tone: 'primary' },
  observers: {
    label: function (value) { this.setData({ displayLabel: String(value || '').trim() || '确认' }); },
    variant: function (value) { this.setData({ tone: ['primary', 'secondary', 'danger', 'destructive'].indexOf(value) >= 0 ? value : 'primary' }); }
  },
  methods: {
    onActivate: function () {
      if (this.properties.disabled || this.properties.loading) return;
      this.triggerEvent('activate', {});
    }
  }
});
