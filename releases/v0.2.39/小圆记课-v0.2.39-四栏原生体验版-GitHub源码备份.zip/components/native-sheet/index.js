Component({
  options: { multipleSlots: true },
  properties: {
    open: { type: Boolean, value: false },
    title: { type: String, value: '操作' },
    triggerId: { type: String, value: '' },
    busy: { type: Boolean, value: false },
    expanded: { type: Boolean, value: false },
    centered: { type: Boolean, value: false },
    compact: { type: Boolean, value: false },
    closePolicy: { type: String, value: 'request' },
    keyboardOffset: { type: Number, value: 0 },
    scrollTop: { type: Number, value: 0 }
  },
  data: { displayTitle: '操作', fullTitle: '', hasFullTitle: false },
  observers: {
    open: function (value) {
      if (value) { this._wasOpen = true; return; }
      if (this._wasOpen) {
        this._wasOpen = false;
        var self = this;
        var triggerId = this.properties.triggerId;
        wx.nextTick(function () { self.triggerEvent('afterClose', { triggerId: triggerId }); });
      }
    },
    title: function (value) {
      var title = String(value || '').trim() || '操作';
      this.setData({ displayTitle: title.length > 36 ? title.slice(0, 36) + '…' : title, fullTitle: title, hasFullTitle: title.length > 36 });
    }
  },
  methods: {
    onBodyScroll: function (event) {
      this.triggerEvent('bodyScroll', { scrollTop: event.detail.scrollTop });
    },
    requestClose: function (reason) {
      if (!this.properties.open || this.properties.busy || this.properties.closePolicy === 'locked') return;
      this.triggerEvent('requestClose', { reason: reason || 'button', triggerId: this.properties.triggerId });
    },
    onMaskTap: function () { this.requestClose('mask'); },
    onButtonClose: function () { this.requestClose('button'); },
    stopBackgroundMove: function () {},
    stopPanelTap: function () {}
  }
});
