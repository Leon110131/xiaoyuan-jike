var copy = {
  loading: ['正在读取', '请稍候，资料尚未读取完成。'],
  empty: ['还没有记录', ''],
  'no-match': ['没有符合条件的记录', '保留当前条件，可修改关键词或清除筛选。'],
  'read-error': ['资料未能读取', '请重试，现有资料不会因此重置。'],
  'write-error': ['未保存成功', '当前输入仍保留，请检查后重试。'],
  insufficient: ['可用课时不足', '本次内容仍保留，请补充课时后继续。']
};

Component({
  properties: {
    kind: { type: String, value: 'empty' },
    title: { type: String, value: '' },
    message: { type: String, value: '' },
    primaryLabel: { type: String, value: '' },
    secondaryLabel: { type: String, value: '' }
  },
  data: { resolvedKind: 'empty', resolvedTitle: copy.empty[0], resolvedMessage: copy.empty[1], showPrimary: false, showSecondary: false },
  observers: {
    'kind,title,message,primaryLabel,secondaryLabel': function () {
      var p = this.properties;
      var kind = Object.prototype.hasOwnProperty.call(copy, p.kind) ? p.kind : 'empty';
      this.setData({
        resolvedKind: kind,
        resolvedTitle: String(p.title || '').trim() || copy[kind][0],
        resolvedMessage: String(p.message || '').trim() || copy[kind][1],
        showPrimary: kind !== 'loading' && !!String(p.primaryLabel || '').trim(),
        showSecondary: kind !== 'loading' && !!String(p.secondaryLabel || '').trim()
      });
    }
  },
  methods: {
    onPrimary: function () {
      if (!this.data.showPrimary) return;
      this.triggerEvent(this.data.resolvedKind === 'read-error' || this.data.resolvedKind === 'write-error' ? 'retry' : 'primary', { kind: this.data.resolvedKind });
    },
    onSecondary: function () {
      if (this.data.showSecondary) this.triggerEvent('secondary', { kind: this.data.resolvedKind });
    }
  }
});
