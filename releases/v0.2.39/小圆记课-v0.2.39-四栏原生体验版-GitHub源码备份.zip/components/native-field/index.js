Component({
  properties: {
    fieldId: { type: String, value: '' },
    label: { type: String, value: '字段' },
    optional: { type: Boolean, value: false },
    error: { type: String, value: '' }
  },
  methods: {
    onRequestFocus: function () {
      this.triggerEvent('requestFocus', { fieldId: this.properties.fieldId });
    }
  }
});
